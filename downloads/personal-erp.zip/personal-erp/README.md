# Personal ERP

A local-first, Workday-inspired accounting system for one household. Double-entry
core, dimensional reporting, statement ingestion and reconciliation, fixed assets,
debt, budgets, forecasts, and KPIs — all running on your own machine, in a browser,
against a single SQLite file. Nothing leaves your computer.

Built by Joseph B. Smith. Distributed as-is under the MIT license (see LICENSE) — use it,
change it, keep it private.

## Requirements

- Python 3.11 or newer
- That's it. No database server, no Docker, no accounts. The data lives in one
  `personal_erp.db` file next to the code.

## Install

From inside this folder:

```bash
python3 -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r backend/requirements.txt
```

## First run

```bash
python -m backend.manage reset       # build a fresh DB with reference + demo data
python -m backend.manage run         # start the web app
```

Then open **http://127.0.0.1:8001** in your browser.

`reset` seeds a synthetic demo household so you can see every screen working —
statements, reconciliation, budgets, forecasts, KPIs. Poke around, then start over
empty when you're ready (below).

## Commands

Run any of these with `python -m backend.manage <command>`:

| Command  | What it does                                                        |
|----------|---------------------------------------------------------------------|
| `init`   | Create the database schema in `personal_erp.db`                     |
| `seed`   | Seed reference data (chart of accounts, dimensions, periods)        |
| `demo`   | Seed a synthetic demo household on top of the reference data        |
| `reset`  | Delete the DB and rebuild it clean: `init` + `seed` + `demo`        |
| `run`    | Launch the web app at http://127.0.0.1:8001                         |
| `backup` | Copy the DB to `backend/backups/personal_erp_<timestamp>.db`        |
| `restore`| Restore the DB from a backup file: `restore <path-to-backup>`       |

## Starting empty (your own books)

To keep the structure but drop the demo household's numbers:

```bash
rm backend/personal_erp.db
python -m backend.manage init
python -m backend.manage seed
python -m backend.manage run
```

That gives you the chart of accounts and dimensions with no transactions — a blank
ledger to start entering your own.

## Notes

- The database file is yours and stays local. Nothing here phones home.
- `backup` before any big change; `restore` if you regret it.
- `docs/operations.md` walks through the month-end close workflow (import →
  review → reconcile → close → report) and the CSV format for statements.
- Run the tests with `python -m pytest backend/tests` if you want to confirm the
  accounting logic before trusting it.
