# Personal ERP — Operating Guide

Local-first, server-rendered FastAPI + SQLite personal ERP. Everything runs on
your machine; no cloud services, no bank APIs.

## Install

Requires Python 3.11 or newer.

```bash
cd personal-erp
python3 -m venv .venv
./.venv/bin/pip install -r backend/requirements.txt
```

## Clean start (init + schema + seed + demo household)

```bash
./.venv/bin/python -m backend.manage reset
```

`reset` deletes the DB file and rebuilds it: schema, chart of accounts,
dimensions, 2026 periods, KPI definitions, then a demo household (opening
balances, two July statements imported/reviewed/posted/reconciled, a
depreciated vehicle, a student loan with interest accrual + payment split, a
budget, goals, commitments, a purchase request, and two forecast scenarios).
It prints the two statement reconciliations as a receipt.

Other commands: `init` (schema only), `seed` (reference data), `demo` (demo
household), `backup`, `restore <file>`, `run`.

## Start the app

```bash
./.venv/bin/python -m backend.manage run
# open http://127.0.0.1:8001
```

(The app auto-seeds a fresh DB on first request if none exists, so `run` works
on a clean checkout without a manual `reset`.)

## Run the tests

```bash
./.venv/bin/python -m pytest backend/tests -q
```

Covers posting invariants (balanced-only, immutability, required dimensions,
closed-period blocking, reversals), report reconciliation (trial balance /
income statement / balance sheet balance), every subledger (statements,
depreciation, debt split, budget-vs-actual, KPIs, scenario inheritance), and a
web smoke test that hits every route and drives the main workflows.

## Back up and restore

```bash
./.venv/bin/python -m backend.manage backup            # -> backend/backups/personal_erp_<ts>.db
./.venv/bin/python -m backend.manage restore backend/backups/personal_erp_<ts>.db
```

The database is a single SQLite file (`backend/personal_erp.db`); copying it is
a complete backup.

## Month-end close workflow

1. **Import statements** — `Statements` tab. Upload a CSV per account
   (`date,description,amount`; amount signed in dollars: checking deposit `+`,
   withdrawal `-`; card charge `+`, payment `-`). Set the opening balance.
2. **Review** — `Review` tab. Each imported line gets a suggested account from
   the matching rules. Choose the account (and cost center / service line /
   person for expense lines) and post; it becomes a balanced journal entry
   against the bank/card GL account. A card payment already on the checking
   statement is matched (Ignore) rather than double-posted.
3. **Reconcile** — `Statements` tab, per statement. Proves the GL balance of the
   account equals the statement's ending balance. Green = reconciled.
4. **Run month-end batch** — `Close` tab. Posts monthly straight-line
   depreciation, accrues debt interest, and refreshes KPIs for the period.
5. **Review reports** — `Statements & Reports` tab: trial balance, income
   statement, balance sheet (both flagged balanced), cash flow, net worth,
   spending by service line / cost center. `Budget` for budget-vs-actual.
6. **Close the period** — `Close` tab. `soft_closed` keeps reporting stable but
   still accepts postings; `hard_closed` rejects normal postings (corrections
   then require a reversal or a reopen with a reason).

## What is intentionally excluded

Plaid / live bank APIs, real-time sync, mobile, AI classification, receipt OCR,
complex tax filing, multi-user approvals, payroll, full investment-lot
accounting, advanced consolidation. Statement CSV ingestion is the source of
truth; a Plaid adapter would later feed the same normalized import tables.
PDF statement parsing is not built (would need a parser dependency); CSV is the
supported source format.
