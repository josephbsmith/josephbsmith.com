"""Financial + managerial reports. Every figure is a sum over posted journal
lines, so reports reconcile to the ledger by construction.

Statistical accounts (type='statistical', 9xxxx) are excluded from the balance
sheet / income statement; they are memo accounts and carry no double-entry
postings in v1.
"""
from __future__ import annotations
import calendar

# A reversed entry's original lines remain real historical postings; they are
# offset by the reversing entry. Both count toward balances. Draft/pending/void
# never posted, so they are excluded.
POSTED = "je.status IN ('posted','reversed')"


def month_bounds(label: str) -> tuple[str, str]:
    """'2026-07' -> ('2026-07-01', '2026-07-31')."""
    y, m = int(label[:4]), int(label[5:7])
    last = calendar.monthrange(y, m)[1]
    return f"{y:04d}-{m:02d}-01", f"{y:04d}-{m:02d}-{last:02d}"


def _sums(conn, *, start=None, end=None):
    """Per-account (Σdebit, Σcredit) over POSTED lines within [start, end]."""
    where = [POSTED]
    params: list = []
    if start:
        where.append("je.entry_date >= ?"); params.append(start)
    if end:
        where.append("je.entry_date <= ?"); params.append(end)
    rows = conn.execute(
        "SELECT a.id, a.code, a.name, a.type, a.normal_balance, a.is_contra, "
        "COALESCE(SUM(l.debit_cents),0) dr, COALESCE(SUM(l.credit_cents),0) cr "
        "FROM ledger_accounts a "
        "JOIN journal_entry_lines l ON l.account_id=a.id "
        "JOIN journal_entries je ON je.id=l.entry_id "
        "WHERE " + " AND ".join(where) + " GROUP BY a.id ORDER BY a.code",
        params,
    ).fetchall()
    return rows


def trial_balance(conn, *, end=None):
    rows = _sums(conn, end=end)
    out, td, tc = [], 0, 0
    for r in rows:
        net = r["dr"] - r["cr"]
        debit = net if net > 0 else 0
        credit = -net if net < 0 else 0
        td += debit; tc += credit
        out.append({"code": r["code"], "name": r["name"], "type": r["type"],
                    "debit": debit, "credit": credit})
    return {"rows": out, "total_debit": td, "total_credit": tc,
            "balanced": td == tc}


def _signed_balance(r) -> int:
    """Balance in the account's natural sign (positive = normal side)."""
    return (r["dr"] - r["cr"]) if r["normal_balance"] == "debit" else (r["cr"] - r["dr"])


def income_statement(conn, *, start, end):
    rows = _sums(conn, start=start, end=end)
    income, expense = [], []
    ti = te = 0
    for r in rows:
        bal = _signed_balance(r)
        item = {"code": r["code"], "name": r["name"], "amount": bal}
        if r["type"] == "income":
            income.append(item); ti += bal
        elif r["type"] == "expense":
            expense.append(item); te += bal
    return {"income": income, "expense": expense, "total_income": ti,
            "total_expense": te, "net_income": ti - te,
            "start": start, "end": end}


def net_income_to_date(conn, *, end) -> int:
    rows = _sums(conn, end=end)
    ni = 0
    for r in rows:
        if r["type"] == "income":
            ni += _signed_balance(r)
        elif r["type"] == "expense":
            ni -= _signed_balance(r)
    return ni


def balance_sheet(conn, *, end):
    rows = _sums(conn, end=end)
    assets, liabilities, equity = [], [], []
    ta = tl = teq = 0
    for r in rows:
        # Asset section uses raw (dr-cr) so contra accounts (accumulated
        # depreciation, credit-normal) correctly reduce the section.
        if r["type"] == "asset":
            bal = r["dr"] - r["cr"]
            assets.append({"code": r["code"], "name": r["name"], "amount": bal})
            ta += bal
        elif r["type"] == "liability":
            bal = r["cr"] - r["dr"]
            liabilities.append({"code": r["code"], "name": r["name"], "amount": bal})
            tl += bal
        elif r["type"] == "equity":
            bal = r["cr"] - r["dr"]
            equity.append({"code": r["code"], "name": r["name"], "amount": bal})
            teq += bal
    ni = net_income_to_date(conn, end=end)
    equity.append({"code": "—", "name": "Current & Retained Earnings",
                   "amount": ni})
    teq += ni
    return {"assets": assets, "liabilities": liabilities, "equity": equity,
            "total_assets": ta, "total_liabilities": tl, "total_equity": teq,
            "balanced": ta == tl + teq, "end": end}


def net_worth(conn, *, end):
    bs = balance_sheet(conn, end=end)
    return {"assets": bs["total_assets"], "liabilities": bs["total_liabilities"],
            "net_worth": bs["total_assets"] - bs["total_liabilities"], "end": end}


# ---------- cash flow (direct; reconciles to change in cash) ----------
CASH_CODES = ("10100", "10200", "10300", "10400")


def cash_flow(conn, *, start, end):
    """Direct method: net change in liquid cash accounts over the period,
    classified by the counterparty account type on each entry."""
    cash_ids = [r["id"] for r in conn.execute(
        "SELECT id FROM ledger_accounts WHERE code IN (%s)"
        % ",".join("?" * len(CASH_CODES)), CASH_CODES).fetchall()]
    if not cash_ids:
        return {"operating": 0, "investing": 0, "financing": 0, "net": 0,
                "start": start, "end": end}
    entries = conn.execute(
        "SELECT DISTINCT l.entry_id FROM journal_entry_lines l "
        "JOIN journal_entries je ON je.id=l.entry_id "
        "WHERE je.status IN ('posted','reversed') AND je.entry_date>=? AND je.entry_date<=? "
        "AND l.account_id IN (%s)" % ",".join("?" * len(cash_ids)),
        [start, end, *cash_ids],
    ).fetchall()
    buckets = {"operating": 0, "investing": 0, "financing": 0}
    for e in entries:
        lines = conn.execute(
            "SELECT l.account_id, l.debit_cents, l.credit_cents, a.type "
            "FROM journal_entry_lines l JOIN ledger_accounts a ON a.id=l.account_id "
            "WHERE l.entry_id=?", (e["entry_id"],)).fetchall()
        cash_delta = sum((l["debit_cents"] - l["credit_cents"])
                         for l in lines if l["account_id"] in cash_ids)
        # classify by the dominant non-cash counterparty type
        others = [l for l in lines if l["account_id"] not in cash_ids]
        ctype = _dominant_type(others)
        if ctype in ("income", "expense"):
            buckets["operating"] += cash_delta
        elif ctype == "asset":
            buckets["investing"] += cash_delta
        else:  # liability / equity
            buckets["financing"] += cash_delta
    net = sum(buckets.values())
    return {**buckets, "net": net, "start": start, "end": end}


def _dominant_type(lines) -> str:
    weight: dict[str, int] = {}
    for l in lines:
        weight[l["type"]] = weight.get(l["type"], 0) + l["debit_cents"] + l["credit_cents"]
    return max(weight, key=weight.get) if weight else "expense"


# ---------- dimensional / managerial ----------
DIM_TABLES = {
    "cost_center": ("cost_centers", "cost_center_id"),
    "service_line": ("service_lines", "service_line_id"),
    "person": ("people", "person_id"),
    "location": ("locations", "location_id"),
    "vendor": ("vendors", "vendor_id"),
    "funding_source": ("funding_sources", "funding_source_id"),
    "tax_treatment": ("tax_treatments", "tax_treatment_id"),
}


def spending_by(conn, dimension, *, start, end):
    """Expense totals grouped by a dimension (managerial view)."""
    table, col = DIM_TABLES[dimension]
    rows = conn.execute(
        f"SELECT d.name, COALESCE(SUM(l.debit_cents - l.credit_cents),0) amount "
        f"FROM journal_entry_lines l "
        f"JOIN journal_entries je ON je.id=l.entry_id "
        f"JOIN ledger_accounts a ON a.id=l.account_id "
        f"LEFT JOIN {table} d ON d.id=l.{col} "
        f"WHERE je.status IN ('posted','reversed') AND a.type='expense' "
        f"AND je.entry_date>=? AND je.entry_date<=? "
        f"GROUP BY l.{col} HAVING amount<>0 ORDER BY amount DESC",
        (start, end),
    ).fetchall()
    return [{"name": r["name"] or "(unassigned)", "amount": r["amount"]}
            for r in rows]


def account_activity(conn, account_id, *, start=None, end=None):
    where = ["je.status IN ('posted','reversed')", "l.account_id=?"]
    params: list = [account_id]
    if start:
        where.append("je.entry_date>=?"); params.append(start)
    if end:
        where.append("je.entry_date<=?"); params.append(end)
    rows = conn.execute(
        "SELECT je.id entry_id, je.entry_date, je.memo, l.debit_cents, "
        "l.credit_cents, l.memo line_memo FROM journal_entry_lines l "
        "JOIN journal_entries je ON je.id=l.entry_id "
        "WHERE " + " AND ".join(where) + " ORDER BY je.entry_date, je.id",
        params,
    ).fetchall()
    running = 0
    out = []
    nb = conn.execute("SELECT normal_balance FROM ledger_accounts WHERE id=?",
                      (account_id,)).fetchone()["normal_balance"]
    for r in rows:
        delta = (r["debit_cents"] - r["credit_cents"]) if nb == "debit" \
            else (r["credit_cents"] - r["debit_cents"])
        running += delta
        out.append({**dict(r), "balance": running})
    return out
