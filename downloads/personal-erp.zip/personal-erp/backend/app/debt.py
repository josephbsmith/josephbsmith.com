"""Phase 5: debt subledger, monthly interest accrual, payment principal/interest
split, payoff scenarios."""
from __future__ import annotations

from . import posting


def monthly_interest(conn, debt_id) -> int:
    d = conn.execute("SELECT * FROM debt_accounts WHERE id=?", (debt_id,)).fetchone()
    return round(d["current_principal_cents"] * d["annual_rate_bps"] / 10000 / 12)


def accrue_interest(conn, debt_id, period_label, entry_date, *, actor="system"):
    d = conn.execute("SELECT * FROM debt_accounts WHERE id=?", (debt_id,)).fetchone()
    exists = conn.execute(
        "SELECT 1 FROM interest_accruals WHERE debt_account_id=? AND period_label=?",
        (debt_id, period_label)).fetchone()
    if exists:
        raise posting.PostingError(
            f"interest already accrued for debt {debt_id} in {period_label}")
    amount = monthly_interest(conn, debt_id)
    accrued_acct = d["gl_accrued_interest_account_id"]
    if accrued_acct is None:
        accrued_acct = conn.execute(
            "SELECT id FROM ledger_accounts WHERE code='23000'").fetchone()["id"]
    dims = {"cost_center_id": d["cost_center_id"],
            "service_line_id": d["service_line_id"],
            "person_id": d["person_id"],
            "tax_treatment_id": d["tax_treatment_id"]}
    lines = [
        {"account_id": d["gl_interest_expense_account_id"], "debit_cents": amount,
         "credit_cents": 0, **dims, "memo": f"Interest accrual {d['name']}"},
        {"account_id": accrued_acct, "debit_cents": 0, "credit_cents": amount,
         "memo": f"Accrued interest {d['name']}"},
    ]
    entry_id = posting.post_entry(
        conn, entry_date, f"Interest accrual - {d['name']}", lines,
        source="interest", source_ref=f"debt{debt_id}:{period_label}", actor=actor)
    conn.execute(
        "INSERT INTO interest_accruals(debt_account_id, period_label, "
        "amount_cents, journal_entry_id) VALUES(?,?,?,?)",
        (debt_id, period_label, amount, entry_id))
    return entry_id


def accrued_balance(conn, debt_id) -> int:
    """Unpaid accrued interest = accrued - interest portion of payments."""
    acc = conn.execute(
        "SELECT COALESCE(SUM(amount_cents),0) s FROM interest_accruals "
        "WHERE debt_account_id=?", (debt_id,)).fetchone()["s"]
    paid = conn.execute(
        "SELECT COALESCE(SUM(interest_cents),0) s FROM debt_payments "
        "WHERE debt_account_id=?", (debt_id,)).fetchone()["s"]
    return acc - paid


def record_payment(conn, debt_id, payment_date, total_cents, cash_gl_account_id,
                   *, interest_cents=None, actor="user"):
    """Split a payment: interest clears accrued interest, remainder reduces
    principal. Dr AccruedInterest (interest) + Dr Principal (principal) / Cr Cash.
    """
    d = conn.execute("SELECT * FROM debt_accounts WHERE id=?", (debt_id,)).fetchone()
    if interest_cents is None:
        interest_cents = min(accrued_balance(conn, debt_id), total_cents)
    interest_cents = max(0, min(interest_cents, total_cents))
    principal_cents = total_cents - interest_cents
    accrued_acct = d["gl_accrued_interest_account_id"] or conn.execute(
        "SELECT id FROM ledger_accounts WHERE code='23000'").fetchone()["id"]
    lines = []
    if interest_cents:
        lines.append({"account_id": accrued_acct, "debit_cents": interest_cents,
                      "credit_cents": 0, "memo": f"Interest {d['name']}"})
    if principal_cents:
        lines.append({"account_id": d["gl_principal_account_id"],
                      "debit_cents": principal_cents, "credit_cents": 0,
                      "memo": f"Principal {d['name']}"})
    lines.append({"account_id": cash_gl_account_id, "debit_cents": 0,
                  "credit_cents": total_cents, "memo": f"Payment {d['name']}"})
    entry_id = posting.post_entry(
        conn, payment_date, f"Debt payment - {d['name']}", lines,
        source="debt_payment", source_ref=f"debt{debt_id}", actor=actor)
    conn.execute(
        "INSERT INTO debt_payments(debt_account_id, payment_date, total_cents, "
        "interest_cents, principal_cents, journal_entry_id) VALUES(?,?,?,?,?,?)",
        (debt_id, payment_date, total_cents, interest_cents, principal_cents, entry_id))
    conn.execute(
        "UPDATE debt_accounts SET current_principal_cents=current_principal_cents-? "
        "WHERE id=?", (principal_cents, debt_id))
    return {"entry_id": entry_id, "interest_cents": interest_cents,
            "principal_cents": principal_cents}


def amortization_schedule(conn, debt_id, monthly_payment_cents, max_months=600):
    """Project payoff. Returns list of {month, interest, principal, balance}."""
    d = conn.execute("SELECT * FROM debt_accounts WHERE id=?", (debt_id,)).fetchone()
    balance = d["current_principal_cents"]
    rate = d["annual_rate_bps"] / 10000 / 12
    out = []
    for m in range(1, max_months + 1):
        interest = round(balance * rate)
        principal = min(monthly_payment_cents - interest, balance)
        if principal <= 0:
            break  # payment doesn't cover interest
        balance -= principal
        out.append({"month": m, "interest_cents": interest,
                    "principal_cents": principal, "balance_cents": balance})
        if balance <= 0:
            break
    return out
