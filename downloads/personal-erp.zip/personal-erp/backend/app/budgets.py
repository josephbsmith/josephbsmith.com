"""Phase 6: budgets, budget-vs-actual, goals, commitments, purchase requests."""
from __future__ import annotations

from .reports import month_bounds, _sums, _signed_balance


def budget_vs_actual(conn, version_id, period_label):
    """Compare budget lines to actual posted activity for a month.

    Actual = signed balance of the account over the month (expenses positive when
    spent, income positive when earned)."""
    start, end = month_bounds(period_label)
    actual_by_acct = {r["id"]: _signed_balance(r)
                      for r in _sums(conn, start=start, end=end)}
    rows = conn.execute(
        "SELECT bl.account_id, a.code, a.name, a.type, "
        "SUM(bl.amount_cents) budget FROM budget_lines bl "
        "JOIN ledger_accounts a ON a.id=bl.account_id "
        "WHERE bl.budget_version_id=? AND bl.period_label=? "
        "GROUP BY bl.account_id ORDER BY a.code",
        (version_id, period_label)).fetchall()
    out, tb, ta = [], 0, 0
    seen = set()
    for r in rows:
        seen.add(r["account_id"])
        actual = actual_by_acct.get(r["account_id"], 0)
        variance = actual - r["budget"]
        tb += r["budget"]; ta += actual
        out.append({"code": r["code"], "name": r["name"], "type": r["type"],
                    "budget": r["budget"], "actual": actual, "variance": variance})
    return {"rows": out, "total_budget": tb, "total_actual": ta,
            "total_variance": ta - tb, "period": period_label}


def commitment_summary(conn):
    rows = conn.execute(
        "SELECT c.*, v.name vendor_name FROM commitments c "
        "LEFT JOIN vendors v ON v.id=c.vendor_id "
        "WHERE c.status IN ('planned','approved','committed') "
        "ORDER BY c.due_date").fetchall()
    total = sum(r["amount_cents"] for r in rows)
    by_month: dict[str, int] = {}
    for r in rows:
        mk = r["due_date"][:7]
        by_month[mk] = by_month.get(mk, 0) + r["amount_cents"]
    return {"rows": [dict(r) for r in rows], "total_cents": total,
            "by_month": by_month}
