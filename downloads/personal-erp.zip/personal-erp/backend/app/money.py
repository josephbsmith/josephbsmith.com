"""Integer-cents money helpers. Parse at the edge, format at the edge."""


def to_cents(dollars) -> int:
    """'1,234.56' or 1234.56 -> 123456. Rounds to nearest cent."""
    if dollars is None or dollars == "":
        return 0
    s = str(dollars).replace(",", "").replace("$", "").strip()
    neg = s.startswith("(") and s.endswith(")")
    s = s.strip("()")
    val = int(round(float(s) * 100))
    return -val if neg else val


def fmt(cents: int) -> str:
    """123456 -> '1,234.56' (accounting; negatives parenthesized)."""
    cents = int(cents or 0)
    sign = cents < 0
    d, c = divmod(abs(cents), 100)
    body = f"{d:,}.{c:02d}"
    return f"({body})" if sign else body
