"""Phase 4: fixed assets, straight-line depreciation, replacement forecast."""
from __future__ import annotations

from . import posting


def _acct_id(conn, code: str) -> int:
    return conn.execute("SELECT id FROM ledger_accounts WHERE code=?",
                        (code,)).fetchone()["id"]


def accumulated(conn, asset_id) -> int:
    row = conn.execute(
        "SELECT COALESCE(SUM(amount_cents),0) s FROM depreciation_runs "
        "WHERE asset_id=?", (asset_id,)).fetchone()
    return row["s"]


def book_value(conn, asset_id) -> int:
    a = conn.execute("SELECT * FROM assets WHERE id=?", (asset_id,)).fetchone()
    return a["cost_cents"] - accumulated(conn, asset_id)


def monthly_amount(conn, asset_id) -> int:
    a = conn.execute("SELECT * FROM assets WHERE id=?", (asset_id,)).fetchone()
    life = a["useful_life_months"]
    if not life:
        return 0
    base = a["cost_cents"] - a["salvage_cents"]
    return round(base / life)


def run_depreciation(conn, asset_id, period_label, entry_date, *, actor="system"):
    """Post one month of straight-line depreciation for an asset."""
    a = conn.execute("SELECT * FROM assets WHERE id=?", (asset_id,)).fetchone()
    if a["asset_class_id"] is None:
        raise posting.PostingError(f"asset {asset_id} has no class; cannot depreciate")
    cls = conn.execute("SELECT * FROM asset_classes WHERE id=?",
                       (a["asset_class_id"],)).fetchone()
    exists = conn.execute(
        "SELECT 1 FROM depreciation_runs WHERE asset_id=? AND period_label=?",
        (asset_id, period_label)).fetchone()
    if exists:
        raise posting.PostingError(
            f"depreciation already run for asset {asset_id} in {period_label}")
    amount = monthly_amount(conn, asset_id)
    # don't depreciate below salvage
    depreciable_left = (a["cost_cents"] - a["salvage_cents"]) - accumulated(conn, asset_id)
    amount = max(0, min(amount, depreciable_left))
    if amount == 0:
        raise posting.PostingError(f"asset {asset_id} fully depreciated")
    dims = {"cost_center_id": a["cost_center_id"],
            "service_line_id": a["service_line_id"],
            "person_id": a["person_id"], "asset_id": asset_id}
    lines = [
        {"account_id": cls["deprec_expense_account_id"], "debit_cents": amount,
         "credit_cents": 0, **dims, "memo": f"Depreciation {a['name']}"},
        {"account_id": cls["accum_deprec_account_id"], "debit_cents": 0,
         "credit_cents": amount, "asset_id": asset_id,
         "memo": f"Accum deprec {a['name']}"},
    ]
    entry_id = posting.post_entry(
        conn, entry_date, f"Monthly depreciation - {a['name']}", lines,
        source="depreciation", source_ref=f"asset{asset_id}:{period_label}",
        actor=actor)
    conn.execute(
        "INSERT INTO depreciation_runs(asset_id, period_label, amount_cents, "
        "journal_entry_id) VALUES(?,?,?,?)",
        (asset_id, period_label, amount, entry_id))
    return entry_id


def run_all(conn, period_label, entry_date, *, actor="system") -> list[int]:
    ids = [r["id"] for r in conn.execute(
        "SELECT id FROM assets WHERE is_active=1 AND asset_class_id IS NOT NULL "
        "AND disposal_date IS NULL").fetchall()]
    posted = []
    for aid in ids:
        already = conn.execute(
            "SELECT 1 FROM depreciation_runs WHERE asset_id=? AND period_label=?",
            (aid, period_label)).fetchone()
        if already or book_value(conn, aid) <= conn.execute(
                "SELECT salvage_cents FROM assets WHERE id=?", (aid,)
        ).fetchone()["salvage_cents"]:
            continue
        posted.append(run_depreciation(conn, aid, period_label, entry_date, actor=actor))
    return posted


def replacement_forecast(conn):
    """Months of remaining life and projected replacement need per asset."""
    out = []
    for a in conn.execute("SELECT * FROM assets WHERE is_active=1").fetchall():
        bv = book_value(conn, a["id"])
        monthly = monthly_amount(conn, a["id"])
        months_left = (bv - a["salvage_cents"]) // monthly if monthly else None
        out.append({
            "id": a["id"], "name": a["name"], "cost_cents": a["cost_cents"],
            "accumulated_cents": accumulated(conn, a["id"]),
            "book_value_cents": bv,
            "replacement_cost_cents": a["replacement_cost_cents"] or a["cost_cents"],
            "months_remaining": months_left,
        })
    return out
