"""Phase 3: month-end statement ingestion, review, matching, posting,
reconciliation. Source-agnostic normalized import tables so a future Plaid
adapter can feed the same pipeline.

amount_cents on an imported line = signed change to the bank/card GL account in
its NATURAL (normal-balance) sign: checking deposit +, withdrawal -; credit-card
charge +, payment -.
"""
from __future__ import annotations
import csv
import io

from .db import audit
from . import posting
from .money import to_cents


def parse_csv(text: str) -> list[dict]:
    """CSV with headers date,description,amount (amount in dollars, signed)."""
    lines = []
    reader = csv.DictReader(io.StringIO(text.strip()))
    for row in reader:
        row = {(k or "").strip().lower(): v for k, v in row.items()}
        lines.append({
            "txn_date": row["date"].strip(),
            "description": row["description"].strip(),
            "amount_cents": to_cents(row["amount"]),
        })
    return lines


def create_statement(conn, bank_account_id, period_label, start, end,
                     opening_cents, lines, *, filename=None, raw_text=None,
                     actor="user") -> int:
    closing = opening_cents + sum(l["amount_cents"] for l in lines)
    cur = conn.execute(
        "INSERT INTO month_end_statements(bank_account_id, period_label, "
        "statement_start, statement_end, opening_balance_cents, "
        "closing_balance_cents, filename, raw_text) VALUES(?,?,?,?,?,?,?,?)",
        (bank_account_id, period_label, start, end, opening_cents, closing,
         filename, raw_text),
    )
    stmt_id = cur.lastrowid
    for l in lines:
        conn.execute(
            "INSERT INTO imported_transactions(statement_id, txn_date, "
            "description, amount_cents) VALUES(?,?,?,?)",
            (stmt_id, l["txn_date"], l["description"], l["amount_cents"]),
        )
    audit(conn, "month_end_statement", stmt_id, "import",
          new={"lines": len(lines), "closing_cents": closing}, actor=actor)
    return stmt_id


def suggest(conn, statement_id) -> int:
    """Apply matching_rules to unreviewed lines. Returns count matched."""
    rules = conn.execute(
        "SELECT * FROM matching_rules ORDER BY priority").fetchall()
    txns = conn.execute(
        "SELECT * FROM imported_transactions WHERE statement_id=? "
        "AND status='unreviewed'", (statement_id,)).fetchall()
    matched = 0
    for t in txns:
        desc = t["description"].lower()
        for r in rules:
            if r["pattern"].lower() in desc:
                conn.execute(
                    "UPDATE imported_transactions SET suggested_account_id=?, "
                    "matched_rule_id=? WHERE id=?",
                    (r["account_id"], r["id"], t["id"]))
                matched += 1
                break
    return matched


def _rule_dims(conn, txn) -> dict:
    if not txn["matched_rule_id"]:
        return {}
    r = conn.execute("SELECT * FROM matching_rules WHERE id=?",
                     (txn["matched_rule_id"],)).fetchone()
    if r is None:
        return {}
    return {k: r[k] for k in ("cost_center_id", "service_line_id", "person_id",
                              "vendor_id")}


def post_transaction(conn, txn_id, counterparty_account_id, *, dims=None,
                     counterparty_is_bank=False, actor="user") -> int:
    """Post one imported line as a balanced journal entry.

    counterparty_account_id = the GL account for the non-bank side (an expense,
    income, or - for a card payment - the paying cash account).
    """
    t = conn.execute("SELECT * FROM imported_transactions WHERE id=?",
                     (txn_id,)).fetchone()
    if t is None:
        raise posting.PostingError(f"imported txn {txn_id} not found")
    if t["status"] == "posted":
        raise posting.PostingError(f"txn {txn_id} already posted")
    stmt = conn.execute("SELECT * FROM month_end_statements WHERE id=?",
                        (t["statement_id"],)).fetchone()
    ba = conn.execute("SELECT * FROM bank_accounts WHERE id=?",
                     (stmt["bank_account_id"],)).fetchone()
    bank_acct = conn.execute("SELECT * FROM ledger_accounts WHERE id=?",
                            (ba["gl_account_id"],)).fetchone()
    amount = t["amount_cents"]
    a = abs(amount)
    # bank side in its normal sign
    if bank_acct["normal_balance"] == "debit":
        bank_dr, bank_cr = (a, 0) if amount > 0 else (0, a)
    else:
        bank_cr, bank_dr = (a, 0) if amount > 0 else (0, a)
    dims = dims or {}
    bank_line = {"account_id": bank_acct["id"], "debit_cents": bank_dr,
                 "credit_cents": bank_cr, "memo": t["description"]}
    cp_line = {"account_id": counterparty_account_id, "debit_cents": bank_cr,
               "credit_cents": bank_dr, "memo": t["description"], **dims}
    entry_id = posting.post_entry(
        conn, t["txn_date"], t["description"], [bank_line, cp_line],
        source="import", source_ref=f"stmt{t['statement_id']}:txn{txn_id}",
        actor=actor)
    conn.execute(
        "UPDATE imported_transactions SET status='posted', journal_entry_id=? "
        "WHERE id=?", (entry_id, txn_id))
    return entry_id


def gl_balance_natural(conn, gl_account_id, *, end) -> int:
    """Account balance in its normal sign, all posted lines through `end`."""
    row = conn.execute(
        "SELECT a.normal_balance, COALESCE(SUM(l.debit_cents),0) dr, "
        "COALESCE(SUM(l.credit_cents),0) cr FROM ledger_accounts a "
        "LEFT JOIN journal_entry_lines l ON l.account_id=a.id "
        "LEFT JOIN journal_entries je ON je.id=l.entry_id "
        "  AND je.status IN ('posted','reversed') AND je.entry_date<=? "
        "WHERE a.id=?", (end, gl_account_id)).fetchone()
    return (row["dr"] - row["cr"]) if row["normal_balance"] == "debit" \
        else (row["cr"] - row["dr"])


def reconcile(conn, statement_id, *, actor="user") -> dict:
    stmt = conn.execute("SELECT * FROM month_end_statements WHERE id=?",
                       (statement_id,)).fetchone()
    ba = conn.execute("SELECT * FROM bank_accounts WHERE id=?",
                     (stmt["bank_account_id"],)).fetchone()
    gl = gl_balance_natural(conn, ba["gl_account_id"], end=stmt["statement_end"])
    diff = gl - stmt["closing_balance_cents"]
    reconciled = 1 if diff == 0 else 0
    conn.execute(
        "INSERT INTO bank_reconciliations(statement_id, gl_balance_cents, "
        "statement_balance_cents, difference_cents, is_reconciled) "
        "VALUES(?,?,?,?,?)",
        (statement_id, gl, stmt["closing_balance_cents"], diff, reconciled))
    if reconciled:
        conn.execute("UPDATE month_end_statements SET status='reconciled' "
                     "WHERE id=?", (statement_id,))
    audit(conn, "month_end_statement", statement_id, "reconcile",
          new={"gl": gl, "statement": stmt["closing_balance_cents"],
               "difference": diff}, actor=actor)
    return {"gl_balance_cents": gl,
            "statement_balance_cents": stmt["closing_balance_cents"],
            "difference_cents": diff, "reconciled": bool(reconciled)}
