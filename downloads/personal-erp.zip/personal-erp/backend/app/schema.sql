-- Personal ERP schema (single-file init; greenfield).
-- Money is INTEGER cents everywhere. No floats for money.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

-- One household / one ledger (SINGLE_HOUSEHOLD). Kept as tables so multi-entity
-- is a later additive change, not a rewrite.
CREATE TABLE IF NOT EXISTS households (
  id   INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  base_currency TEXT NOT NULL DEFAULT 'USD'
);

-- ---------- Accounting core ----------
CREATE TABLE IF NOT EXISTS ledger_accounts (
  id            INTEGER PRIMARY KEY,
  code          TEXT NOT NULL UNIQUE,          -- 5-digit
  name          TEXT NOT NULL,
  type          TEXT NOT NULL,                 -- asset/liability/equity/income/expense/statistical
  normal_balance TEXT NOT NULL,                -- debit/credit
  is_contra     INTEGER NOT NULL DEFAULT 0,
  requires_dimensions INTEGER NOT NULL DEFAULT 0,
  is_active     INTEGER NOT NULL DEFAULT 1,
  parent_code   TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS accounting_periods (
  id         INTEGER PRIMARY KEY,
  year       INTEGER NOT NULL,
  month      INTEGER NOT NULL,
  label      TEXT NOT NULL,                    -- e.g. 2026-07
  start_date TEXT NOT NULL,
  end_date   TEXT NOT NULL,
  status     TEXT NOT NULL DEFAULT 'open',     -- open/soft_closed/hard_closed/reopened
  closed_at  TEXT,
  reopened_reason TEXT,
  UNIQUE(year, month)
);

CREATE TABLE IF NOT EXISTS journal_entries (
  id          INTEGER PRIMARY KEY,
  entry_date  TEXT NOT NULL,
  period_id   INTEGER NOT NULL REFERENCES accounting_periods(id),
  memo        TEXT NOT NULL DEFAULT '',
  status      TEXT NOT NULL DEFAULT 'draft',   -- draft/pending/posted/reversed/voided
  source      TEXT NOT NULL DEFAULT 'manual',  -- manual/import/depreciation/interest/reversal/...
  source_ref  TEXT,
  reverses_entry_id  INTEGER REFERENCES journal_entries(id),
  reversed_by_entry_id INTEGER REFERENCES journal_entries(id),
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  posted_at   TEXT
);

CREATE TABLE IF NOT EXISTS journal_entry_lines (
  id            INTEGER PRIMARY KEY,
  entry_id      INTEGER NOT NULL REFERENCES journal_entries(id),
  account_id    INTEGER NOT NULL REFERENCES ledger_accounts(id),
  debit_cents   INTEGER NOT NULL DEFAULT 0,
  credit_cents  INTEGER NOT NULL DEFAULT 0,
  vendor_id        INTEGER REFERENCES vendors(id),
  location_id      INTEGER REFERENCES locations(id),
  cost_center_id   INTEGER REFERENCES cost_centers(id),
  service_line_id  INTEGER REFERENCES service_lines(id),
  person_id        INTEGER REFERENCES people(id),
  asset_id         INTEGER REFERENCES assets(id),
  funding_source_id INTEGER REFERENCES funding_sources(id),
  tax_treatment_id INTEGER REFERENCES tax_treatments(id),
  memo          TEXT NOT NULL DEFAULT '',
  CHECK (debit_cents >= 0 AND credit_cents >= 0),
  CHECK (NOT (debit_cents > 0 AND credit_cents > 0)),
  CHECK (debit_cents > 0 OR credit_cents > 0)
);
CREATE INDEX IF NOT EXISTS idx_jel_entry ON journal_entry_lines(entry_id);
CREATE INDEX IF NOT EXISTS idx_jel_account ON journal_entry_lines(account_id);

CREATE TABLE IF NOT EXISTS audit_events (
  id          INTEGER PRIMARY KEY,
  entity_type TEXT NOT NULL,
  entity_id   INTEGER,
  action      TEXT NOT NULL,
  old_value   TEXT,
  new_value   TEXT,
  actor       TEXT NOT NULL DEFAULT 'system',
  reason      TEXT,
  source      TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------- Dimensions ----------
CREATE TABLE IF NOT EXISTS people (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, is_active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS locations (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, is_active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS cost_centers (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, is_active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS service_lines (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, is_active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS funding_sources (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, is_active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS tax_treatments (
  id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, is_active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS vendors (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  is_active INTEGER NOT NULL DEFAULT 1,
  default_account_id       INTEGER REFERENCES ledger_accounts(id),
  default_cost_center_id   INTEGER REFERENCES cost_centers(id),
  default_service_line_id  INTEGER REFERENCES service_lines(id),
  default_location_id      INTEGER REFERENCES locations(id),
  default_person_id        INTEGER REFERENCES people(id),
  default_tax_treatment_id INTEGER REFERENCES tax_treatments(id)
);

-- Per-account required-dimension overrides beyond the policy default.
CREATE TABLE IF NOT EXISTS account_dimension_rules (
  id INTEGER PRIMARY KEY,
  account_id INTEGER NOT NULL REFERENCES ledger_accounts(id),
  dimension  TEXT NOT NULL   -- cost_center_id/service_line_id/person_id/...
);

-- ---------- Banking / statement ingestion (Phase 3) ----------
CREATE TABLE IF NOT EXISTS bank_accounts (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  kind TEXT NOT NULL,                 -- checking/savings/credit_card/loan/investment
  gl_account_id INTEGER NOT NULL REFERENCES ledger_accounts(id),
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS month_end_statements (
  id INTEGER PRIMARY KEY,
  bank_account_id INTEGER NOT NULL REFERENCES bank_accounts(id),
  period_label TEXT NOT NULL,          -- e.g. 2026-07
  statement_start TEXT NOT NULL,
  statement_end   TEXT NOT NULL,
  opening_balance_cents INTEGER NOT NULL,
  closing_balance_cents INTEGER NOT NULL,
  filename TEXT,
  raw_text TEXT,                       -- stored source document text
  status TEXT NOT NULL DEFAULT 'imported',  -- imported/reconciled
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS imported_transactions (
  id INTEGER PRIMARY KEY,
  statement_id INTEGER NOT NULL REFERENCES month_end_statements(id),
  txn_date TEXT NOT NULL,
  description TEXT NOT NULL,
  -- signed from the bank_account's perspective (deposit +, withdrawal -), in cents
  amount_cents INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'unreviewed', -- unreviewed/reviewed/posted/ignored
  suggested_account_id INTEGER REFERENCES ledger_accounts(id),
  journal_entry_id INTEGER REFERENCES journal_entries(id),
  matched_rule_id INTEGER
);
CREATE INDEX IF NOT EXISTS idx_imp_stmt ON imported_transactions(statement_id);

CREATE TABLE IF NOT EXISTS matching_rules (
  id INTEGER PRIMARY KEY,
  pattern TEXT NOT NULL,               -- case-insensitive substring on description
  account_id INTEGER NOT NULL REFERENCES ledger_accounts(id),
  vendor_id INTEGER REFERENCES vendors(id),
  cost_center_id INTEGER REFERENCES cost_centers(id),
  service_line_id INTEGER REFERENCES service_lines(id),
  person_id INTEGER REFERENCES people(id),
  priority INTEGER NOT NULL DEFAULT 100
);

CREATE TABLE IF NOT EXISTS bank_reconciliations (
  id INTEGER PRIMARY KEY,
  statement_id INTEGER NOT NULL REFERENCES month_end_statements(id),
  gl_balance_cents INTEGER NOT NULL,
  statement_balance_cents INTEGER NOT NULL,
  difference_cents INTEGER NOT NULL,
  is_reconciled INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ---------- Fixed assets (Phase 4) ----------
CREATE TABLE IF NOT EXISTS asset_classes (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  default_useful_life_months INTEGER NOT NULL,
  asset_account_id INTEGER NOT NULL REFERENCES ledger_accounts(id),
  accum_deprec_account_id INTEGER NOT NULL REFERENCES ledger_accounts(id),
  deprec_expense_account_id INTEGER NOT NULL REFERENCES ledger_accounts(id)
);

CREATE TABLE IF NOT EXISTS assets (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  asset_class_id INTEGER REFERENCES asset_classes(id),
  parent_asset_id INTEGER REFERENCES assets(id),   -- componentization
  acquisition_date TEXT,
  in_service_date TEXT,
  cost_cents INTEGER NOT NULL DEFAULT 0,
  salvage_cents INTEGER NOT NULL DEFAULT 0,
  useful_life_months INTEGER,
  method TEXT NOT NULL DEFAULT 'straight_line',
  cost_center_id INTEGER REFERENCES cost_centers(id),
  service_line_id INTEGER REFERENCES service_lines(id),
  location_id INTEGER REFERENCES locations(id),
  person_id INTEGER REFERENCES people(id),
  market_value_cents INTEGER,
  replacement_cost_cents INTEGER,
  disposal_date TEXT,
  disposal_proceeds_cents INTEGER,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS depreciation_runs (
  id INTEGER PRIMARY KEY,
  asset_id INTEGER NOT NULL REFERENCES assets(id),
  period_label TEXT NOT NULL,
  amount_cents INTEGER NOT NULL,
  journal_entry_id INTEGER REFERENCES journal_entries(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(asset_id, period_label)
);

CREATE TABLE IF NOT EXISTS maintenance_events (
  id INTEGER PRIMARY KEY,
  asset_id INTEGER NOT NULL REFERENCES assets(id),
  event_date TEXT NOT NULL,
  description TEXT NOT NULL,
  cost_cents INTEGER NOT NULL DEFAULT 0
);

-- ---------- Debt (Phase 5) ----------
CREATE TABLE IF NOT EXISTS debt_accounts (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  kind TEXT NOT NULL,                  -- mortgage/auto/student/personal/credit_card
  gl_principal_account_id INTEGER NOT NULL REFERENCES ledger_accounts(id),
  gl_interest_expense_account_id INTEGER NOT NULL REFERENCES ledger_accounts(id),
  gl_accrued_interest_account_id INTEGER REFERENCES ledger_accounts(id),
  original_principal_cents INTEGER NOT NULL,
  current_principal_cents INTEGER NOT NULL,
  scheduled_payment_cents INTEGER,
  annual_rate_bps INTEGER NOT NULL,    -- basis points (e.g. 6.5% = 650)
  term_months INTEGER,
  origination_date TEXT,
  cost_center_id INTEGER REFERENCES cost_centers(id),
  service_line_id INTEGER REFERENCES service_lines(id),
  person_id INTEGER REFERENCES people(id),
  tax_treatment_id INTEGER REFERENCES tax_treatments(id),
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS interest_accruals (
  id INTEGER PRIMARY KEY,
  debt_account_id INTEGER NOT NULL REFERENCES debt_accounts(id),
  period_label TEXT NOT NULL,
  amount_cents INTEGER NOT NULL,
  journal_entry_id INTEGER REFERENCES journal_entries(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(debt_account_id, period_label)
);

CREATE TABLE IF NOT EXISTS debt_payments (
  id INTEGER PRIMARY KEY,
  debt_account_id INTEGER NOT NULL REFERENCES debt_accounts(id),
  payment_date TEXT NOT NULL,
  total_cents INTEGER NOT NULL,
  interest_cents INTEGER NOT NULL,
  principal_cents INTEGER NOT NULL,
  journal_entry_id INTEGER REFERENCES journal_entries(id)
);

-- ---------- Planning: budgets, goals, commitments, purchases (Phase 6) ----------
CREATE TABLE IF NOT EXISTS budget_versions (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  year INTEGER NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS budget_lines (
  id INTEGER PRIMARY KEY,
  budget_version_id INTEGER NOT NULL REFERENCES budget_versions(id),
  account_id INTEGER NOT NULL REFERENCES ledger_accounts(id),
  period_label TEXT NOT NULL,          -- YYYY-MM
  cost_center_id INTEGER REFERENCES cost_centers(id),
  service_line_id INTEGER REFERENCES service_lines(id),
  person_id INTEGER REFERENCES people(id),
  amount_cents INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_budget_line ON budget_lines(budget_version_id, period_label);

CREATE TABLE IF NOT EXISTS goals (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  target_cents INTEGER NOT NULL,
  current_cents INTEGER NOT NULL DEFAULT 0,
  target_date TEXT,
  gl_account_id INTEGER REFERENCES ledger_accounts(id),
  status TEXT NOT NULL DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS commitments (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  vendor_id INTEGER REFERENCES vendors(id),
  amount_cents INTEGER NOT NULL,
  due_date TEXT NOT NULL,
  cost_center_id INTEGER REFERENCES cost_centers(id),
  service_line_id INTEGER REFERENCES service_lines(id),
  status TEXT NOT NULL DEFAULT 'planned'  -- planned/approved/committed/fulfilled/cancelled/expired
);

CREATE TABLE IF NOT EXISTS purchase_requests (
  id INTEGER PRIMARY KEY,
  item TEXT NOT NULL,
  vendor_id INTEGER REFERENCES vendors(id),
  estimated_cents INTEGER NOT NULL,
  desired_date TEXT,
  cost_center_id INTEGER REFERENCES cost_centers(id),
  service_line_id INTEGER REFERENCES service_lines(id),
  funding_source_id INTEGER REFERENCES funding_sources(id),
  capitalize INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'requested'  -- requested/approved/ordered/received/rejected
);

-- ---------- Forecasting / scenarios (Phase 7) ----------
CREATE TABLE IF NOT EXISTS scenario_versions (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  base_scenario_id INTEGER REFERENCES scenario_versions(id),
  description TEXT,
  horizon_months INTEGER NOT NULL DEFAULT 12,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS forecast_assumptions (
  id INTEGER PRIMARY KEY,
  scenario_id INTEGER NOT NULL REFERENCES scenario_versions(id),
  key TEXT NOT NULL,                    -- e.g. monthly_income_cents, monthly_expense_cents, income_growth_bps
  value TEXT NOT NULL,
  UNIQUE(scenario_id, key)
);

-- ---------- KPIs (Phase 8) ----------
CREATE TABLE IF NOT EXISTS kpi_definitions (
  id INTEGER PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  formula TEXT NOT NULL,
  unit TEXT NOT NULL DEFAULT 'ratio',  -- ratio/percent/currency/months
  warning_threshold REAL,
  target_threshold REAL,
  explanation TEXT
);

CREATE TABLE IF NOT EXISTS kpi_results (
  id INTEGER PRIMARY KEY,
  kpi_code TEXT NOT NULL REFERENCES kpi_definitions(code),
  period_label TEXT NOT NULL,
  value REAL NOT NULL,
  computed_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(kpi_code, period_label)
);
