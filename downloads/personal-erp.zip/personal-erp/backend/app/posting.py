"""Posting engine. Enforces the accounting invariants (see DECISIONS.md):

- debits == credits, both > 0            (no unbalanced entries)
- each line carries exactly one of dr/cr (non-negative)
- accounts active; required dims present
- posting date resolves to a period; hard-closed periods reject normal postings
- posted entries are immutable; corrections are reversals
- every material change writes an audit_event
"""
from __future__ import annotations

from .db import audit
from . import policy

REQUIRED = policy.REQUIRED_DIMS
LINE_DIM_FIELDS = (
    "vendor_id", "location_id", "cost_center_id", "service_line_id",
    "person_id", "asset_id", "funding_source_id", "tax_treatment_id",
)


class PostingError(ValueError):
    """Raised when an accounting invariant would be violated."""


def period_for_date(conn, entry_date: str):
    """entry_date 'YYYY-MM-DD' -> accounting_periods row, or None."""
    year, month = int(entry_date[0:4]), int(entry_date[5:7])
    return conn.execute(
        "SELECT * FROM accounting_periods WHERE year=? AND month=?",
        (year, month),
    ).fetchone()


def _account(conn, account_id: int):
    row = conn.execute(
        "SELECT * FROM ledger_accounts WHERE id=?", (account_id,)
    ).fetchone()
    if row is None:
        raise PostingError(f"account {account_id} does not exist")
    return row


def _extra_required_dims(conn, account_id: int) -> set[str]:
    rows = conn.execute(
        "SELECT dimension FROM account_dimension_rules WHERE account_id=?",
        (account_id,),
    ).fetchall()
    return {r["dimension"] for r in rows}


def validate_lines(conn, lines: list[dict]) -> None:
    if len(lines) < 2:
        raise PostingError("a journal entry needs at least two lines")
    total_dr = total_cr = 0
    for i, ln in enumerate(lines, 1):
        dr = int(ln.get("debit_cents") or 0)
        cr = int(ln.get("credit_cents") or 0)
        if dr < 0 or cr < 0:
            raise PostingError(f"line {i}: amounts must be non-negative")
        if (dr > 0) == (cr > 0):
            raise PostingError(
                f"line {i}: each line must carry exactly one of debit or credit"
            )
        acct = _account(conn, int(ln["account_id"]))
        if not acct["is_active"]:
            raise PostingError(f"line {i}: account {acct['code']} is inactive")
        required = set()
        if acct["requires_dimensions"]:
            required |= set(REQUIRED)
        required |= _extra_required_dims(conn, acct["id"])
        for dim in required:
            if not ln.get(dim):
                raise PostingError(
                    f"line {i}: account {acct['code']} requires {dim}"
                )
        total_dr += dr
        total_cr += cr
    if total_dr != total_cr:
        raise PostingError(
            f"entry does not balance: debits {total_dr} != credits {total_cr}"
        )
    if total_dr == 0:
        raise PostingError("entry total is zero")


def create_draft(conn, entry_date, memo, lines, *, source="manual",
                 source_ref=None, actor="user") -> int:
    validate_lines(conn, lines)
    period = period_for_date(conn, entry_date)
    if period is None:
        raise PostingError(f"no accounting period contains {entry_date}")
    cur = conn.execute(
        "INSERT INTO journal_entries(entry_date, period_id, memo, status, "
        "source, source_ref) VALUES(?,?,?,'draft',?,?)",
        (entry_date, period["id"], memo, source, source_ref),
    )
    entry_id = cur.lastrowid
    _insert_lines(conn, entry_id, lines)
    audit(conn, "journal_entry", entry_id, "create_draft", new={"memo": memo},
          actor=actor, source=source)
    return entry_id


def _insert_lines(conn, entry_id, lines) -> None:
    for ln in lines:
        conn.execute(
            "INSERT INTO journal_entry_lines(entry_id, account_id, debit_cents, "
            "credit_cents, vendor_id, location_id, cost_center_id, "
            "service_line_id, person_id, asset_id, funding_source_id, "
            "tax_treatment_id, memo) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                entry_id, int(ln["account_id"]),
                int(ln.get("debit_cents") or 0), int(ln.get("credit_cents") or 0),
                ln.get("vendor_id"), ln.get("location_id"),
                ln.get("cost_center_id"), ln.get("service_line_id"),
                ln.get("person_id"), ln.get("asset_id"),
                ln.get("funding_source_id"), ln.get("tax_treatment_id"),
                ln.get("memo", ""),
            ),
        )


def post_draft(conn, entry_id, *, actor="user", allow_closed=False,
               reason=None) -> None:
    entry = conn.execute(
        "SELECT * FROM journal_entries WHERE id=?", (entry_id,)
    ).fetchone()
    if entry is None:
        raise PostingError(f"entry {entry_id} not found")
    if entry["status"] != "draft":
        raise PostingError(
            f"only draft entries can be posted (entry {entry_id} is "
            f"{entry['status']})"
        )
    period = conn.execute(
        "SELECT * FROM accounting_periods WHERE id=?", (entry["period_id"],)
    ).fetchone()
    if period["status"] == "hard_closed" and not allow_closed:
        raise PostingError(
            f"period {period['label']} is hard-closed; normal postings rejected"
        )
    # re-validate lines from storage (defensive)
    lines = [dict(r) for r in conn.execute(
        "SELECT * FROM journal_entry_lines WHERE entry_id=?", (entry_id,)
    ).fetchall()]
    validate_lines(conn, lines)
    conn.execute(
        "UPDATE journal_entries SET status='posted', posted_at=datetime('now') "
        "WHERE id=?", (entry_id,)
    )
    audit(conn, "journal_entry", entry_id, "post",
          old={"status": "draft"}, new={"status": "posted"},
          actor=actor, reason=reason, source=entry["source"])


def post_entry(conn, entry_date, memo, lines, *, source="manual",
               source_ref=None, actor="user", allow_closed=False,
               reason=None) -> int:
    """Create and immediately post. Returns entry id."""
    entry_id = create_draft(conn, entry_date, memo, lines, source=source,
                            source_ref=source_ref, actor=actor)
    post_draft(conn, entry_id, actor=actor, allow_closed=allow_closed,
               reason=reason)
    return entry_id


def assert_editable(conn, entry_id) -> None:
    entry = conn.execute(
        "SELECT status FROM journal_entries WHERE id=?", (entry_id,)
    ).fetchone()
    if entry is None:
        raise PostingError(f"entry {entry_id} not found")
    if entry["status"] in ("posted", "reversed", "voided"):
        raise PostingError(
            f"entry {entry_id} is {entry['status']} and immutable; "
            "use a reversal or adjusting entry"
        )


def reverse_entry(conn, entry_id, *, entry_date=None, actor="user",
                  reason=None) -> int:
    """Post a mirror-image entry that cancels a posted entry."""
    entry = conn.execute(
        "SELECT * FROM journal_entries WHERE id=?", (entry_id,)
    ).fetchone()
    if entry is None:
        raise PostingError(f"entry {entry_id} not found")
    if entry["status"] != "posted":
        raise PostingError(f"only posted entries can be reversed (is {entry['status']})")
    lines = conn.execute(
        "SELECT * FROM journal_entry_lines WHERE entry_id=?", (entry_id,)
    ).fetchall()
    rev_lines = []
    for ln in lines:
        d = {f: ln[f] for f in LINE_DIM_FIELDS}
        d["account_id"] = ln["account_id"]
        d["debit_cents"] = ln["credit_cents"]   # swap
        d["credit_cents"] = ln["debit_cents"]
        d["memo"] = f"Reversal: {ln['memo']}"
        rev_lines.append(d)
    rev_date = entry_date or entry["entry_date"]
    if period_for_date(conn, rev_date) is None:
        raise PostingError(f"no open period for reversal date {rev_date}")
    rev_id = create_draft(
        conn, rev_date, f"Reversal of JE#{entry_id}: {entry['memo']}", rev_lines,
        source="reversal", source_ref=str(entry_id), actor=actor,
    )
    conn.execute(
        "UPDATE journal_entries SET reverses_entry_id=? WHERE id=?",
        (entry_id, rev_id),
    )
    post_draft(conn, rev_id, actor=actor, allow_closed=True, reason=reason)
    conn.execute(
        "UPDATE journal_entries SET status='reversed', reversed_by_entry_id=? "
        "WHERE id=?", (rev_id, entry_id),
    )
    audit(conn, "journal_entry", entry_id, "reverse",
          old={"status": "posted"}, new={"status": "reversed",
          "reversed_by": rev_id}, actor=actor, reason=reason)
    return rev_id


def void_draft(conn, entry_id, *, actor="user", reason=None) -> None:
    entry = conn.execute(
        "SELECT status FROM journal_entries WHERE id=?", (entry_id,)
    ).fetchone()
    if entry is None:
        raise PostingError(f"entry {entry_id} not found")
    if entry["status"] not in ("draft", "pending"):
        raise PostingError("only draft/pending entries can be voided")
    conn.execute("UPDATE journal_entries SET status='voided' WHERE id=?", (entry_id,))
    audit(conn, "journal_entry", entry_id, "void", new={"status": "voided"},
          actor=actor, reason=reason)


# ---------- period controls ----------
def set_period_status(conn, period_id, status, *, actor="user", reason=None):
    if status not in ("open", "soft_closed", "hard_closed", "reopened"):
        raise PostingError(f"invalid period status {status}")
    old = conn.execute(
        "SELECT status FROM accounting_periods WHERE id=?", (period_id,)
    ).fetchone()
    if old is None:
        raise PostingError(f"period {period_id} not found")
    if status == "reopened" and not reason:
        raise PostingError("reopening a period requires a reason")
    closed = "datetime('now')" if status in ("soft_closed", "hard_closed") else "NULL"
    conn.execute(
        f"UPDATE accounting_periods SET status=?, closed_at={closed}, "
        "reopened_reason=? WHERE id=?",
        (status, reason if status == "reopened" else None, period_id),
    )
    audit(conn, "accounting_period", period_id, "status_change",
          old={"status": old["status"]}, new={"status": status},
          actor=actor, reason=reason)
