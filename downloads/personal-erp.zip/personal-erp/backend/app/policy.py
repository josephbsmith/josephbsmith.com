"""Implementation defaults / policy config (see DECISIONS.md).

These resolve the open design questions in brief section 27. They live here (plus
a `settings` table for the mutable threshold) so accounting behavior can change
without rewriting engine logic.
"""

BASIS = "hybrid_personal_gaap"
BASE_CURRENCY = "USD"
SINGLE_HOUSEHOLD = True
ALLOCATIONS_POST_TO_GL = False
INVESTMENT_VALUATION = "account_level"
MORTGAGE_PRINCIPAL = "debt_reduction_financing"
TAX_AS_VALUATION_LAYER = True
SCENARIO_INHERIT = True

# Default capitalization threshold in cents; the live value is read from the
# `settings` table (key = 'capitalization_threshold_cents') so it is editable.
DEFAULT_CAPITALIZATION_THRESHOLD_CENTS = 100_000  # $1,000

# Account-code prefixes that force required analytical dimensions on a line.
# Expense (5-8) and fixed-asset (130-135) lines require cost center, service
# line, and person. Accumulated-depreciation contra (139xx) is exempt.
REQUIRED_DIMS = ("cost_center_id", "service_line_id", "person_id")


def account_type_for_code(code: str) -> str:
    """Classify a 5-digit account code into a statement type."""
    d = code[0]
    return {
        "1": "asset",
        "2": "liability",
        "3": "equity",
        "4": "income",
        "5": "expense",
        "6": "expense",
        "7": "expense",
        "8": "expense",
        "9": "statistical",
    }[d]


def normal_balance_for_code(code: str) -> str:
    """Debit-normal: assets, expenses. Credit-normal: liabilities, equity, income.

    Contra-asset accumulated depreciation (139xx) is credit-normal.
    """
    if code.startswith("139"):
        return "credit"
    t = account_type_for_code(code)
    if t in ("asset", "expense"):
        return "debit"
    return "credit"  # liability, equity, income, statistical (arbitrary)


def requires_dimensions(code: str) -> bool:
    """True if lines on this account must carry the required analytical dims.

    Expense accounts (5xxxx-8xxxx) and capitalizable fixed-asset accounts
    (13000-13599, excluding accumulated depreciation 139xx) require them.
    """
    if code.startswith("139"):
        return False
    if code[0] in ("5", "6", "7", "8"):
        return True
    # fixed-asset property accounts 13000..13599
    if code.startswith("13") and not code.startswith("139"):
        return True
    return False
