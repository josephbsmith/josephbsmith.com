"""SQLite access: connection, schema init, audit helper.

stdlib sqlite3 only. Money is integer cents. One DB file per install; path is
overridable with PERSONAL_ERP_DB for tests.
"""
import json
import os
import sqlite3
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
DEFAULT_DB = APP_DIR.parent / "personal_erp.db"
SCHEMA_PATH = APP_DIR / "schema.sql"


def db_path() -> Path:
    return Path(os.environ.get("PERSONAL_ERP_DB", DEFAULT_DB))


def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(db_path())
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(conn: sqlite3.Connection | None = None) -> None:
    own = conn is None
    conn = conn or connect()
    conn.executescript(SCHEMA_PATH.read_text())
    conn.commit()
    if own:
        conn.close()


def get_setting(conn, key: str, default=None):
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(conn, key: str, value) -> None:
    conn.execute(
        "INSERT INTO settings(key, value) VALUES(?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, str(value)),
    )


def audit(conn, entity_type, entity_id, action, *, old=None, new=None,
          actor="system", reason=None, source=None) -> None:
    conn.execute(
        "INSERT INTO audit_events(entity_type, entity_id, action, old_value, "
        "new_value, actor, reason, source) VALUES(?,?,?,?,?,?,?,?)",
        (
            entity_type, entity_id, action,
            json.dumps(old) if old is not None else None,
            json.dumps(new) if new is not None else None,
            actor, reason, source,
        ),
    )
