"""Phase 7: forecast assumptions + scenario projections. Scenarios inherit
assumptions from a base scenario until overridden (policy.SCENARIO_INHERIT)."""
from __future__ import annotations

from . import reports

# Assumption keys (all cents unless *_bps or *_pct)
DEFAULTS = {
    "monthly_income_cents": "0",
    "monthly_expense_cents": "0",
    "monthly_savings_cents": "0",
    "income_growth_bps_annual": "0",
    "expense_growth_bps_annual": "0",
}


def resolved_assumptions(conn, scenario_id) -> dict:
    """Walk the base chain; nearer scenarios override farther ones."""
    chain = []
    sid = scenario_id
    seen = set()
    while sid and sid not in seen:
        seen.add(sid)
        s = conn.execute("SELECT * FROM scenario_versions WHERE id=?",
                         (sid,)).fetchone()
        if s is None:
            break
        chain.append(s)
        sid = s["base_scenario_id"]
    merged = dict(DEFAULTS)
    for s in reversed(chain):  # base first, then overrides
        for a in conn.execute(
                "SELECT key, value FROM forecast_assumptions WHERE scenario_id=?",
                (s["id"],)).fetchall():
            merged[a["key"]] = a["value"]
    return merged


def project(conn, scenario_id, *, start_net_worth_cents=None):
    """Project net worth month by month over the scenario horizon."""
    s = conn.execute("SELECT * FROM scenario_versions WHERE id=?",
                     (scenario_id,)).fetchone()
    a = resolved_assumptions(conn, scenario_id)
    income = int(a["monthly_income_cents"])
    expense = int(a["monthly_expense_cents"])
    ig = int(a["income_growth_bps_annual"]) / 10000 / 12
    eg = int(a["expense_growth_bps_annual"]) / 10000 / 12
    if start_net_worth_cents is None:
        import datetime
        today = datetime.date.today().isoformat()
        start_net_worth_cents = reports.net_worth(conn, end=today)["net_worth"]
    nw = start_net_worth_cents
    out = []
    for m in range(1, s["horizon_months"] + 1):
        income = round(income * (1 + ig))
        expense = round(expense * (1 + eg))
        net = income - expense
        nw += net
        out.append({"month": m, "income_cents": income, "expense_cents": expense,
                    "net_cents": net, "net_worth_cents": nw})
    return {"scenario": dict(s), "assumptions": a, "rows": out,
            "ending_net_worth_cents": nw}


def compare(conn, scenario_ids, *, start_net_worth_cents=None):
    return [project(conn, sid, start_net_worth_cents=start_net_worth_cents)
            for sid in scenario_ids]
