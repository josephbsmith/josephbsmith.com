"""Server-rendered FastAPI app. Dense operational UI over the accounting core.
Every mutating route goes through the posting engine / services, so the UI can
never bypass posting integrity.
"""
from __future__ import annotations
from pathlib import Path

from fastapi import FastAPI, Request, Form, UploadFile, File
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from . import (db, posting, imports, assets, debt, budgets, scenarios, kpis,
               reports, money, seed, policy)

APP_DIR = Path(__file__).resolve().parent
app = FastAPI(title="Personal ERP")
templates = Jinja2Templates(directory=str(APP_DIR / "templates"))
templates.env.filters["c"] = money.fmt
templates.env.filters["pct"] = lambda v: f"{v*100:.1f}%"
(APP_DIR / "static").mkdir(exist_ok=True)
app.mount("/static", StaticFiles(directory=str(APP_DIR / "static")), name="static")

DEFAULT_PERIOD = "2026-07"


def get_conn():
    if not db.db_path().exists():
        db.init_db()
        c = db.connect()
        seed.seed_reference(c)
        seed.seed_demo(c)
        c.close()
    return db.connect()


def render(request, template, **ctx):
    ctx.setdefault("flash", None)
    ctx.setdefault("flash_err", False)
    return templates.TemplateResponse(request, template, ctx)


def dims(conn):
    """Dropdown option lists for journal / review forms."""
    q = lambda t: conn.execute(f"SELECT id, name FROM {t} WHERE is_active=1 ORDER BY name").fetchall()
    return {
        "accounts": conn.execute(
            "SELECT id, code, name FROM ledger_accounts WHERE is_active=1 "
            "AND type!='statistical' ORDER BY code").fetchall(),
        "cost_centers": q("cost_centers"), "service_lines": q("service_lines"),
        "people": q("people"), "vendors": q("vendors"), "locations": q("locations"),
        "funding_sources": q("funding_sources"), "tax_treatments": q("tax_treatments"),
    }


# ---------------- Dashboard ----------------
@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request, period: str = DEFAULT_PERIOD):
    conn = get_conn()
    start, end = reports.month_bounds(period)
    k = kpis.compute(conn, period, store=False)
    kdefs = {d["code"]: d for d in conn.execute("SELECT * FROM kpi_definitions").fetchall()}
    nw = reports.net_worth(conn, end=end)
    isr = reports.income_statement(conn, start=start, end=end)
    cf = reports.cash_flow(conn, start=start, end=end)
    recs = conn.execute(
        "SELECT s.id, ba.name, s.period_label, r.is_reconciled, r.difference_cents "
        "FROM month_end_statements s JOIN bank_accounts ba ON ba.id=s.bank_account_id "
        "LEFT JOIN bank_reconciliations r ON r.id=("
        "  SELECT id FROM bank_reconciliations WHERE statement_id=s.id "
        "  ORDER BY id DESC LIMIT 1) ORDER BY s.id").fetchall()
    periods = conn.execute("SELECT * FROM accounting_periods ORDER BY month").fetchall()
    conn.close()
    return render(request, "dashboard.html", period=period, k=k, kdefs=kdefs,
                  nw=nw, isr=isr, cf=cf, recs=recs, periods=periods)


# ---------------- Chart of accounts ----------------
@app.get("/accounts", response_class=HTMLResponse)
def accounts(request: Request, end: str = "2026-07-31", flash: str = None, flash_err: bool = False):
    conn = get_conn()
    bals = {r["code"]: r for r in reports._sums(conn, end=end)}
    rows = conn.execute("SELECT * FROM ledger_accounts ORDER BY code").fetchall()
    conn.close()
    out = []
    for a in rows:
        b = bals.get(a["code"])
        net = (b["dr"] - b["cr"]) if b else 0
        out.append({**dict(a), "balance": net if a["normal_balance"] == "debit" else -net})
    return render(request, "accounts.html", rows=out, end=end, flash=flash, flash_err=flash_err)


@app.get("/accounts/new", response_class=HTMLResponse)
def account_new(request: Request):
    return render(request, "account_new.html")


@app.post("/accounts/new")
def account_create(request: Request, code: str = Form(...), name: str = Form(...)):
    code, name = code.strip(), name.strip()
    conn = get_conn()
    try:
        if not (len(code) == 5 and code.isdigit() and code[0] in "123456789"):
            raise ValueError("Code must be 5 digits starting 1-9 (1=asset 2=liability "
                             "3=equity 4=income 5-8=expense 9=statistical).")
        if not name:
            raise ValueError("Name is required.")
        conn.execute(
            "INSERT INTO ledger_accounts(code, name, type, normal_balance, "
            "is_contra, requires_dimensions) VALUES(?,?,?,?,?,?)",
            (code, name, policy.account_type_for_code(code),
             policy.normal_balance_for_code(code),
             1 if code.startswith("139") else 0,
             1 if policy.requires_dimensions(code) else 0))
        conn.commit()
        conn.close()
        return RedirectResponse("/accounts?flash=Account+added", status_code=303)
    except Exception as e:
        conn.close()
        msg = "That code already exists." if "UNIQUE" in str(e) else str(e)
        return render(request, "account_new.html", flash=msg, flash_err=True,
                      code=code, name=name)


# ---------------- Journal ----------------
@app.get("/journal", response_class=HTMLResponse)
def journal(request: Request, period: str = "", flash: str = None, flash_err: bool = False):
    conn = get_conn()
    where = ""
    params = []
    if period:
        where = "WHERE ap.label=?"; params = [period]
    entries = conn.execute(
        "SELECT je.*, ap.label period, "
        "(SELECT COALESCE(SUM(debit_cents),0) FROM journal_entry_lines WHERE entry_id=je.id) tot "
        "FROM journal_entries je JOIN accounting_periods ap ON ap.id=je.period_id "
        f"{where} ORDER BY je.entry_date DESC, je.id DESC", params).fetchall()
    periods = conn.execute("SELECT label FROM accounting_periods ORDER BY month").fetchall()
    conn.close()
    return render(request, "journal_list.html", entries=entries, periods=periods,
                  period=period, flash=flash, flash_err=flash_err)


@app.get("/journal/new", response_class=HTMLResponse)
def journal_new(request: Request):
    conn = get_conn()
    d = dims(conn)
    conn.close()
    return render(request, "journal_new.html", d=d, nlines=range(4))


@app.post("/journal/new")
async def journal_create(request: Request):
    form = await request.form()
    conn = get_conn()
    lines = []
    for i in range(6):
        acc = form.get(f"account_{i}")
        if not acc:
            continue
        dr = money.to_cents(form.get(f"debit_{i}") or 0)
        cr = money.to_cents(form.get(f"credit_{i}") or 0)
        if dr == 0 and cr == 0:
            continue
        lines.append({
            "account_id": int(acc), "debit_cents": dr, "credit_cents": cr,
            "cost_center_id": _int(form.get(f"cc_{i}")),
            "service_line_id": _int(form.get(f"sl_{i}")),
            "person_id": _int(form.get(f"person_{i}")),
            "vendor_id": _int(form.get(f"vendor_{i}")),
            "memo": form.get(f"memo_{i}") or "",
        })
    try:
        eid = posting.post_entry(conn, form.get("entry_date"), form.get("memo", ""),
                                 lines, actor="user")
        conn.commit()
        conn.close()
        return RedirectResponse(f"/journal/{eid}", status_code=303)
    except Exception as e:
        conn.close()
        d_conn = get_conn(); d = dims(d_conn); d_conn.close()
        return render(request, "journal_new.html", d=d, nlines=range(4),
                      flash=str(e), flash_err=True)


@app.get("/journal/{eid}", response_class=HTMLResponse)
def journal_detail(request: Request, eid: int):
    conn = get_conn()
    entry = conn.execute("SELECT je.*, ap.label period, ap.status pstatus "
                         "FROM journal_entries je JOIN accounting_periods ap "
                         "ON ap.id=je.period_id WHERE je.id=?", (eid,)).fetchone()
    lines = conn.execute(
        "SELECT l.*, a.code, a.name, cc.name cc, sl.name sl, p.name person "
        "FROM journal_entry_lines l JOIN ledger_accounts a ON a.id=l.account_id "
        "LEFT JOIN cost_centers cc ON cc.id=l.cost_center_id "
        "LEFT JOIN service_lines sl ON sl.id=l.service_line_id "
        "LEFT JOIN people p ON p.id=l.person_id WHERE l.entry_id=?", (eid,)).fetchall()
    conn.close()
    return render(request, "journal_detail.html", entry=entry, lines=lines)


@app.post("/journal/{eid}/reverse")
async def journal_reverse(eid: int, reason: str = Form("")):
    conn = get_conn()
    try:
        rid = posting.reverse_entry(conn, eid, reason=reason or "correction", actor="user")
        conn.commit(); conn.close()
        return RedirectResponse(f"/journal/{rid}", status_code=303)
    except Exception as e:
        conn.close()
        return RedirectResponse(f"/journal?flash={e}&flash_err=1", status_code=303)


# ---------------- Transaction review ----------------
@app.get("/review", response_class=HTMLResponse)
def review(request: Request, flash: str = None, flash_err: bool = False):
    conn = get_conn()
    stmts = conn.execute(
        "SELECT s.*, ba.name ba_name, ba.kind FROM month_end_statements s "
        "JOIN bank_accounts ba ON ba.id=s.bank_account_id ORDER BY s.id").fetchall()
    data = []
    for s in stmts:
        txns = conn.execute(
            "SELECT t.*, a.code sugg_code FROM imported_transactions t "
            "LEFT JOIN ledger_accounts a ON a.id=t.suggested_account_id "
            "WHERE t.statement_id=? ORDER BY t.txn_date", (s["id"],)).fetchall()
        data.append({"stmt": s, "txns": txns})
    d = dims(conn)
    conn.close()
    return render(request, "review.html", data=data, d=d, flash=flash, flash_err=flash_err)


@app.post("/review/{txn_id}/post")
async def review_post(request: Request, txn_id: int):
    form = await request.form()
    conn = get_conn()
    try:
        acc = int(form["account_id"])
        d = {"cost_center_id": _int(form.get("cc")),
             "service_line_id": _int(form.get("sl")),
             "person_id": _int(form.get("person"))}
        imports.post_transaction(conn, txn_id, acc, dims={k: v for k, v in d.items() if v},
                                 actor="user")
        conn.commit(); conn.close()
        return RedirectResponse("/review?flash=Posted+transaction", status_code=303)
    except Exception as e:
        conn.close()
        return RedirectResponse(f"/review?flash={e}&flash_err=1", status_code=303)


@app.post("/review/{txn_id}/ignore")
def review_ignore(txn_id: int):
    conn = get_conn()
    conn.execute("UPDATE imported_transactions SET status='ignored' WHERE id=?", (txn_id,))
    conn.commit(); conn.close()
    return RedirectResponse("/review?flash=Ignored", status_code=303)


# ---------------- Statements ----------------
@app.get("/statements", response_class=HTMLResponse)
def statements(request: Request, flash: str = None, flash_err: bool = False):
    conn = get_conn()
    stmts = conn.execute(
        "SELECT s.*, ba.name ba_name, ba.kind, "
        "(SELECT is_reconciled FROM bank_reconciliations WHERE statement_id=s.id ORDER BY id DESC LIMIT 1) recon, "
        "(SELECT difference_cents FROM bank_reconciliations WHERE statement_id=s.id ORDER BY id DESC LIMIT 1) diff "
        "FROM month_end_statements s JOIN bank_accounts ba ON ba.id=s.bank_account_id "
        "ORDER BY s.id").fetchall()
    banks = conn.execute("SELECT * FROM bank_accounts WHERE is_active=1").fetchall()
    conn.close()
    return render(request, "statements.html", stmts=stmts, banks=banks,
                  flash=flash, flash_err=flash_err)


@app.post("/statements/upload")
async def statements_upload(bank_account_id: int = Form(...), period_label: str = Form(...),
                            start: str = Form(...), end: str = Form(...),
                            opening: str = Form(...), file: UploadFile = File(...)):
    conn = get_conn()
    try:
        text = (await file.read()).decode("utf-8")
        lines = imports.parse_csv(text)
        sid = imports.create_statement(conn, bank_account_id, period_label, start, end,
                                       money.to_cents(opening), lines,
                                       filename=file.filename, raw_text=text, actor="user")
        imports.suggest(conn, sid)
        conn.commit(); conn.close()
        return RedirectResponse("/review?flash=Statement+imported;+review+lines", status_code=303)
    except Exception as e:
        conn.close()
        return RedirectResponse(f"/statements?flash={e}&flash_err=1", status_code=303)


@app.post("/statements/{sid}/reconcile")
def statements_reconcile(sid: int):
    conn = get_conn()
    r = imports.reconcile(conn, sid, actor="user")
    conn.commit(); conn.close()
    msg = "Reconciled" if r["reconciled"] else f"Out+of+balance+by+{money.fmt(r['difference_cents'])}"
    return RedirectResponse(f"/statements?flash={msg}&flash_err={0 if r['reconciled'] else 1}",
                            status_code=303)


# ---------------- Reports ----------------
@app.get("/reports", response_class=HTMLResponse)
def reports_page(request: Request, period: str = DEFAULT_PERIOD):
    conn = get_conn()
    start, end = reports.month_bounds(period)
    ctx = {
        "period": period, "start": start, "end": end,
        "tb": reports.trial_balance(conn, end=end),
        "isr": reports.income_statement(conn, start=start, end=end),
        "bs": reports.balance_sheet(conn, end=end),
        "cf": reports.cash_flow(conn, start=start, end=end),
        "nw": reports.net_worth(conn, end=end),
        "by_sl": reports.spending_by(conn, "service_line", start=start, end=end),
        "by_cc": reports.spending_by(conn, "cost_center", start=start, end=end),
        "periods": conn.execute("SELECT label FROM accounting_periods ORDER BY month").fetchall(),
    }
    conn.close()
    return render(request, "reports.html", **ctx)


# ---------------- Budget ----------------
@app.get("/budget", response_class=HTMLResponse)
def budget(request: Request, period: str = DEFAULT_PERIOD):
    conn = get_conn()
    versions = conn.execute("SELECT * FROM budget_versions ORDER BY id").fetchall()
    bva = None
    if versions:
        bva = budgets.budget_vs_actual(conn, versions[0]["id"], period)
    commit = budgets.commitment_summary(conn)
    goals = conn.execute("SELECT * FROM goals").fetchall()
    prs = conn.execute("SELECT pr.*, v.name vendor FROM purchase_requests pr "
                       "LEFT JOIN vendors v ON v.id=pr.vendor_id").fetchall()
    periods = conn.execute("SELECT label FROM accounting_periods ORDER BY month").fetchall()
    conn.close()
    return render(request, "budget.html", bva=bva, versions=versions, period=period,
                  commit=commit, goals=goals, prs=prs, periods=periods)


# ---------------- Assets ----------------
@app.get("/assets", response_class=HTMLResponse)
def assets_page(request: Request, flash: str = None, flash_err: bool = False):
    conn = get_conn()
    fc = assets.replacement_forecast(conn)
    rows = conn.execute("SELECT a.*, ac.name cls FROM assets a "
                       "LEFT JOIN asset_classes ac ON ac.id=a.asset_class_id "
                       "ORDER BY a.id").fetchall()
    runs = conn.execute("SELECT dr.*, a.name asset FROM depreciation_runs dr "
                       "JOIN assets a ON a.id=dr.asset_id ORDER BY dr.period_label, a.name").fetchall()
    conn.close()
    return render(request, "assets.html", fc={f["id"]: f for f in fc}, rows=rows,
                  runs=runs, flash=flash, flash_err=flash_err)


@app.post("/assets/depreciate")
def assets_depreciate(period: str = Form(...)):
    conn = get_conn()
    start, end = reports.month_bounds(period)
    posted = assets.run_all(conn, period, end, actor="user")
    conn.commit(); conn.close()
    return RedirectResponse(f"/assets?flash=Posted+{len(posted)}+depreciation+entries+for+{period}",
                            status_code=303)


# ---------------- Debt ----------------
@app.get("/debt", response_class=HTMLResponse)
def debt_page(request: Request, flash: str = None, flash_err: bool = False):
    conn = get_conn()
    debts = conn.execute("SELECT * FROM debt_accounts ORDER BY id").fetchall()
    data = []
    for d in debts:
        data.append({
            "d": d, "monthly_interest": debt.monthly_interest(conn, d["id"]),
            "accrued": debt.accrued_balance(conn, d["id"]),
            "sched": debt.amortization_schedule(conn, d["id"],
                     d["scheduled_payment_cents"] or
                     max(debt.monthly_interest(conn, d["id"]) + 20000, 25000))[:12],
            "payments": conn.execute("SELECT * FROM debt_payments WHERE debt_account_id=? "
                                      "ORDER BY payment_date", (d["id"],)).fetchall(),
        })
    conn.close()
    return render(request, "debt.html", data=data, flash=flash, flash_err=flash_err)


@app.post("/debt/{did}/accrue")
def debt_accrue(did: int, period: str = Form(...)):
    conn = get_conn()
    start, end = reports.month_bounds(period)
    try:
        debt.accrue_interest(conn, did, period, end, actor="user")
        conn.commit(); conn.close()
        return RedirectResponse(f"/debt?flash=Accrued+interest+for+{period}", status_code=303)
    except Exception as e:
        conn.close()
        return RedirectResponse(f"/debt?flash={e}&flash_err=1", status_code=303)


# ---------------- Scenarios ----------------
@app.get("/scenarios", response_class=HTMLResponse)
def scenarios_page(request: Request):
    conn = get_conn()
    svs = conn.execute("SELECT * FROM scenario_versions ORDER BY id").fetchall()
    nw = reports.net_worth(conn, end="2026-07-31")["net_worth"]
    projections = scenarios.compare(conn, [s["id"] for s in svs], start_net_worth_cents=nw)
    conn.close()
    return render(request, "scenarios.html", projections=projections, start_nw=nw)


# ---------------- Dimensions ----------------
@app.get("/dimensions", response_class=HTMLResponse)
def dimensions_page(request: Request):
    conn = get_conn()
    tables = ["people", "locations", "cost_centers", "service_lines",
              "funding_sources", "tax_treatments", "vendors"]
    data = {t: conn.execute(f"SELECT * FROM {t} ORDER BY name").fetchall() for t in tables}
    conn.close()
    return render(request, "dimensions.html", data=data)


# ---------------- Close ----------------
@app.get("/close", response_class=HTMLResponse)
def close_page(request: Request, period: str = DEFAULT_PERIOD, flash: str = None, flash_err: bool = False):
    conn = get_conn()
    periods = conn.execute("SELECT * FROM accounting_periods ORDER BY month").fetchall()
    p = conn.execute("SELECT * FROM accounting_periods WHERE label=?", (period,)).fetchone()
    start, end = reports.month_bounds(period)
    checklist = _close_checklist(conn, period, start, end)
    conn.close()
    return render(request, "close.html", periods=periods, p=p, period=period,
                  checklist=checklist, flash=flash, flash_err=flash_err)


def _close_checklist(conn, period, start, end):
    stmts = conn.execute(
        "SELECT COUNT(*) n, SUM(status='reconciled') rec FROM month_end_statements "
        "WHERE period_label=?", (period,)).fetchone()
    unreviewed = conn.execute(
        "SELECT COUNT(*) n FROM imported_transactions t "
        "JOIN month_end_statements s ON s.id=t.statement_id "
        "WHERE s.period_label=? AND t.status='unreviewed'", (period,)).fetchone()["n"]
    deprec = conn.execute("SELECT COUNT(*) n FROM depreciation_runs WHERE period_label=?",
                          (period,)).fetchone()["n"]
    interest = conn.execute("SELECT COUNT(*) n FROM interest_accruals WHERE period_label=?",
                            (period,)).fetchone()["n"]
    tb = reports.trial_balance(conn, end=end)
    return [
        ("All statements reconciled", stmts["n"] and stmts["rec"] == stmts["n"]),
        ("No unreviewed imported transactions", unreviewed == 0),
        ("Depreciation posted", deprec > 0),
        ("Interest accrued", interest > 0),
        ("Trial balance balances", tb["balanced"]),
    ]


@app.post("/close/run-month-end")
def run_month_end(period: str = Form(...)):
    conn = get_conn()
    start, end = reports.month_bounds(period)
    msgs = []
    posted = assets.run_all(conn, period, end, actor="user")
    msgs.append(f"{len(posted)}+deprec")
    for d in conn.execute("SELECT id FROM debt_accounts WHERE is_active=1").fetchall():
        already = conn.execute("SELECT 1 FROM interest_accruals WHERE debt_account_id=? "
                               "AND period_label=?", (d["id"], period)).fetchone()
        if not already:
            try:
                debt.accrue_interest(conn, d["id"], period, end, actor="user")
                msgs.append("interest")
            except Exception:
                pass
    kpis.compute(conn, period)
    conn.commit(); conn.close()
    return RedirectResponse(f"/close?period={period}&flash=Month-end+run:+{'+'.join(msgs)}",
                            status_code=303)


@app.post("/close/period/{pid}")
def close_period(pid: int, status: str = Form(...), reason: str = Form("")):
    conn = get_conn()
    label = conn.execute("SELECT label FROM accounting_periods WHERE id=?", (pid,)).fetchone()["label"]
    try:
        posting.set_period_status(conn, pid, status, actor="user", reason=reason or None)
        conn.commit(); conn.close()
        return RedirectResponse(f"/close?period={label}&flash=Period+{label}+{status}", status_code=303)
    except Exception as e:
        conn.close()
        return RedirectResponse(f"/close?period={label}&flash={e}&flash_err=1", status_code=303)


def _int(v):
    return int(v) if v else None
