"""Seed reference data (chart of accounts, dimensions, periods, KPI defs,
settings) and a deliberately fictional demo household that exercises Phases 1-8
end to end. The demo numbers and names are made up (a DeLorean, a Jedi Academy
loan, Starfleet payroll) — it is example data, not anyone's real finances.
"""
from __future__ import annotations

from . import policy, posting, imports, assets, debt, kpis
from .db import set_setting

# ---- Chart of accounts: leaf accounts from brief sections 5-6, 8 ----
ACCOUNTS = [
    # Assets
    ("10100", "Checking"), ("10200", "Savings"), ("10300", "Cash"),
    ("10400", "Emergency Fund"), ("11000", "Taxable Brokerage"),
    ("11100", "Roth IRA"), ("11200", "Traditional IRA"),
    ("11300", "HSA Investments"), ("11400", "Crypto Assets"),
    ("12000", "Receivables"), ("12100", "Tax Refund Receivable"),
    ("12200", "Employer Reimbursements"), ("13000", "Vehicles"),
    ("13100", "Home and Property"), ("13200", "Furniture and Fixtures"),
    ("13300", "Electronics"), ("13400", "Collectibles"),
    ("13500", "Home Improvements"),
    ("13900", "Accumulated Depreciation"),
    ("13910", "Accumulated Depreciation - Vehicles"),
    ("13920", "Accumulated Depreciation - Home Components"),
    ("13930", "Accumulated Depreciation - Electronics"),
    # Liabilities
    ("20100", "Credit Cards"), ("21000", "Auto Loans"),
    ("21100", "Student Loans"), ("21200", "Personal Loans"),
    ("21300", "Mortgage Payable"), ("22000", "Federal Tax Payable"),
    ("22100", "State Tax Payable"), ("23000", "Accrued Interest Payable"),
    ("24000", "Commitments Clearing"),
    # Equity
    ("30100", "Opening Balance Equity"), ("31000", "Personal Equity"),
    ("32000", "Current Year Earnings"), ("33000", "Prior Year Earnings"),
    ("34000", "Valuation Reserve"),
    # Income
    ("40100", "Salary"), ("40110", "Bonus"), ("40120", "Overtime"),
    ("41000", "Interest Income"), ("41100", "Dividend Income"),
    ("41200", "Capital Gains"), ("42000", "Consulting Income"),
    ("42100", "Royalties"), ("42200", "Software Sales"),
    ("43000", "Gifts Received"), ("43100", "Miscellaneous Income"),
    # Taxes (expense)
    ("50100", "Federal Income Tax"), ("50200", "State Income Tax"),
    ("50300", "Social Security Tax"), ("50400", "Medicare Tax"),
    ("50500", "Local Taxes"), ("50600", "Property Tax"),
    ("50700", "Sales and Use Tax"),
    # Living expenses
    ("60100", "Rent / Mortgage Occupancy"), ("60110", "HOA"),
    ("60120", "Home Insurance"), ("60130", "Repairs and Maintenance"),
    ("60200", "Electric"), ("60210", "Water"), ("60220", "Internet"),
    ("60230", "Mobile Phone"), ("60300", "Groceries"), ("60310", "Restaurants"),
    ("60400", "Health Insurance Premiums"), ("60410", "Medical"),
    ("60420", "Dental"), ("60430", "Vision"), ("60440", "Pharmacy"),
    # Transportation
    ("70100", "Fuel"), ("70110", "Vehicle Maintenance"),
    ("70120", "Vehicle Insurance"), ("70130", "Registration"),
    ("70140", "Parking"), ("70150", "Ride Share"), ("70160", "Airfare"),
    ("70170", "Lodging"),
    # Personal / discretionary
    ("80100", "Clothing"), ("80110", "Personal Care"), ("80120", "Fitness"),
    ("80130", "Hobbies"), ("80200", "Streaming"), ("80210", "Books"),
    ("80220", "Games"), ("80230", "Movies"), ("80300", "Tuition"),
    ("80310", "Educational Materials"), ("80320", "Professional Certifications"),
    ("80330", "Software Subscriptions"), ("80400", "Charitable Donations"),
    ("80410", "Gifts Given"),
    # Financing / capital costs
    ("85100", "Mortgage Interest Expense"), ("85200", "Auto Loan Interest Expense"),
    ("85300", "Student Loan Interest Expense"),
    ("85400", "Credit Card Interest Expense"), ("85500", "Margin Interest Expense"),
    ("85600", "Loan Fees"), ("85700", "Personal Loan Interest Expense"),
    # Depreciation / amortization
    ("86100", "Depreciation Expense - Vehicles"),
    ("86200", "Depreciation Expense - Home Components"),
    ("86300", "Depreciation Expense - Electronics"),
    ("86400", "Depreciation Expense - Furniture"),
    ("86500", "Amortization Expense - Software"),
    # Statistical (memo; no double-entry postings in v1)
    ("90100", "Transfer to Savings"), ("90200", "Brokerage Contributions"),
    ("90300", "Roth IRA Contributions"), ("90400", "HSA Contributions"),
    ("90500", "Debt Principal Payments"), ("90600", "Internal Transfers"),
    ("99000", "Statistical Accounts"),
]

PEOPLE = ["Primary", "Partner", "Joint", "Dependent"]
LOCATIONS = ["Metropolis", "Gotham", "Online", "Home", "Home office", "Travel"]
COST_CENTERS = ["Household", "Primary", "Partner", "Education", "Health",
                "Investments", "Business venture", "Home office"]
SERVICE_LINES = ["Housing", "Nutrition", "Transportation", "Healthcare",
                 "Education", "Wealth Building", "Entertainment",
                 "Business Development", "Professional Development", "Travel"]
FUNDING_SOURCES = ["Salary", "Bonus", "Emergency fund", "Tax refund",
                   "Loan proceeds", "Gift", "Investment liquidation",
                   "Business income"]
TAX_TREATMENTS = ["Nondeductible personal", "Charitable deduction",
                  "HSA-qualified", "Medical deductible", "Mortgage interest",
                  "Student loan interest", "Investment interest",
                  "Business deductible", "Capitalizable", "Taxable income",
                  "Tax-exempt income"]
VENDORS = ["Duff Megamart", "Vault-Tec Insurance", "Galactic Airways",
           "Gringotts", "Acme Corp", "Wonka Industries", "Jedi Academy",
           "Springfield Nuclear", "HoloNet Plus", "Xanadu Estates", "Mortgage Co"]


def _id(conn, table, name):
    return conn.execute(f"SELECT id FROM {table} WHERE name=?", (name,)).fetchone()["id"]


def _acct(conn, code):
    return conn.execute("SELECT id FROM ledger_accounts WHERE code=?",
                        (code,)).fetchone()["id"]


def seed_reference(conn):
    conn.execute("INSERT INTO households(id, name, base_currency) VALUES(1, ?, ?)",
                 ("Demo Household", policy.BASE_CURRENCY))
    set_setting(conn, "capitalization_threshold_cents",
                policy.DEFAULT_CAPITALIZATION_THRESHOLD_CENTS)
    set_setting(conn, "basis", policy.BASIS)
    for code, name in ACCOUNTS:
        conn.execute(
            "INSERT INTO ledger_accounts(code, name, type, normal_balance, "
            "is_contra, requires_dimensions) VALUES(?,?,?,?,?,?)",
            (code, name, policy.account_type_for_code(code),
             policy.normal_balance_for_code(code),
             1 if code.startswith("139") else 0,
             1 if policy.requires_dimensions(code) else 0))
    for name in PEOPLE:
        conn.execute("INSERT INTO people(name) VALUES(?)", (name,))
    for name in LOCATIONS:
        conn.execute("INSERT INTO locations(name) VALUES(?)", (name,))
    for name in COST_CENTERS:
        conn.execute("INSERT INTO cost_centers(name) VALUES(?)", (name,))
    for name in SERVICE_LINES:
        conn.execute("INSERT INTO service_lines(name) VALUES(?)", (name,))
    for name in FUNDING_SOURCES:
        conn.execute("INSERT INTO funding_sources(name) VALUES(?)", (name,))
    for name in TAX_TREATMENTS:
        conn.execute("INSERT INTO tax_treatments(name) VALUES(?)", (name,))
    for name in VENDORS:
        conn.execute("INSERT INTO vendors(name) VALUES(?)", (name,))
    # accounting periods for 2026
    import calendar
    for m in range(1, 13):
        last = calendar.monthrange(2026, m)[1]
        conn.execute(
            "INSERT INTO accounting_periods(year, month, label, start_date, "
            "end_date) VALUES(?,?,?,?,?)",
            (2026, m, f"2026-{m:02d}", f"2026-{m:02d}-01", f"2026-{m:02d}-{last:02d}"))
    kpis.seed_definitions(conn)
    conn.commit()


# ---------------- Demo household (exercises Phases 3-8) ----------------
# Everything below is invented example data — absurd on purpose.
def seed_demo(conn):
    cc_house = _id(conn, "cost_centers", "Household")
    cc_primary = _id(conn, "cost_centers", "Primary")
    sl_nutrition = _id(conn, "service_lines", "Nutrition")
    sl_housing = _id(conn, "service_lines", "Housing")
    sl_transport = _id(conn, "service_lines", "Transportation")
    sl_entertain = _id(conn, "service_lines", "Entertainment")
    sl_prof = _id(conn, "service_lines", "Professional Development")
    p_joint = _id(conn, "people", "Joint")
    p_primary = _id(conn, "people", "Primary")

    # 1) Opening balances (June 2026), from Opening Balance Equity
    checking, savings = _acct(conn, "10100"), _acct(conn, "10200")
    vehicles, cc_liab = _acct(conn, "13000"), _acct(conn, "20100")
    student_loan, obe = _acct(conn, "21100"), _acct(conn, "30100")
    posting.post_entry(conn, "2026-06-30", "Opening balances", [
        {"account_id": checking, "debit_cents": 1200000, "credit_cents": 0},
        {"account_id": savings, "debit_cents": 8800000, "credit_cents": 0},
        {"account_id": vehicles, "debit_cents": 12100000, "credit_cents": 0,
         "cost_center_id": cc_house, "service_line_id": sl_transport,
         "person_id": p_joint},
        {"account_id": student_loan, "debit_cents": 0, "credit_cents": 5000000},
        {"account_id": cc_liab, "debit_cents": 0, "credit_cents": 300000},
        {"account_id": obe, "debit_cents": 0, "credit_cents": 16800000},
    ], source="opening", actor="seed")

    # 2) Bank accounts + matching rules
    conn.execute("INSERT INTO bank_accounts(name, kind, gl_account_id) "
                 "VALUES('Everyday Checking','checking',?)", (checking,))
    chk_ba = conn.execute("SELECT id FROM bank_accounts WHERE name='Everyday Checking'").fetchone()["id"]
    conn.execute("INSERT INTO bank_accounts(name, kind, gl_account_id) "
                 "VALUES('Gringotts Platinum','credit_card',?)", (cc_liab,))
    cc_ba = conn.execute("SELECT id FROM bank_accounts WHERE name='Gringotts Platinum'").fetchone()["id"]

    def rule(pattern, code, cc, sl, person):
        conn.execute(
            "INSERT INTO matching_rules(pattern, account_id, cost_center_id, "
            "service_line_id, person_id) VALUES(?,?,?,?,?)",
            (pattern, _acct(conn, code), cc, sl, person))
    rule("PAYROLL", "40100", None, None, None)
    rule("RENT", "60100", cc_house, sl_housing, p_joint)
    rule("ELECTRIC", "60200", cc_house, sl_housing, p_joint)
    rule("MEGAMART", "60300", cc_house, sl_nutrition, p_joint)
    rule("CANTINA", "60310", cc_house, sl_nutrition, p_joint)
    rule("HOLONET", "80200", cc_primary, sl_entertain, p_primary)

    # 3) Debt + asset masters
    conn.execute(
        "INSERT INTO debt_accounts(name, kind, gl_principal_account_id, "
        "gl_interest_expense_account_id, gl_accrued_interest_account_id, "
        "original_principal_cents, current_principal_cents, annual_rate_bps, "
        "term_months, cost_center_id, service_line_id, person_id, tax_treatment_id) "
        "VALUES('Jedi Academy Tuition Loan','student',?,?,?,?,?,?,?,?,?,?,?)",
        (student_loan, _acct(conn, "85300"), _acct(conn, "23000"),
         5000000, 5000000, 500, 120, cc_primary, sl_prof, p_primary,
         _id(conn, "tax_treatments", "Student loan interest")))
    loan_id = conn.execute("SELECT id FROM debt_accounts").fetchone()["id"]

    conn.execute(
        "INSERT INTO asset_classes(name, default_useful_life_months, "
        "asset_account_id, accum_deprec_account_id, deprec_expense_account_id) "
        "VALUES('Vehicle',60,?,?,?)",
        (vehicles, _acct(conn, "13910"), _acct(conn, "86100")))
    veh_class = conn.execute("SELECT id FROM asset_classes WHERE name='Vehicle'").fetchone()["id"]
    conn.execute(
        "INSERT INTO assets(name, asset_class_id, acquisition_date, "
        "in_service_date, cost_cents, salvage_cents, useful_life_months, "
        "cost_center_id, service_line_id, person_id, replacement_cost_cents) "
        "VALUES('1985 DeLorean DMC-12',?,?,?,?,?,?,?,?,?,?)",
        (veh_class, "1985-10-26", "1985-10-26", 12100000, 2100000, 60,
         cc_house, sl_transport, p_joint, 13000000))
    car_id = conn.execute("SELECT id FROM assets WHERE name='1985 DeLorean DMC-12'").fetchone()["id"]

    # 4) July checking statement -> review -> post -> reconcile
    chk_lines = [
        {"txn_date": "2026-07-01", "description": "STARFLEET PAYROLL", "amount_cents": 4200000},
        {"txn_date": "2026-07-03", "description": "XANADU ESTATES RENT", "amount_cents": -800000},
        {"txn_date": "2026-07-10", "description": "SPRINGFIELD NUCLEAR ELECTRIC", "amount_cents": -50000},
        {"txn_date": "2026-07-15", "description": "GRINGOTTS CARD PAYMENT", "amount_cents": -300000},
        {"txn_date": "2026-07-05", "description": "JEDI ACADEMY LOAN PYMT", "amount_cents": -60000},
    ]
    chk_stmt = imports.create_statement(
        conn, chk_ba, "2026-07", "2026-07-01", "2026-07-31", 1200000, chk_lines,
        filename="checking_2026-07.csv", actor="seed")
    imports.suggest(conn, chk_stmt)
    for t in conn.execute("SELECT * FROM imported_transactions WHERE statement_id=?",
                          (chk_stmt,)).fetchall():
        desc = t["description"]
        if "JEDI" in desc:
            # accrue interest first, then split payment
            debt.accrue_interest(conn, loan_id, "2026-07", "2026-07-31", actor="seed")
            r = debt.record_payment(conn, loan_id, t["txn_date"], 60000, checking, actor="seed")
            conn.execute("UPDATE imported_transactions SET status='posted', "
                         "journal_entry_id=? WHERE id=?", (r["entry_id"], t["id"]))
        elif "GRINGOTTS CARD PAYMENT" in desc:
            imports.post_transaction(conn, t["id"], cc_liab, actor="seed")
        else:
            dims = imports._rule_dims(conn, t)
            dims.pop("vendor_id", None)
            imports.post_transaction(conn, t["id"], t["suggested_account_id"],
                                     dims=dims, actor="seed")
    # 5) July credit-card statement -> review -> post -> reconcile
    cc_lines = [
        {"txn_date": "2026-07-08", "description": "DUFF MEGAMART", "amount_cents": 32100},
        {"txn_date": "2026-07-12", "description": "MOS EISLEY CANTINA", "amount_cents": 8800},
        {"txn_date": "2026-07-14", "description": "HOLONET PLUS", "amount_cents": 4200},
        {"txn_date": "2026-07-15", "description": "PAYMENT THANK YOU", "amount_cents": -300000},
    ]
    cc_stmt = imports.create_statement(
        conn, cc_ba, "2026-07", "2026-07-01", "2026-07-31", 300000, cc_lines,
        filename="gringotts_2026-07.csv", actor="seed")
    imports.suggest(conn, cc_stmt)
    for t in conn.execute("SELECT * FROM imported_transactions WHERE statement_id=?",
                          (cc_stmt,)).fetchall():
        if "PAYMENT THANK YOU" in t["description"]:
            # Same economic event as the checking-side transfer; match, don't
            # re-post (double posting would overstate the payment).
            conn.execute("UPDATE imported_transactions SET status='ignored' "
                         "WHERE id=?", (t["id"],))
        else:
            dims = imports._rule_dims(conn, t)
            dims.pop("vendor_id", None)
            imports.post_transaction(conn, t["id"], t["suggested_account_id"],
                                     dims=dims, actor="seed")

    # Reconcile both statements after all July postings are in the ledger.
    chk_recon = imports.reconcile(conn, chk_stmt, actor="seed")
    cc_recon = imports.reconcile(conn, cc_stmt, actor="seed")

    # 6) July depreciation
    assets.run_depreciation(conn, car_id, "2026-07", "2026-07-31", actor="seed")

    # 7) Budget version 2026 + July lines (some variance vs actual)
    conn.execute("INSERT INTO budget_versions(name, year) VALUES('Original 2026',2026)")
    bv = conn.execute("SELECT id FROM budget_versions").fetchone()["id"]
    budget = [("60100", 800000, cc_house, sl_housing, p_joint),
              ("60200", 55000, cc_house, sl_housing, p_joint),
              ("60300", 30000, cc_house, sl_nutrition, p_joint),
              ("60310", 10000, cc_house, sl_nutrition, p_joint),
              ("80200", 4000, cc_primary, sl_entertain, p_primary)]
    for code, amt, cc, sl, person in budget:
        conn.execute(
            "INSERT INTO budget_lines(budget_version_id, account_id, "
            "period_label, cost_center_id, service_line_id, person_id, "
            "amount_cents) VALUES(?,?,?,?,?,?,?)",
            (bv, _acct(conn, code), "2026-07", cc, sl, person, amt))

    # 8) Goal, commitment, purchase request
    conn.execute("INSERT INTO goals(name, target_cents, current_cents, "
                 "target_date, gl_account_id) VALUES('Escape-to-Mars Fund',50000000,"
                 "8800000,'2026-12-31',?)", (savings,))
    conn.execute("INSERT INTO commitments(name, vendor_id, amount_cents, "
                 "due_date, cost_center_id, service_line_id, status) "
                 "VALUES('Hoverboard insurance renewal',?,42000,'2026-09-01',?,?, 'approved')",
                 (_id(conn, "vendors", "Vault-Tec Insurance"), cc_house, sl_transport))
    conn.execute("INSERT INTO purchase_requests(item, vendor_id, "
                 "estimated_cents, desired_date, cost_center_id, service_line_id, "
                 "capitalize, status) VALUES('Flux Capacitor',?,121000,'2026-08-15',?,?,1,'requested')",
                 (_id(conn, "vendors", "Acme Corp"), cc_primary, sl_prof))

    # 9) Scenarios: base + income shock
    conn.execute("INSERT INTO scenario_versions(name, description, horizon_months) "
                 "VALUES('Base Case','Steady state',12)")
    base = conn.execute("SELECT id FROM scenario_versions WHERE name='Base Case'").fetchone()["id"]
    for k, v in [("monthly_income_cents", "4200000"),
                 ("monthly_expense_cents", "1210000"),
                 ("income_growth_bps_annual", "300")]:
        conn.execute("INSERT INTO forecast_assumptions(scenario_id, key, value) "
                     "VALUES(?,?,?)", (base, k, v))
    conn.execute("INSERT INTO scenario_versions(name, base_scenario_id, "
                 "description, horizon_months) VALUES('Income Shock',?,"
                 "'Income drops 30%',12)", (base,))
    shock = conn.execute("SELECT id FROM scenario_versions WHERE name='Income Shock'").fetchone()["id"]
    conn.execute("INSERT INTO forecast_assumptions(scenario_id, key, value) "
                 "VALUES(?,'monthly_income_cents','2940000')", (shock,))

    # 10) KPIs for July
    kpis.compute(conn, "2026-07")
    conn.commit()
    return {"checking_recon": chk_recon, "cc_recon": cc_recon}
