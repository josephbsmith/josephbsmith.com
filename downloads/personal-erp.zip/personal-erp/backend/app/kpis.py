"""Phase 8: KPI engine. Every KPI is computed from posted ledger data (and debt
payment / depreciation subledgers) so dashboard values reconcile to source."""
from __future__ import annotations

from . import reports
from .reports import month_bounds


DEFINITIONS = [
    ("savings_rate", "Savings Rate", "(income - expense) / income", "percent",
     0.10, 0.20, "Share of income retained after all expense."),
    ("effective_tax_rate", "Effective Tax Rate", "tax expense / income", "percent",
     None, None, "Tax load as a share of income."),
    ("housing_cost_pct", "Housing Cost %", "housing service line / income", "percent",
     0.35, 0.28, "Housing burden as a share of income."),
    ("debt_service_ratio", "Debt Service Ratio", "debt payments / income", "percent",
     0.36, 0.20, "Financing burden as a share of income."),
    ("emergency_fund_months", "Emergency Fund Months", "liquid cash / monthly expense",
     "months", 3.0, 6.0, "Months of expense covered by liquid cash."),
    ("interest_burden_ratio", "Interest Burden", "interest expense / income", "percent",
     0.10, 0.05, "Cost of financing as a share of income."),
    ("maintenance_adjusted_fcf", "Maint-Adjusted FCF",
     "net income - depreciation", "currency", None, None,
     "Surplus after recognizing capital consumption."),
    ("net_worth", "Net Worth", "assets - liabilities", "currency", None, None,
     "Total assets minus total liabilities."),
]


def seed_definitions(conn):
    for code, name, formula, unit, warn, target, expl in DEFINITIONS:
        conn.execute(
            "INSERT OR IGNORE INTO kpi_definitions(code, name, formula, unit, "
            "warning_threshold, target_threshold, explanation) "
            "VALUES(?,?,?,?,?,?,?)",
            (code, name, formula, unit, warn, target, expl))


def _acct_sum(conn, prefix, *, start, end, signed=True):
    rows = reports._sums(conn, start=start, end=end)
    total = 0
    for r in rows:
        if r["code"].startswith(prefix):
            total += reports._signed_balance(r) if signed else (r["dr"] - r["cr"])
    return total


def compute(conn, period_label, *, store=True) -> dict:
    start, end = month_bounds(period_label)
    isr = reports.income_statement(conn, start=start, end=end)
    income = isr["total_income"]
    expense = isr["total_expense"]
    tax = sum(_acct_sum(conn, p, start=start, end=end) for p in ("5",))
    interest = _acct_sum(conn, "85", start=start, end=end)
    depreciation = _acct_sum(conn, "86", start=start, end=end)
    housing = next((x["amount"] for x in
                    reports.spending_by(conn, "service_line", start=start, end=end)
                    if x["name"] == "Housing"), 0)
    cash = 0
    for code in ("10100", "10200", "10300", "10400"):
        r = conn.execute("SELECT id FROM ledger_accounts WHERE code=?",
                         (code,)).fetchone()
        if r:
            from .imports import gl_balance_natural
            cash += gl_balance_natural(conn, r["id"], end=end)
    debt_pay = conn.execute(
        "SELECT COALESCE(SUM(total_cents),0) s FROM debt_payments "
        "WHERE payment_date>=? AND payment_date<=?", (start, end)).fetchone()["s"]
    nw = reports.net_worth(conn, end=end)["net_worth"]

    def ratio(n, d):
        return round(n / d, 4) if d else 0.0

    vals = {
        "savings_rate": ratio(income - expense, income),
        "effective_tax_rate": ratio(tax, income),
        "housing_cost_pct": ratio(housing, income),
        "debt_service_ratio": ratio(debt_pay, income),
        "emergency_fund_months": round(cash / expense, 2) if expense else 0.0,
        "interest_burden_ratio": ratio(interest, income),
        "maintenance_adjusted_fcf": (income - expense) - depreciation,
        "net_worth": nw,
    }
    if store:
        for code, v in vals.items():
            conn.execute(
                "INSERT INTO kpi_results(kpi_code, period_label, value) "
                "VALUES(?,?,?) ON CONFLICT(kpi_code, period_label) "
                "DO UPDATE SET value=excluded.value, computed_at=datetime('now')",
                (code, period_label, v))
    return vals
