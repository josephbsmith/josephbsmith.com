"""Web smoke test: every route serves, no dead/placeholder content, and the
principal workflows post through the engine. Runs the ASGI app in-process."""
import asyncio
import os
import tempfile

import httpx
import pytest

LOOP = asyncio.new_event_loop()

from backend.app import db, seed


@pytest.fixture(scope="module")
def app_client():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    os.environ["PERSONAL_ERP_DB"] = path
    db.init_db()
    c = db.connect(); seed.seed_reference(c); seed.seed_demo(c); c.close()
    from backend.app.main import app
    client = httpx.AsyncClient(transport=httpx.ASGITransport(app=app),
                               base_url="http://t", follow_redirects=True)
    yield client
    LOOP.run_until_complete(client.aclose())
    os.unlink(path)
    os.environ.pop("PERSONAL_ERP_DB", None)


def _get(client, path):
    return LOOP.run_until_complete(client.get(path))


def _post(client, path, **kw):
    return LOOP.run_until_complete(client.post(path, **kw))


ROUTES = ["/", "/accounts", "/accounts/new", "/journal", "/journal/new",
          "/journal/1", "/review", "/statements", "/reports", "/budget",
          "/assets", "/debt", "/scenarios", "/dimensions", "/close"]
DEAD = ["todo", "coming soon", "lorem ipsum", "not implemented",
        "traceback (most recent"]


@pytest.mark.parametrize("path", ROUTES)
def test_route_serves_without_dead_content(app_client, path):
    r = _get(app_client, path)
    assert r.status_code == 200, path
    low = r.text.lower()
    assert not any(m in low for m in DEAD), path


def _acct(code):
    c = db.connect()
    v = c.execute("SELECT id FROM ledger_accounts WHERE code=?", (code,)).fetchone()[0]
    c.close()
    return v


def _dim(table, name):
    c = db.connect()
    v = c.execute(f"SELECT id FROM {table} WHERE name=?", (name,)).fetchone()[0]
    c.close()
    return v


def test_post_and_reject_and_close_block(app_client):
    g, cash = _acct("60300"), _acct("10100")
    cc = _dim("cost_centers", "Household")
    sl = _dim("service_lines", "Nutrition")
    p = _dim("people", "Joint")
    # balanced entry posts
    r = _post(app_client, "/journal/new", data={
        "entry_date": "2026-07-22", "memo": "web groceries",
        "account_0": g, "debit_0": "42.10", "cc_0": cc, "sl_0": sl, "person_0": p,
        "account_1": cash, "credit_1": "42.10"})
    assert "web groceries" in r.text
    # unbalanced entry rejected
    r = _post(app_client, "/journal/new", data={
        "entry_date": "2026-07-22", "memo": "bad",
        "account_0": g, "debit_0": "10.00", "cc_0": cc, "sl_0": sl, "person_0": p,
        "account_1": cash, "credit_1": "5.00"})
    assert "balance" in r.text.lower()
    # hard-close July, posting is blocked
    c = db.connect()
    pid = c.execute("SELECT id FROM accounting_periods WHERE label='2026-07'").fetchone()[0]
    c.close()
    _post(app_client, f"/close/period/{pid}", data={"status": "hard_closed", "reason": ""})
    r = _post(app_client, "/journal/new", data={
        "entry_date": "2026-07-23", "memo": "blocked",
        "account_0": g, "debit_0": "5.00", "cc_0": cc, "sl_0": sl, "person_0": p,
        "account_1": cash, "credit_1": "5.00"})
    assert "hard-closed" in r.text.lower()


def test_account_create_derives_and_rejects(app_client):
    # create: only code + name; type/normal/dims derived from the code
    r = _post(app_client, "/accounts/new",
              data={"code": "52950", "name": "Web-Added Utility"})
    assert r.status_code == 200  # followed redirect to /accounts
    lst = _get(app_client, "/accounts").text
    assert "52950" in lst and "Web-Added Utility" in lst
    # 5xxxx -> expense, debit-normal, requires dimensions
    c = db.connect()
    a = c.execute("SELECT type, normal_balance, requires_dimensions "
                  "FROM ledger_accounts WHERE code='52950'").fetchone()
    c.close()
    assert a[0] == "expense" and a[1] == "debit" and a[2] == 1
    # duplicate code rejected, form re-renders with error
    r = _post(app_client, "/accounts/new", data={"code": "52950", "name": "Dup"})
    assert "already exists" in r.text
    # malformed code rejected
    r = _post(app_client, "/accounts/new", data={"code": "9", "name": "x"})
    assert "5 digits" in r.text
