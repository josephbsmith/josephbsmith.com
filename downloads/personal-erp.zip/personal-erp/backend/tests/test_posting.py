"""Posting-engine invariants (brief section 26.7)."""
import pytest

from backend.app import posting, reports
from backend.app.posting import PostingError
from backend.tests.conftest import acct


def _simple_lines(conn, dr_code, cr_code, cents, dims=None):
    dims = dims or {}
    return [
        {"account_id": acct(conn, dr_code), "debit_cents": cents,
         "credit_cents": 0, **dims},
        {"account_id": acct(conn, cr_code), "debit_cents": 0,
         "credit_cents": cents},
    ]


def _dims(conn):
    cc = conn.execute("SELECT id FROM cost_centers WHERE name='Household'").fetchone()["id"]
    sl = conn.execute("SELECT id FROM service_lines WHERE name='Nutrition'").fetchone()["id"]
    p = conn.execute("SELECT id FROM people WHERE name='Joint'").fetchone()["id"]
    return {"cost_center_id": cc, "service_line_id": sl, "person_id": p}


def test_balanced_entry_posts(conn):
    eid = posting.post_entry(conn, "2026-07-08", "groceries",
                             _simple_lines(conn, "60300", "10100", 18234, _dims(conn)))
    row = conn.execute("SELECT status FROM journal_entries WHERE id=?", (eid,)).fetchone()
    assert row["status"] == "posted"


def test_unbalanced_entry_rejected(conn):
    lines = _simple_lines(conn, "60300", "10100", 18234, _dims(conn))
    lines[1]["credit_cents"] = 10000  # break balance
    with pytest.raises(PostingError, match="balance"):
        posting.post_entry(conn, "2026-07-08", "bad", lines)


def test_posted_entry_is_immutable(conn):
    eid = posting.post_entry(conn, "2026-07-08", "g",
                             _simple_lines(conn, "60300", "10100", 100, _dims(conn)))
    with pytest.raises(PostingError, match="immutable"):
        posting.assert_editable(conn, eid)


def test_required_dimensions_enforced(conn):
    # expense line without required dims is rejected
    with pytest.raises(PostingError, match="requires"):
        posting.post_entry(conn, "2026-07-08", "no dims",
                           _simple_lines(conn, "60300", "10100", 100))


def test_inactive_account_rejected(conn):
    conn.execute("UPDATE ledger_accounts SET is_active=0 WHERE code='60300'")
    with pytest.raises(PostingError, match="inactive"):
        posting.post_entry(conn, "2026-07-08", "x",
                           _simple_lines(conn, "60300", "10100", 100, _dims(conn)))


def test_no_period_rejected(conn):
    with pytest.raises(PostingError, match="period"):
        posting.post_entry(conn, "2030-01-01", "future",
                           _simple_lines(conn, "60300", "10100", 100, _dims(conn)))


def test_hard_closed_period_blocks_posting(conn):
    pid = conn.execute("SELECT id FROM accounting_periods WHERE label='2026-07'").fetchone()["id"]
    posting.set_period_status(conn, pid, "hard_closed")
    with pytest.raises(PostingError, match="hard-closed"):
        posting.post_entry(conn, "2026-07-08", "blocked",
                           _simple_lines(conn, "60300", "10100", 100, _dims(conn)))


def test_soft_closed_period_allows_posting(conn):
    pid = conn.execute("SELECT id FROM accounting_periods WHERE label='2026-07'").fetchone()["id"]
    posting.set_period_status(conn, pid, "soft_closed")
    eid = posting.post_entry(conn, "2026-07-08", "ok",
                             _simple_lines(conn, "60300", "10100", 100, _dims(conn)))
    assert eid


def test_reopen_requires_reason(conn):
    pid = conn.execute("SELECT id FROM accounting_periods WHERE label='2026-07'").fetchone()["id"]
    with pytest.raises(PostingError, match="reason"):
        posting.set_period_status(conn, pid, "reopened")


def test_reversal_creates_mirror_entry(conn):
    eid = posting.post_entry(conn, "2026-07-08", "g",
                             _simple_lines(conn, "60300", "10100", 500, _dims(conn)))
    rid = posting.reverse_entry(conn, eid, reason="mistake")
    orig = conn.execute("SELECT status, reversed_by_entry_id FROM journal_entries WHERE id=?", (eid,)).fetchone()
    assert orig["status"] == "reversed"
    assert orig["reversed_by_entry_id"] == rid
    # net effect on the expense account is zero after reversal
    tb = reports.trial_balance(conn, end="2026-07-31")
    g = next(r for r in tb["rows"] if r["code"] == "60300")
    assert g["debit"] == 0 and g["credit"] == 0


def test_trial_balance_balances(demo_conn):
    tb = reports.trial_balance(demo_conn, end="2026-07-31")
    assert tb["balanced"]
    assert tb["total_debit"] == tb["total_credit"]


def test_income_statement_excludes_balance_sheet_accounts(demo_conn):
    isr = reports.income_statement(demo_conn, start="2026-07-01", end="2026-07-31")
    codes = {r["code"] for r in isr["income"] + isr["expense"]}
    assert all(c[0] in "45678" for c in codes)


def test_balance_sheet_balances(demo_conn):
    bs = reports.balance_sheet(demo_conn, end="2026-07-31")
    assert bs["balanced"]
    assert bs["total_assets"] == bs["total_liabilities"] + bs["total_equity"]
