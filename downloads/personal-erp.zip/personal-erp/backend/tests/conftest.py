import os
import tempfile
import pytest

from backend.app import db, seed


@pytest.fixture
def conn():
    """Fresh seeded in-file DB per test (reference data only)."""
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    os.environ["PERSONAL_ERP_DB"] = path
    db.init_db()
    c = db.connect()
    seed.seed_reference(c)
    yield c
    c.close()
    os.unlink(path)
    os.environ.pop("PERSONAL_ERP_DB", None)


@pytest.fixture
def demo_conn():
    """Fresh DB with full demo household."""
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    os.environ["PERSONAL_ERP_DB"] = path
    db.init_db()
    c = db.connect()
    seed.seed_reference(c)
    seed.seed_demo(c)
    yield c
    c.close()
    os.unlink(path)
    os.environ.pop("PERSONAL_ERP_DB", None)


def acct(conn, code):
    return conn.execute("SELECT id FROM ledger_accounts WHERE code=?",
                        (code,)).fetchone()["id"]
