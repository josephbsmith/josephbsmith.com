"""Subledger + reconciliation + planning reconcile to the ledger."""
from backend.app import imports, assets, debt, budgets, reports, kpis, scenarios


def _asset_id(conn):
    return conn.execute("SELECT id FROM assets LIMIT 1").fetchone()["id"]


def _loan_id(conn):
    return conn.execute("SELECT id FROM debt_accounts LIMIT 1").fetchone()["id"]


def test_statements_reconcile(demo_conn):
    for s in demo_conn.execute("SELECT id FROM month_end_statements").fetchall():
        r = imports.reconcile(demo_conn, s["id"])
        assert r["reconciled"], r


def test_depreciation_run_is_balanced_and_recorded(demo_conn):
    aid = _asset_id(demo_conn)
    # July already run in demo; book value reflects one month
    monthly = assets.monthly_amount(demo_conn, aid)
    assert monthly == 166667  # (121000-21000)/60 * 100 cents
    assert assets.accumulated(demo_conn, aid) == 166667
    # the depreciation JE balances (checked globally by trial balance)
    assert reports.trial_balance(demo_conn, end="2026-07-31")["balanced"]


def test_depreciation_not_run_twice(demo_conn):
    aid = _asset_id(demo_conn)
    import pytest
    from backend.app.posting import PostingError
    with pytest.raises(PostingError, match="already"):
        assets.run_depreciation(demo_conn, aid, "2026-07", "2026-07-31")


def test_debt_payment_splits_interest_and_principal(demo_conn):
    lid = _loan_id(demo_conn)
    # demo: 50000 principal at 5% -> ~208.33 interest; 600 payment
    pay = demo_conn.execute(
        "SELECT interest_cents, principal_cents, total_cents FROM debt_payments "
        "WHERE debt_account_id=? ORDER BY id DESC LIMIT 1", (lid,)).fetchone()
    assert pay["interest_cents"] + pay["principal_cents"] == pay["total_cents"]
    assert pay["interest_cents"] == 20833
    assert pay["principal_cents"] == 39167


def test_debt_principal_reduced(demo_conn):
    lid = _loan_id(demo_conn)
    d = demo_conn.execute("SELECT current_principal_cents FROM debt_accounts WHERE id=?",
                          (lid,)).fetchone()
    assert d["current_principal_cents"] == 5000000 - 39167


def test_amortization_pays_off(demo_conn):
    lid = _loan_id(demo_conn)
    sched = debt.amortization_schedule(demo_conn, lid, 25000)
    assert sched[-1]["balance_cents"] <= 0


def test_budget_vs_actual(demo_conn):
    bv = demo_conn.execute("SELECT id FROM budget_versions LIMIT 1").fetchone()["id"]
    bva = budgets.budget_vs_actual(demo_conn, bv, "2026-07")
    groceries = next(r for r in bva["rows"] if r["code"] == "60300")
    assert groceries["budget"] == 30000
    assert groceries["actual"] == 32100        # Duff Megamart charge
    assert groceries["variance"] == 32100 - 30000


def test_kpis_compute(demo_conn):
    v = kpis.compute(demo_conn, "2026-07", store=False)
    assert v["net_worth"] == reports.net_worth(demo_conn, end="2026-07-31")["net_worth"]
    assert 0 <= v["savings_rate"] <= 1


def test_scenario_inherits_from_base(demo_conn):
    shock = demo_conn.execute("SELECT id FROM scenario_versions WHERE name='Income Shock'").fetchone()["id"]
    a = scenarios.resolved_assumptions(demo_conn, shock)
    # overridden
    assert a["monthly_income_cents"] == "2940000"
    # inherited from base
    assert a["monthly_expense_cents"] == "1210000"


def test_imported_transaction_becomes_posted_journal(demo_conn):
    posted = demo_conn.execute(
        "SELECT COUNT(*) n FROM imported_transactions WHERE status='posted' "
        "AND journal_entry_id IS NOT NULL").fetchone()["n"]
    assert posted >= 6
