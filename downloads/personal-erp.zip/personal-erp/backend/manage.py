#!/usr/bin/env python
"""Management CLI: init / seed / reset / run / backup / restore.

Usage:
  python -m backend.manage <command>

Commands:
  init      create schema in the DB file
  seed      seed reference data (chart of accounts, dimensions, periods)
  demo      seed the demo household (requires reference data)
  reset     delete the DB and rebuild it: init + seed + demo   (clean start)
  run       launch the web app (uvicorn) on http://127.0.0.1:8001
  backup    copy the DB to backups/personal_erp_<timestamp>.db
  restore   restore the DB from a backup file (path arg)
"""
import shutil
import sys
from datetime import datetime
from pathlib import Path

from backend.app import db, seed

BACKUP_DIR = Path(__file__).resolve().parent / "backups"


def cmd_init():
    db.init_db()
    print(f"initialized schema in {db.db_path()}")


def cmd_seed():
    with db.connect() as conn:
        seed.seed_reference(conn)
    print("seeded reference data")


def cmd_demo():
    with db.connect() as conn:
        result = seed.seed_demo(conn)
    print("seeded demo household")
    print(f"  checking reconciliation: {result['checking_recon']}")
    print(f"  credit card reconciliation: {result['cc_recon']}")


def cmd_reset():
    p = db.db_path()
    if p.exists():
        p.unlink()
    cmd_init(); cmd_seed(); cmd_demo()
    print("clean start complete")


def cmd_backup():
    BACKUP_DIR.mkdir(exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    dest = BACKUP_DIR / f"personal_erp_{ts}.db"
    shutil.copy2(db.db_path(), dest)
    print(f"backed up to {dest}")


def cmd_restore():
    if len(sys.argv) < 3:
        sys.exit("usage: manage.py restore <backup-file>")
    shutil.copy2(sys.argv[2], db.db_path())
    print(f"restored {db.db_path()} from {sys.argv[2]}")


def cmd_run():
    import uvicorn
    uvicorn.run("backend.app.main:app", host="127.0.0.1", port=8001, reload=False)


COMMANDS = {"init": cmd_init, "seed": cmd_seed, "demo": cmd_demo,
            "reset": cmd_reset, "run": cmd_run, "backup": cmd_backup,
            "restore": cmd_restore}


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in COMMANDS:
        sys.exit(__doc__)
    COMMANDS[sys.argv[1]]()


if __name__ == "__main__":
    main()
