import * as pdfjsLib from "/vendor/pdf.mjs";

pdfjsLib.GlobalWorkerOptions.workerSrc = "/vendor/pdf.worker.mjs";

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const dom = {
  appHeader: $(".app-header"),
  appGrid: $(".app-grid"),
  fileInput: $("#file-input"),
  dropTarget: $("#drop-target"),
  documentList: $("#document-list"),
  libraryCount: $("#library-count"),
  libraryFilter: $("#library-filter"),
  adaptiveActions: $("#adaptive-actions"),
  aboutDialog: $("#about-dialog"),
  aboutDataDir: $("#about-data-dir"),
  emptyState: $("#empty-state"),
  reader: $("#reader"),
  title: $("#document-title"),
  meta: $("#document-meta"),
  canvas: $("#pdf-canvas"),
  textLayer: $("#text-layer"),
  linkLayer: $("#link-layer"),
  pageShell: $("#page-shell"),
  pageStage: $("#page-stage"),
  loading: $("#page-loading"),
  annotationLayer: $("#annotation-layer"),
  drawBox: $("#draw-box"),
  pageNumber: $("#page-number"),
  pageCount: $("#page-count"),
  zoomLabel: $("#zoom-label"),
  documentSearch: $("#document-search"),
  searchResults: $("#search-results"),
  searchCount: $("#search-count"),
  annotationList: $("#annotation-list"),
  annotationCount: $("#annotation-count"),
  provenance: $("#provenance"),
  noteDialog: $("#note-dialog"),
  noteDialogTitle: $("#note-dialog-title"),
  noteText: $("#note-text"),
  noteColor: $("#note-color"),
  saveNote: $("#save-note"),
  deleteNote: $("#delete-note"),
  textDialog: $("#text-dialog"),
  textDialogTitle: $("#text-dialog-title"),
  replacementText: $("#replacement-text"),
  textColor: $("#text-color"),
  saveText: $("#save-text"),
  deleteText: $("#delete-text"),
  pdfNoteDialog: $("#pdf-note-dialog"),
  pdfNoteText: $("#pdf-note-text"),
  signatureDialog: $("#signature-dialog"),
  signaturePad: $("#signature-pad"),
  organizerDialog: $("#organize-dialog"),
  organizerPages: $("#organizer-pages"),
  organizerName: $("#organizer-name"),
  rotationDegrees: $("#rotation-degrees"),
  mergeDialog: $("#merge-dialog"),
  mergeList: $("#merge-list"),
  mergeName: $("#merge-name"),
  trashDialog: $("#trash-dialog"),
  trashList: $("#trash-list"),
  backupList: $("#backup-list"),
  toast: $("#toast")
};

const state = {
  documents: [],
  current: null,
  pdf: null,
  page: 1,
  zoom: 1.15,
  fit: "width",
  renderTask: null,
  textLayer: null,
  renderToken: 0,
  annotations: [],
  nativeNotes: new Map(),
  tool: "select",
  drawStart: null,
  pendingNote: null,
  pendingText: null,
  editingAnnotation: null,
  signature: null,
  signatureHasInk: false,
  searchTimer: null,
  resizeTimer: null,
  toastTimer: null,
  busy: false,
  status: null,
  librarySearchResults: null,
  librarySearchTimer: null
};

function element(tag, options = {}, children = []) {
  const node = document.createElement(tag);
  if (options.className) node.className = options.className;
  if (options.text != null) node.textContent = options.text;
  if (options.type) node.type = options.type;
  if (options.title) node.title = options.title;
  if (options.dataset) Object.assign(node.dataset, options.dataset);
  for (const child of children) node.append(child);
  return node;
}

async function api(path, options = {}, retried = false) {
  const response = await fetch(path, options);
  const type = response.headers.get("content-type") || "";
  const payload = type.includes("application/json") ? await response.json() : null;
  if (response.status === 401 && !retried) {
    await fetch("/", { cache: "no-store" });
    return api(path, options, true);
  }
  if (!response.ok) throw new Error(payload?.error || `Request failed (${response.status}).`);
  return payload;
}

function showToast(message, isError = false) {
  clearTimeout(state.toastTimer);
  dom.toast.textContent = message;
  dom.toast.classList.toggle("error", isError);
  dom.toast.classList.add("show");
  state.toastTimer = setTimeout(() => dom.toast.classList.remove("show"), 3400);
}

function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
}

function formatDate(value) {
  return new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(new Date(value));
}

function baseName(name) {
  return name.replace(/\.pdf$/i, "");
}

function setBusy(busy, message = "") {
  state.busy = busy;
  dom.appHeader.inert = busy;
  dom.appGrid.inert = busy;
  for (const dialog of $$("dialog")) dialog.inert = busy;
  dom.loading.textContent = message;
}

async function loadLibrary({ preserveSelection = true } = {}) {
  const selectedId = preserveSelection ? state.current?.id : null;
  const [{ documents }, adaptive] = await Promise.all([api("/api/documents"), api("/api/adaptive")]);
  state.documents = documents;
  if (selectedId) state.current = documents.find((document) => document.id === selectedId) || state.current;
  renderLibrary();
  renderAdaptive(adaptive.actions);
}

function renderLibrary() {
  const query = dom.libraryFilter.value.trim().toLowerCase();
  const matches = new Map((state.librarySearchResults || []).map((result) => [result.document_id, result]));
  const documents = query
    ? state.documents.filter((document) => document.name.toLowerCase().includes(query) || matches.has(document.id))
    : state.documents;
  dom.libraryCount.textContent = `${state.documents.length} document${state.documents.length === 1 ? "" : "s"}`;
  dom.documentList.replaceChildren();
  if (query && state.librarySearchResults === null) {
    dom.documentList.append(element("p", { className: "quiet", text: "Searching filenames, PDF text, and annotations…" }));
    return;
  }
  if (!documents.length) {
    dom.documentList.append(element("p", { className: "quiet", text: query ? "No matching PDFs or annotations." : "Your local library is empty." }));
    return;
  }
  for (const document of documents) {
    const icon = element("span", { className: "document-icon", text: "PDF" });
    const copy = element("span", {}, [
      element("strong", { text: document.name }),
      element("small", { text: matches.get(document.id)?.snippet || `${document.page_count} page${document.page_count === 1 ? "" : "s"} · ${formatSize(document.size)}${document.annotation_count ? ` · ${document.annotation_count} mark${document.annotation_count === 1 ? "" : "s"}` : ""}` })
    ]);
    const button = element("button", {
      className: `document-card${state.current?.id === document.id ? " active" : ""}`,
      type: "button",
      title: document.name
    }, [icon, copy]);
    button.addEventListener("click", () => openDocument(document.id));
    dom.documentList.append(button);
  }
}

async function searchLibrary() {
  const query = dom.libraryFilter.value.trim();
  if (!query) {
    state.librarySearchResults = null;
    renderLibrary();
    return;
  }
  state.librarySearchResults = null;
  renderLibrary();
  try {
    const { results } = await api(`/api/search?q=${encodeURIComponent(query)}`);
    if (query === dom.libraryFilter.value.trim()) {
      state.librarySearchResults = results;
      renderLibrary();
    }
  } catch (error) {
    if (query === dom.libraryFilter.value.trim()) {
      state.librarySearchResults = [];
      renderLibrary();
      showToast(error.message, true);
    }
  }
}

function renderAdaptive(actions) {
  const labels = {
    import: "Import PDF",
    open: "Resume reading",
    search: "Search text",
    highlight: "Highlight",
    note: "Add note",
    text: "Overlay text",
    signature: "Sign",
    merge: "Merge",
    rotate: "Rotate pages",
    extract: "Extract pages",
    reorder: "Reorder pages",
    delete: "Remove pages",
    ocr: "OCR",
    "export-annotations": "Export marks"
  };
  const usable = actions.filter((item) => labels[item.action] && item.action !== "open").slice(0, 5);
  dom.adaptiveActions.replaceChildren();
  if (!usable.length) {
    dom.adaptiveActions.append(element("span", { className: "quiet", text: "They will reorder as you work." }));
    return;
  }
  for (const item of usable) {
    const button = element("button", { className: "shortcut-chip", type: "button", text: labels[item.action], title: `Used ${item.count} times recently` });
    button.addEventListener("click", () => invokeShortcut(item.action));
    dom.adaptiveActions.append(button);
  }
}

function invokeShortcut(action) {
  if (action === "import") return dom.fileInput.click();
  if (action === "merge") return openMerge();
  if (!state.current) return showToast("Open a PDF first.", true);
  if (["rotate", "extract", "reorder", "delete"].includes(action)) return openOrganizer();
  if (action === "ocr") return runOcr();
  if (action === "export-annotations") return exportAnnotations();
  if (["highlight", "note", "text", "signature"].includes(action)) return setTool(action);
  if (action === "search") dom.documentSearch.focus();
}

async function importFiles(fileList) {
  if (state.busy) return;
  const files = [...fileList].filter((file) => file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf"));
  if (!files.length) return showToast("Choose one or more PDF files.", true);
  setBusy(true, `Importing 1 of ${files.length}…`);
  let firstId = null;
  try {
    for (let index = 0; index < files.length; index++) {
      dom.loading.textContent = `Importing ${index + 1} of ${files.length}…`;
      const result = await api(`/api/documents?name=${encodeURIComponent(files[index].name)}`, {
        method: "POST",
        headers: { "Content-Type": "application/pdf" },
        body: files[index]
      });
      firstId ||= result.document.id;
    }
    await loadLibrary({ preserveSelection: false });
    if (firstId) await openDocument(firstId, { force: true });
    showToast(`${files.length} PDF${files.length === 1 ? "" : "s"} imported.`);
  } catch (error) {
    showToast(error.message, true);
  } finally {
    dom.fileInput.value = "";
    setBusy(false, "");
  }
}

async function openDocument(id, { force = false } = {}) {
  if (state.busy && !force) return;
  const document = state.documents.find((item) => item.id === id);
  if (!document) return showToast("Document not found.", true);
  state.current = document;
  state.page = Math.min(document.page_count, Math.max(1, document.current_page || 1));
  state.zoom = document.zoom || 1.15;
  state.fit = document.fit || "width";
  state.annotations = [];
  state.nativeNotes = new Map();
  state.pdf = null;
  state.renderToken++;
  renderLibrary();
  dom.emptyState.hidden = true;
  dom.reader.hidden = false;
  dom.title.textContent = document.name;
  dom.meta.textContent = `${document.page_count} page${document.page_count === 1 ? "" : "s"} · ${formatSize(document.size)}`;
  dom.pageCount.textContent = `of ${document.page_count}`;
  dom.pageNumber.max = String(document.page_count);
  dom.documentSearch.value = "";
  renderSearchResults([]);
  renderProvenance();
  setTool("select");
  setBusy(true, "Opening PDF…");
  try {
    const [, annotationResult, pdf] = await Promise.all([
      api(`/api/documents/${id}/open`, { method: "POST" }),
      api(`/api/documents/${id}/annotations`),
      pdfjsLib.getDocument({ url: `/api/documents/${id}/file` }).promise
    ]);
    if (state.current?.id !== id) return;
    state.annotations = annotationResult.annotations;
    state.pdf = pdf;
    await renderPage();
    renderAnnotationList();
    await loadLibrary();
  } catch (error) {
    showToast(error.message, true);
  } finally {
    setBusy(false, "");
  }
}

function renderProvenance() {
  const document = state.current;
  const sources = document.source_ids?.length ? `${document.source_ids.length} source document${document.source_ids.length === 1 ? "" : "s"}` : "Local import";
  const values = [
    ["Created", formatDate(document.imported_at)],
    ["Origin", document.source_type === "import" ? "Imported file" : document.source_type],
    ["Based on", sources],
    ["Checksum", document.sha256.slice(0, 16) + "…"]
  ];
  dom.provenance.replaceChildren();
  for (const [term, definition] of values) {
    dom.provenance.append(element("dt", { text: term }), element("dd", { text: definition }));
  }
}

async function renderPage() {
  if (!state.pdf || !state.current) return;
  const token = ++state.renderToken;
  if (state.renderTask) {
    try { state.renderTask.cancel(); } catch {}
  }
  try { state.textLayer?.cancel(); } catch {}
  dom.textLayer.replaceChildren();
  dom.linkLayer.replaceChildren();
  dom.loading.textContent = `Rendering page ${state.page}…`;
  try {
    const page = await state.pdf.getPage(state.page);
    const natural = page.getViewport({ scale: 1 });
    const availableWidth = Math.max(200, dom.pageStage.clientWidth - 60);
    const availableHeight = Math.max(200, dom.pageStage.clientHeight - 60);
    let scale = state.zoom;
    if (state.fit === "width") scale = availableWidth / natural.width;
    if (state.fit === "page") scale = Math.min(availableWidth / natural.width, availableHeight / natural.height);
    scale = Math.min(5, Math.max(0.25, scale));
    state.zoom = scale;
    const viewport = page.getViewport({ scale });
    const pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
    dom.canvas.width = Math.floor(viewport.width * pixelRatio);
    dom.canvas.height = Math.floor(viewport.height * pixelRatio);
    dom.canvas.style.width = `${viewport.width}px`;
    dom.canvas.style.height = `${viewport.height}px`;
    dom.pageShell.style.width = `${viewport.width}px`;
    dom.pageShell.style.height = `${viewport.height}px`;
    const context = dom.canvas.getContext("2d", { alpha: false });
    state.renderTask = page.render({
      canvasContext: context,
      viewport,
      transform: pixelRatio === 1 ? null : [pixelRatio, 0, 0, pixelRatio, 0, 0]
    });
    await state.renderTask.promise;
    if (token !== state.renderToken) return;
    await renderPdfLayers(page, viewport, token);
    if (token !== state.renderToken) return;
    dom.pageNumber.value = String(state.page);
    dom.zoomLabel.textContent = state.fit === "custom"
      ? `${Math.round(state.zoom * 100)}%`
      : `${state.fit === "page" ? "Fit page" : "Fit width"} (${Math.round(state.zoom * 100)}%)`;
    renderAnnotations();
    persistReadingState();
  } catch (error) {
    if (error?.name !== "RenderingCancelledException") showToast(`Could not render page: ${error.message}`, true);
  } finally {
    if (token === state.renderToken) dom.loading.textContent = "";
  }
}

function contrastingTextColor(color) {
  const match = /^#([0-9a-f]{6})$/i.exec(color || "");
  if (!match) return "#1b211d";
  const channels = match[1].match(/../g).map((part) => Number.parseInt(part, 16) / 255)
    .map((value) => value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4);
  const luminance = channels[0] * 0.2126 + channels[1] * 0.7152 + channels[2] * 0.0722;
  return luminance < 0.42 ? "#ffffff" : "#1b211d";
}

function openPdfNote(note) {
  dom.pdfNoteText.textContent = note.text;
  if (!dom.pdfNoteDialog.open) dom.pdfNoteDialog.showModal();
  dom.pdfNoteText.focus();
}

async function renderPdfLayers(page, viewport, token) {
  state.textLayer = new pdfjsLib.TextLayer({
    textContentSource: page.streamTextContent({ includeMarkedContent: true, disableNormalization: true }),
    container: dom.textLayer,
    viewport
  });
  const annotationsPromise = page.getAnnotations({ intent: "display" });
  await state.textLayer.render();
  if (token !== state.renderToken) return;

  const annotations = await annotationsPromise;
  if (token !== state.renderToken) return;
  const nativeNotes = [];
  for (const annotation of annotations) {
    const contents = String(annotation.contentsObj?.str ?? annotation.contents ?? "").trim();
    if ((annotation.subtype === "Text" || annotation.annotationType === 1) && contents) {
      const start = viewport.convertToViewportPoint(annotation.rect[0], annotation.rect[1]);
      const end = viewport.convertToViewportPoint(annotation.rect[2], annotation.rect[3]);
      const rect = [...start, ...end];
      const channels = Array.from(annotation.color || []);
      const color = channels.length === 3
        ? `#${channels.map((value) => Math.round(Number(value) <= 1 ? Number(value) * 255 : Number(value)).toString(16).padStart(2, "0")).join("")}`
        : "#f6c945";
      const note = { id: annotation.id || `pdf-note-${state.page}-${nativeNotes.length}`, page: state.page, text: contents, color, native: true };
      nativeNotes.push(note);
      const button = element("button", { className: "pdf-note", type: "button", text: "N", title: "Read PDF sticky note" });
      button.setAttribute("aria-label", `Read PDF sticky note on page ${state.page}`);
      button.style.left = `${Math.min(rect[0], rect[2])}px`;
      button.style.top = `${Math.min(rect[1], rect[3])}px`;
      button.style.width = `${Math.abs(rect[0] - rect[2])}px`;
      button.style.height = `${Math.abs(rect[1] - rect[3])}px`;
      button.style.backgroundColor = color;
      button.style.color = contrastingTextColor(color);
      button.addEventListener("click", () => openPdfNote(note));
      dom.linkLayer.append(button);
      continue;
    }
    if (!annotation.url && !annotation.dest) continue;
    const start = viewport.convertToViewportPoint(annotation.rect[0], annotation.rect[1]);
    const end = viewport.convertToViewportPoint(annotation.rect[2], annotation.rect[3]);
    const rect = [...start, ...end];
    const link = element("a", {
      className: "pdf-link",
      title: annotation.url || "Open linked page"
    });
    link.setAttribute("aria-label", annotation.url ? `Open ${annotation.url}` : "Open linked page");
    link.style.left = `${Math.min(rect[0], rect[2])}px`;
    link.style.top = `${Math.min(rect[1], rect[3])}px`;
    link.style.width = `${Math.abs(rect[0] - rect[2])}px`;
    link.style.height = `${Math.abs(rect[1] - rect[3])}px`;
    if (annotation.url) {
      link.href = annotation.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
    } else if (annotation.dest) {
      link.href = "#";
      link.addEventListener("click", async (event) => {
        event.preventDefault();
        try {
          const destination = typeof annotation.dest === "string" ? await state.pdf.getDestination(annotation.dest) : annotation.dest;
          const target = destination?.[0];
          const index = Number.isInteger(target) ? target : await state.pdf.getPageIndex(target);
          goToPage(index + 1);
        } catch {
          showToast("That PDF link could not be opened.", true);
        }
      });
    } else {
      continue;
    }
    dom.linkLayer.append(link);
  }
  state.nativeNotes.set(state.page, nativeNotes);
  renderAnnotationList();
}

function persistReadingState() {
  if (!state.current) return;
  api(`/api/documents/${state.current.id}/state`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ page: state.page, zoom: state.zoom, fit: state.fit })
  }).catch(() => {});
}

function goToPage(page) {
  if (state.busy || !state.pdf) return;
  const next = Math.min(state.current.page_count, Math.max(1, Number(page) || 1));
  if (next === state.page) return;
  state.page = next;
  renderPage();
}

function changeZoom(delta) {
  if (state.busy) return;
  state.fit = "custom";
  state.zoom = Math.min(5, Math.max(0.25, state.zoom + delta));
  renderPage();
}

function cycleFit() {
  if (state.busy) return;
  state.fit = state.fit === "width" ? "page" : "width";
  renderPage();
}

function setTool(tool) {
  state.tool = tool;
  $$(".tool-button").forEach((button) => button.classList.toggle("active", button.dataset.tool === tool));
  dom.annotationLayer.classList.toggle("drawing", tool !== "select");
  if (tool === "signature" && !state.signature) {
    clearSignature();
    dom.signatureDialog.showModal();
  }
}

function annotationRect(event) {
  const bounds = dom.annotationLayer.getBoundingClientRect();
  return {
    x: Math.min(1, Math.max(0, (event.clientX - bounds.left) / bounds.width)),
    y: Math.min(1, Math.max(0, (event.clientY - bounds.top) / bounds.height))
  };
}

function startDrawing(event) {
  if (state.busy || state.tool === "select" || !state.current) return;
  event.preventDefault();
  const point = annotationRect(event);
  if (state.tool === "note") {
    state.editingAnnotation = null;
    state.pendingNote = point;
    dom.noteText.value = "";
    dom.noteColor.value = "#f6c945";
    dom.noteDialogTitle.textContent = "Add a note";
    dom.saveNote.textContent = "Place note";
    dom.deleteNote.hidden = true;
    dom.noteDialog.showModal();
    return;
  }
  if (state.tool === "text") {
    state.editingAnnotation = null;
    state.pendingText = point;
    dom.replacementText.value = "";
    dom.textColor.value = "#1b211d";
    dom.textDialogTitle.textContent = "Place overlay text";
    dom.saveText.textContent = "Place text";
    dom.deleteText.hidden = true;
    dom.textDialog.showModal();
    return;
  }
  if (state.tool === "signature") {
    if (!state.signature) return dom.signatureDialog.showModal();
    createAnnotation({ type: "signature", ...placedBox(point, 0.25, 0.09), text: state.signature, color: "#245640" });
    return;
  }
  state.drawStart = point;
  dom.drawBox.hidden = false;
  updateDrawBox(point, point);
  dom.annotationLayer.setPointerCapture?.(event.pointerId);
}

function placedBox(point, width, height) {
  return { x: Math.min(point.x, 1 - width), y: Math.min(point.y, 1 - height), width, height };
}

function moveDrawing(event) {
  if (!state.drawStart || state.tool !== "highlight") return;
  updateDrawBox(state.drawStart, annotationRect(event));
}

function finishDrawing(event) {
  if (!state.drawStart || state.tool !== "highlight") return;
  const start = state.drawStart;
  const end = annotationRect(event);
  state.drawStart = null;
  dom.drawBox.hidden = true;
  const annotation = {
    type: "highlight",
    x: Math.min(start.x, end.x),
    y: Math.min(start.y, end.y),
    width: Math.abs(end.x - start.x),
    height: Math.abs(end.y - start.y),
    text: "",
    color: "#f6c945"
  };
  if (annotation.width < 0.005 || annotation.height < 0.003) return;
  createAnnotation(annotation);
}

function updateDrawBox(start, end) {
  const left = Math.min(start.x, end.x) * 100;
  const top = Math.min(start.y, end.y) * 100;
  dom.drawBox.style.left = `${left}%`;
  dom.drawBox.style.top = `${top}%`;
  dom.drawBox.style.width = `${Math.abs(end.x - start.x) * 100}%`;
  dom.drawBox.style.height = `${Math.abs(end.y - start.y) * 100}%`;
}

async function createAnnotation(annotation) {
  try {
    const result = await api(`/api/documents/${state.current.id}/annotations`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...annotation, page: state.page })
    });
    state.annotations.push(result.annotation);
    renderAnnotations();
    renderAnnotationList();
    loadLibrary();
    showToast(annotation.type === "text" ? "Text overlay added." : `${annotation.type[0].toUpperCase()}${annotation.type.slice(1)} added.`);
    return true;
  } catch (error) {
    showToast(error.message, true);
    return false;
  }
}

function editAnnotation(event, annotation, node, mode) {
  if (state.tool !== "select" || event.button !== 0) return;
  event.preventDefault();
  event.stopPropagation();
  const bounds = dom.annotationLayer.getBoundingClientRect();
  const start = { x: event.clientX, y: event.clientY, left: annotation.x, top: annotation.y, width: annotation.width, height: annotation.height };
  let changed = false;

  const move = (nextEvent) => {
    const dx = (nextEvent.clientX - start.x) / bounds.width;
    const dy = (nextEvent.clientY - start.y) / bounds.height;
    if (Math.abs(dx) > 0.002 || Math.abs(dy) > 0.002) changed = true;
    if (mode === "resize") {
      annotation.width = Math.min(1 - annotation.x, Math.max(0.012, start.width + dx));
      annotation.height = Math.min(1 - annotation.y, Math.max(0.012, start.height + dy));
    } else {
      annotation.x = Math.min(1 - annotation.width, Math.max(0, start.left + dx));
      annotation.y = Math.min(1 - annotation.height, Math.max(0, start.top + dy));
    }
    node.style.left = `${annotation.x * 100}%`;
    node.style.top = `${annotation.y * 100}%`;
    node.style.width = `${annotation.width * 100}%`;
    node.style.height = `${annotation.height * 100}%`;
  };

  const finish = async () => {
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", finish);
    if (!changed) return;
    node.dataset.dragged = "true";
    try {
      const result = await api(`/api/annotations/${annotation.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ x: annotation.x, y: annotation.y, width: annotation.width, height: annotation.height })
      });
      Object.assign(annotation, result.annotation);
      showToast(mode === "resize" ? "Annotation resized." : "Annotation moved.");
    } catch (error) {
      Object.assign(annotation, { x: start.left, y: start.top, width: start.width, height: start.height });
      renderAnnotations();
      showToast(error.message, true);
    }
  };

  window.addEventListener("pointermove", move);
  window.addEventListener("pointerup", finish, { once: true });
}

function renderAnnotations() {
  dom.annotationLayer.replaceChildren();
  for (const annotation of state.annotations.filter((item) => item.page === state.page)) {
    const node = element("button", {
      className: `annotation ${annotation.type}`,
      type: "button",
      title: ["note", "text"].includes(annotation.type) ? annotation.text : `${annotation.type} on page ${annotation.page}`
    });
    node.style.left = `${annotation.x * 100}%`;
    node.style.top = `${annotation.y * 100}%`;
    node.style.width = `${annotation.width * 100}%`;
    node.style.height = `${annotation.height * 100}%`;
    if (annotation.type === "signature") node.style.backgroundImage = `url(${annotation.text})`;
    if (annotation.type === "text") {
      node.textContent = annotation.text;
      node.style.color = annotation.color;
      const height = annotation.height * dom.annotationLayer.clientHeight;
      node.style.fontSize = `${Math.min(18 * state.zoom, Math.max(7 * state.zoom, height * 0.42))}px`;
    }
    if (annotation.type === "note") {
      node.style.backgroundColor = annotation.color;
      node.style.color = contrastingTextColor(annotation.color);
    }
    if (annotation.type === "highlight") node.style.backgroundColor = `${annotation.color}52`;
    const resize = element("span", { className: "annotation-resize", title: "Drag to resize" });
    resize.addEventListener("pointerdown", (event) => editAnnotation(event, annotation, node, "resize"));
    node.append(resize);
    node.addEventListener("pointerdown", (event) => {
      if (event.target === resize) return;
      editAnnotation(event, annotation, node, "move");
    });
    node.addEventListener("click", (event) => {
      event.stopPropagation();
      if (node.dataset.dragged) {
        delete node.dataset.dragged;
        return;
      }
      if (["note", "text"].includes(annotation.type)) editAnnotationDetails(annotation);
    });
    dom.annotationLayer.append(node);
    if (annotation.type === "text") {
      const minimum = 7 * state.zoom;
      let size = Number.parseFloat(node.style.fontSize);
      while (node.scrollHeight > node.clientHeight && size > minimum) {
        size = Math.max(minimum, size - 0.5);
        node.style.fontSize = `${size}px`;
      }
    }
  }
}

function renderAnnotationList() {
  const nativeNotes = [...state.nativeNotes.values()].flat();
  dom.annotationCount.textContent = String(state.annotations.length + nativeNotes.length);
  dom.annotationList.replaceChildren();
  if (!state.annotations.length && !nativeNotes.length) {
    dom.annotationList.append(element("p", { className: "quiet", text: "No annotations yet." }));
    return;
  }
  for (const annotation of state.annotations) {
    const row = element("div", { className: "annotation-row" });
    const open = element("button", { className: "result-button", type: "button" }, [
      element("strong", { text: `Page ${annotation.page} · ${annotation.type === "text" ? "text overlay" : annotation.type}` }),
      element("span", { text: ["note", "text"].includes(annotation.type) ? annotation.text : formatDate(annotation.created_at) })
    ]);
    open.addEventListener("click", () => {
      goToPage(annotation.page);
      if (["note", "text"].includes(annotation.type)) editAnnotationDetails(annotation);
    });
    if (["note", "text"].includes(annotation.type)) {
      const edit = element("button", { className: "annotation-edit", type: "button", text: "Edit", title: "Edit annotation" });
      edit.addEventListener("click", () => editAnnotationDetails(annotation));
      row.append(edit);
    } else if (annotation.type === "highlight") {
      const color = document.createElement("input");
      color.type = "color";
      color.className = "annotation-edit";
      color.title = "Change highlight color";
      color.value = annotation.color;
      color.addEventListener("change", () => updateAnnotationDetails(annotation, { color: color.value }));
      row.append(color);
    }
    const remove = element("button", { className: "annotation-delete", type: "button", text: "×", title: "Delete annotation" });
    remove.addEventListener("click", () => deleteAnnotation(annotation.id));
    row.append(open, remove);
    dom.annotationList.append(row);
  }
  for (const note of nativeNotes) {
    const row = element("div", { className: "annotation-row" });
    const open = element("button", { className: "result-button", type: "button" }, [
      element("strong", { text: `Page ${note.page} · PDF sticky note` }),
      element("span", { text: note.text })
    ]);
    open.addEventListener("click", () => {
      goToPage(note.page);
      openPdfNote(note);
    });
    row.append(open);
    dom.annotationList.append(row);
  }
}

function editAnnotationDetails(annotation) {
  state.editingAnnotation = annotation;
  state.pendingNote = null;
  state.pendingText = null;
  if (annotation.type === "note") {
    dom.noteText.value = annotation.text;
    dom.noteColor.value = annotation.color;
    dom.noteDialogTitle.textContent = "Read or edit note";
    dom.saveNote.textContent = "Save note";
    dom.deleteNote.hidden = false;
    if (!dom.noteDialog.open) dom.noteDialog.showModal();
    dom.noteText.focus();
  } else if (annotation.type === "text") {
    dom.replacementText.value = annotation.text;
    dom.textColor.value = annotation.color;
    dom.textDialogTitle.textContent = "Edit overlay text";
    dom.saveText.textContent = "Save text";
    dom.deleteText.hidden = false;
    if (!dom.textDialog.open) dom.textDialog.showModal();
    dom.replacementText.focus();
  }
}

async function updateAnnotationDetails(annotation, changes) {
  try {
    const { annotation: updated } = await api(`/api/annotations/${annotation.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(changes)
    });
    Object.assign(annotation, updated);
    renderAnnotations();
    renderAnnotationList();
    showToast("Annotation updated.");
    return true;
  } catch (error) {
    showToast(error.message, true);
    return false;
  }
}

async function deleteAnnotation(id) {
  try {
    await api(`/api/annotations/${id}`, { method: "DELETE" });
    state.annotations = state.annotations.filter((annotation) => annotation.id !== id);
    renderAnnotations();
    renderAnnotationList();
    loadLibrary();
    showToast("Annotation deleted.");
    return true;
  } catch (error) {
    showToast(error.message, true);
    return false;
  }
}

async function searchDocument() {
  const query = dom.documentSearch.value.trim();
  if (!query || !state.current) return renderSearchResults([]);
  dom.searchResults.replaceChildren(element("p", { className: "quiet", text: "Searching…" }));
  try {
    const { results } = await api(`/api/documents/${state.current.id}/search?q=${encodeURIComponent(query)}`);
    if (query === dom.documentSearch.value.trim()) renderSearchResults(results);
  } catch (error) {
    dom.searchResults.replaceChildren(element("p", { className: "quiet", text: error.message }));
    dom.searchCount.textContent = "";
  }
}

function renderSearchResults(results) {
  dom.searchResults.replaceChildren();
  dom.searchCount.textContent = results.length ? String(results.length) : "";
  if (!results.length) {
    dom.searchResults.append(element("p", { className: "quiet", text: dom.documentSearch.value.trim() ? "No matches." : "Search inside the current PDF." }));
    return;
  }
  for (const result of results) {
    const button = element("button", { className: "result-button", type: "button" }, [
      element("strong", { text: `Page ${result.page}` }),
      element("span", { text: result.snippet })
    ]);
    button.addEventListener("click", () => goToPage(result.page));
    dom.searchResults.append(button);
  }
}

function clearSignature() {
  const context = dom.signaturePad.getContext("2d");
  context.clearRect(0, 0, dom.signaturePad.width, dom.signaturePad.height);
  context.lineCap = "round";
  context.lineJoin = "round";
  context.lineWidth = 4;
  context.strokeStyle = "#173b2b";
  state.signatureHasInk = false;
}

function signaturePoint(event) {
  const bounds = dom.signaturePad.getBoundingClientRect();
  return {
    x: (event.clientX - bounds.left) * (dom.signaturePad.width / bounds.width),
    y: (event.clientY - bounds.top) * (dom.signaturePad.height / bounds.height)
  };
}

function wireSignaturePad() {
  const context = dom.signaturePad.getContext("2d");
  let drawing = false;
  dom.signaturePad.addEventListener("pointerdown", (event) => {
    drawing = true;
    state.signatureHasInk = true;
    const point = signaturePoint(event);
    context.beginPath();
    context.moveTo(point.x, point.y);
    dom.signaturePad.setPointerCapture?.(event.pointerId);
  });
  dom.signaturePad.addEventListener("pointermove", (event) => {
    if (!drawing) return;
    const point = signaturePoint(event);
    context.lineTo(point.x, point.y);
    context.stroke();
  });
  const stop = () => { drawing = false; };
  dom.signaturePad.addEventListener("pointerup", stop);
  dom.signaturePad.addEventListener("pointercancel", stop);
}

function openOrganizer() {
  if (!state.current) return showToast("Open a PDF first.", true);
  dom.organizerPages.replaceChildren();
  for (let page = 1; page <= state.current.page_count; page++) {
    const checkbox = element("input");
    checkbox.type = "checkbox";
    checkbox.value = String(page);
    const row = element("div", { className: "organizer-row", dataset: { page: String(page) } }, [
      element("span", { className: "drag-handle", text: "⋮⋮", title: "Drag to reorder" }),
      element("span", { className: "page-badge", text: String(page) }),
      element("strong", { text: `Page ${page}` }),
      checkbox
    ]);
    row.draggable = true;
    wireReorderRow(row, dom.organizerPages);
    dom.organizerPages.append(row);
  }
  $("#toggle-pages").textContent = "Select all";
  dom.organizerName.value = `${baseName(state.current.name)}-revised.pdf`;
  dom.organizerDialog.showModal();
}

function openMerge() {
  if (state.documents.length < 2) return showToast("Import at least two PDFs to merge.", true);
  dom.mergeList.replaceChildren();
  for (const document of state.documents) {
    const checkbox = element("input");
    checkbox.type = "checkbox";
    checkbox.checked = true;
    const row = element("div", { className: "merge-row", dataset: { id: document.id } }, [
      element("span", { className: "drag-handle", text: "⋮⋮", title: "Drag to reorder" }),
      element("span", { className: "page-badge", text: "PDF" }),
      element("span", {}, [element("strong", { text: document.name }), element("small", { text: `${document.page_count} pages` })]),
      checkbox
    ]);
    row.draggable = true;
    wireReorderRow(row, dom.mergeList);
    dom.mergeList.append(row);
  }
  dom.mergeDialog.showModal();
}

function wireReorderRow(row, container) {
  row.addEventListener("dragstart", () => row.classList.add("dragging"));
  row.addEventListener("dragend", () => row.classList.remove("dragging"));
  row.addEventListener("dragover", (event) => {
    event.preventDefault();
    const dragging = container.querySelector(".dragging");
    if (!dragging || dragging === row) return;
    const box = row.getBoundingClientRect();
    container.insertBefore(dragging, event.clientY < box.top + box.height / 2 ? row : row.nextSibling);
  });
}

function selectedOrganizerPages() {
  return [...dom.organizerPages.querySelectorAll("input:checked")].map((checkbox) => Number(checkbox.value));
}

function toggleOrganizerPages() {
  const checkboxes = [...dom.organizerPages.querySelectorAll("input[type=checkbox]")];
  const select = checkboxes.some((checkbox) => !checkbox.checked);
  for (const checkbox of checkboxes) checkbox.checked = select;
  $("#toggle-pages").textContent = select ? "Clear" : "Select all";
}

async function runOperation(body, { closeDialog = null, download = false, busyMessage = "Creating PDF…" } = {}) {
  setBusy(true, busyMessage);
  try {
    const { document: created } = await api("/api/operations", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    closeDialog?.close();
    await loadLibrary({ preserveSelection: false });
    await openDocument(created.id, { force: true });
    if (download) {
      const link = element("a");
      link.href = `/api/documents/${created.id}/file`;
      link.download = created.name;
      document.body.append(link);
      link.click();
      link.remove();
    }
    showToast(`${created.name} created. The source is unchanged.`);
    return created;
  } catch (error) {
    showToast(error.message, true);
    return null;
  } finally {
    setBusy(false, "");
  }
}

async function organizerOperation(operation) {
  const pages = operation === "reorder"
    ? [...dom.organizerPages.children].map((row) => Number(row.dataset.page))
    : selectedOrganizerPages();
  if (operation !== "reorder" && !pages.length) return showToast("Select at least one page.", true);
  await runOperation({
    operation,
    documentId: state.current.id,
    pages,
    degrees: operation === "rotate" ? Number(dom.rotationDegrees.value) : undefined,
    name: dom.organizerName.value
  }, { closeDialog: dom.organizerDialog });
}

async function runMerge() {
  const documentIds = [...dom.mergeList.children]
    .filter((row) => row.querySelector("input").checked)
    .map((row) => row.dataset.id);
  if (documentIds.length < 2) return showToast("Select at least two PDFs.", true);
  await runOperation({ operation: "merge", documentIds, name: dom.mergeName.value }, { closeDialog: dom.mergeDialog });
}

async function runOcr() {
  if (!state.current) return;
  await runOperation({ operation: "ocr", documentId: state.current.id, language: "eng" }, { busyMessage: "Running OCR locally…" });
}

async function exportAnnotations() {
  if (!state.current) return;
  await runOperation({ operation: "export-annotations", documentId: state.current.id }, { download: true, busyMessage: "Exporting annotations…" });
}

async function archiveCurrent() {
  if (!state.current || !window.confirm(`Remove “${state.current.name}” from the library? The source file remains recoverable on disk.`)) return;
  try {
    await api(`/api/documents/${state.current.id}`, { method: "DELETE" });
    state.current = null;
    state.pdf = null;
    dom.reader.hidden = true;
    dom.emptyState.hidden = false;
    await loadLibrary({ preserveSelection: false });
    showToast("Document removed from the library; its file remains recoverable.");
  } catch (error) {
    showToast(error.message, true);
  }
}

async function openTrash() {
  dom.trashList.replaceChildren(element("p", { className: "quiet", text: "Loading…" }));
  dom.backupList.replaceChildren(element("p", { className: "quiet", text: "Loading…" }));
  dom.trashDialog.showModal();
  try {
    const [{ documents }, { backups }] = await Promise.all([api("/api/trash"), api("/api/backups")]);
    dom.trashList.replaceChildren();
    if (!documents.length) {
      dom.trashList.append(element("p", { className: "quiet", text: "No removed documents." }));
    }
    for (const document of documents) {
      const row = element("div", { className: "trash-row" }, [
        element("span", {}, [
          element("strong", { text: document.name }),
          element("small", { text: `${document.page_count} page${document.page_count === 1 ? "" : "s"} · removed ${formatDate(document.updated_at)}` })
        ])
      ]);
      const restore = element("button", { className: "button secondary", type: "button", text: "Restore" });
      restore.addEventListener("click", async () => {
        restore.disabled = true;
        try {
          await api(`/api/documents/${document.id}/restore`, { method: "POST" });
          await loadLibrary({ preserveSelection: false });
          dom.trashDialog.close();
          await openDocument(document.id, { force: true });
          showToast(`${document.name} restored.`);
        } catch (error) {
          restore.disabled = false;
          showToast(error.message, true);
        }
      });
      const remove = element("button", { className: "button danger-outline", type: "button", text: "Delete permanently" });
      remove.addEventListener("click", async () => {
        if (!window.confirm(`Permanently delete “${document.name}” and its annotations from this computer? This cannot be undone.`)) return;
        remove.disabled = true;
        try {
          await api(`/api/trash/${document.id}`, { method: "DELETE" });
          row.remove();
          showToast(`${document.name} permanently deleted.`);
        } catch (error) {
          remove.disabled = false;
          showToast(error.message, true);
        }
      });
      row.append(element("div", { className: "row-actions" }, [restore, remove]));
      dom.trashList.append(row);
    }
    renderBackups(backups);
  } catch (error) {
    dom.trashList.replaceChildren(element("p", { className: "quiet", text: error.message }));
    dom.backupList.replaceChildren();
  }
}

function renderBackups(backups) {
  dom.backupList.replaceChildren();
  if (!backups.length) {
    dom.backupList.append(element("p", { className: "quiet", text: "No backups yet." }));
    return;
  }
  for (const backup of backups) {
    const row = element("div", { className: "backup-row" }, [
      element("span", {}, [
        element("strong", { text: formatDate(backup.created_at) }),
        element("small", { text: `${backup.documents} document${backup.documents === 1 ? "" : "s"} · ${backup.path}` })
      ])
    ]);
    const restore = element("button", { className: "button secondary", type: "button", text: "Restore" });
    restore.addEventListener("click", async () => {
      if (!window.confirm("Restore missing documents, annotations, and reading state from this backup? Newer library items will be kept.")) return;
      restore.disabled = true;
      try {
        await api(`/api/backups/${backup.id}/restore`, { method: "POST" });
        await loadLibrary({ preserveSelection: false });
        dom.trashDialog.close();
        showToast("Library restored from backup.");
      } catch (error) {
        restore.disabled = false;
        showToast(error.message, true);
      }
    });
    const remove = element("button", { className: "button danger-outline", type: "button", text: "Delete" });
    remove.addEventListener("click", async () => {
      if (!window.confirm(`Permanently delete the backup from ${formatDate(backup.created_at)}?`)) return;
      remove.disabled = true;
      try {
        await api(`/api/backups/${backup.id}`, { method: "DELETE" });
        row.remove();
        showToast("Backup deleted.");
      } catch (error) {
        remove.disabled = false;
        showToast(error.message, true);
      }
    });
    row.append(element("div", { className: "row-actions" }, [restore, remove]));
    dom.backupList.append(row);
  }
}

async function createBackup() {
  const button = $("#create-backup");
  button.disabled = true;
  try {
    const { backup } = await api("/api/backups", { method: "POST" });
    const { backups } = await api("/api/backups");
    renderBackups(backups);
    showToast(`Backup created with ${backup.documents} document${backup.documents === 1 ? "" : "s"}.`);
  } catch (error) {
    showToast(error.message, true);
  } finally {
    button.disabled = false;
  }
}

async function resetAdaptive() {
  try {
    await api("/api/adaptive", { method: "DELETE" });
    await loadLibrary();
    showToast("Shortcut history reset.");
  } catch (error) {
    showToast(error.message, true);
  }
}

async function loadStatus() {
  state.status = await api("/api/status");
  dom.aboutDataDir.textContent = state.status.dataDir;
  const missing = Object.entries(state.status.tools).filter(([, available]) => !available).map(([name]) => name);
  const ocrButton = $("#ocr-button");
  ocrButton.disabled = missing.length > 0;
  ocrButton.title = missing.length ? `Install Poppler, Tesseract, and qpdf to enable local OCR. Missing: ${missing.join(", ")}.` : "Create a searchable OCR copy";
}

function wireEvents() {
  dom.fileInput.addEventListener("change", () => importFiles(dom.fileInput.files));
  dom.libraryFilter.addEventListener("input", () => {
    clearTimeout(state.librarySearchTimer);
    state.librarySearchTimer = setTimeout(searchLibrary, 260);
  });
  $("#refresh-library").addEventListener("click", () => loadLibrary());
  $("#about-button").addEventListener("click", () => dom.aboutDialog.showModal());
  $("#reset-adaptive").addEventListener("click", resetAdaptive);
  $("#trash-button").addEventListener("click", openTrash);
  $("#create-backup").addEventListener("click", createBackup);
  $("#merge-button").addEventListener("click", openMerge);
  $("#organize-button").addEventListener("click", openOrganizer);
  $("#ocr-button").addEventListener("click", runOcr);
  $("#export-button").addEventListener("click", exportAnnotations);
  $("#archive-button").addEventListener("click", archiveCurrent);
  $("#previous-page").addEventListener("click", () => goToPage(state.page - 1));
  $("#next-page").addEventListener("click", () => goToPage(state.page + 1));
  dom.pageNumber.addEventListener("change", () => goToPage(dom.pageNumber.value));
  $("#zoom-out").addEventListener("click", () => changeZoom(-0.15));
  $("#zoom-in").addEventListener("click", () => changeZoom(0.15));
  dom.zoomLabel.addEventListener("click", cycleFit);
  $$(".tool-button").forEach((button) => button.addEventListener("click", () => setTool(button.dataset.tool)));

  dom.documentSearch.addEventListener("input", () => {
    clearTimeout(state.searchTimer);
    state.searchTimer = setTimeout(searchDocument, 260);
  });

  dom.annotationLayer.addEventListener("pointerdown", startDrawing);
  dom.annotationLayer.addEventListener("pointermove", moveDrawing);
  dom.annotationLayer.addEventListener("pointerup", finishDrawing);
  dom.annotationLayer.addEventListener("pointercancel", () => {
    state.drawStart = null;
    dom.drawBox.hidden = true;
  });

  dom.saveNote.addEventListener("click", async (event) => {
    event.preventDefault();
    const text = dom.noteText.value.trim();
    if (!text) return dom.noteText.focus();
    if (state.editingAnnotation?.type === "note") {
      if (await updateAnnotationDetails(state.editingAnnotation, { text, color: dom.noteColor.value })) dom.noteDialog.close();
      return;
    }
    if (!state.pendingNote) return;
    const point = state.pendingNote;
    if (await createAnnotation({ type: "note", ...placedBox(point, 0.028, 0.028), text, color: dom.noteColor.value })) dom.noteDialog.close();
  });
  dom.deleteNote.addEventListener("click", async () => {
    const annotation = state.editingAnnotation;
    if (annotation?.type === "note" && window.confirm("Delete this note?" ) && await deleteAnnotation(annotation.id)) dom.noteDialog.close();
  });
  dom.noteDialog.addEventListener("close", () => {
    state.pendingNote = null;
    if (state.editingAnnotation?.type === "note") state.editingAnnotation = null;
  });

  dom.saveText.addEventListener("click", async (event) => {
    event.preventDefault();
    const text = dom.replacementText.value.trim();
    if (!text) return dom.replacementText.focus();
    if (state.editingAnnotation?.type === "text") {
      if (await updateAnnotationDetails(state.editingAnnotation, { text, color: dom.textColor.value })) dom.textDialog.close();
      return;
    }
    if (!state.pendingText) return;
    const point = state.pendingText;
    if (await createAnnotation({ type: "text", ...placedBox(point, 0.34, 0.075), text, color: dom.textColor.value })) dom.textDialog.close();
  });
  dom.deleteText.addEventListener("click", async () => {
    const annotation = state.editingAnnotation;
    if (annotation?.type === "text" && window.confirm("Delete this text overlay?") && await deleteAnnotation(annotation.id)) dom.textDialog.close();
  });
  dom.textDialog.addEventListener("close", () => {
    state.pendingText = null;
    if (state.editingAnnotation?.type === "text") state.editingAnnotation = null;
  });

  $("#clear-signature").addEventListener("click", clearSignature);
  $("#save-signature").addEventListener("click", (event) => {
    event.preventDefault();
    if (!state.signatureHasInk) return showToast("Draw a signature first.", true);
    state.signature = dom.signaturePad.toDataURL("image/png");
    dom.signatureDialog.close();
    showToast("Signature ready. Click the page to place it.");
  });

  $("#rotate-pages").addEventListener("click", () => organizerOperation("rotate"));
  $("#toggle-pages").addEventListener("click", toggleOrganizerPages);
  $("#extract-pages").addEventListener("click", () => organizerOperation("extract"));
  $("#delete-pages").addEventListener("click", () => organizerOperation("delete"));
  $("#save-page-order").addEventListener("click", () => organizerOperation("reorder"));
  $("#run-merge").addEventListener("click", runMerge);

  for (const eventName of ["dragenter", "dragover"]) {
    dom.dropTarget.addEventListener(eventName, (event) => {
      event.preventDefault();
      if (state.busy) return;
      dom.dropTarget.classList.add("dragging");
    });
  }
  for (const eventName of ["dragleave", "drop"]) {
    dom.dropTarget.addEventListener(eventName, (event) => {
      event.preventDefault();
      dom.dropTarget.classList.remove("dragging");
    });
  }
  dom.dropTarget.addEventListener("drop", (event) => {
    if (!state.busy) importFiles(event.dataTransfer.files);
  });
  dom.dropTarget.addEventListener("keydown", (event) => {
    if (!state.busy && (event.key === "Enter" || event.key === " ")) dom.fileInput.click();
  });

  window.addEventListener("resize", () => {
    if (!state.pdf || state.fit === "custom") return;
    clearTimeout(state.resizeTimer);
    state.resizeTimer = setTimeout(renderPage, 160);
  });
  window.addEventListener("keydown", (event) => {
    if (state.busy) return;
    const typing = ["INPUT", "TEXTAREA"].includes(document.activeElement?.tagName);
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "f" && state.current) {
      event.preventDefault();
      dom.documentSearch.focus();
      return;
    }
    if (typing || !state.current || document.querySelector("dialog[open]")) return;
    if (event.key === "ArrowLeft" || event.key === "PageUp") goToPage(state.page - 1);
    if (event.key === "ArrowRight" || event.key === "PageDown") goToPage(state.page + 1);
    if (event.key.toLowerCase() === "h") setTool("highlight");
    if (event.key.toLowerCase() === "n") setTool("note");
    if (event.key.toLowerCase() === "t") setTool("text");
    if (event.key.toLowerCase() === "s") setTool("signature");
    if (event.key === "Escape") setTool("select");
  });
}

async function start() {
  wireEvents();
  wireSignaturePad();
  clearSignature();
  try {
    await loadStatus();
    await loadLibrary();
    if (state.documents.length) await openDocument(state.documents[0].id);
  } catch (error) {
    showToast(`Could not start the workstation: ${error.message}`, true);
  }
}

start();
