@echo off
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Paperwork requires Node.js 22.13 or newer.
  echo Download it from https://nodejs.org/
  pause
  exit /b 1
)

node -e "const [major, minor] = process.versions.node.split('.').map(Number); process.exit(major ^> 22 ^|^| (major === 22 ^&^& minor ^>= 13) ? 0 : 1)" >nul 2>nul
if errorlevel 1 (
  echo Paperwork requires Node.js 22.13 or newer.
  echo Download it from https://nodejs.org/
  pause
  exit /b 1
)

if not exist node_modules (
  echo Installing Paperwork's open-source components...
  call npm ci --omit=dev
  if errorlevel 1 (
    pause
    exit /b 1
  )
)

start "Paperwork server" cmd /c "npm start"
timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:4310/
