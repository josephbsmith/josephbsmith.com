# `[001]` PDF Workstation

A local-first PDF reader and document workstation for real files.

## Product behavior

- Imports PDFs into a durable library without altering the source upload.
- Renders documents with selectable text and interactive PDF links, and remembers the last page and zoom.
- Searches extracted text and returns page-linked results.
- Stores movable and resizable highlights, notes, white-backed text overlays, and signatures separately from the source.
- Exports a new flattened PDF containing visible annotations.
- Creates new documents for merge, extraction, deletion, rotation, and reordering while preserving Paperwork annotations and registered AcroForm fields.
- Restores removed documents and creates restorable local library backups.
- OCRs scanned documents locally when the optional Poppler, Tesseract, and qpdf tools are installed.
- Surfaces recent documents and frequently used actions from local activity.

The workstation never overwrites an imported PDF. Generated copies are added to the same library with provenance recorded in SQLite.

Core reading and editing are implemented in JavaScript with PDF.js and pdf-lib, so Poppler is not required to open, search, edit, or export PDFs.

Text overlays and multiline notes use an embedded TrueType Noto Sans SC font and export correctly on rotated and cropped pages. They are not redaction: the covered source content remains inside the PDF. Paperwork rejects unsupported overlay characters instead of silently corrupting them.

The server accepts only loopback hosts, validates browser origins and request content types, and requires an HttpOnly, same-site session cookie for document APIs. Imports are limited to 200 MB and 5,000 pages, and memory-heavy work is serialized.
