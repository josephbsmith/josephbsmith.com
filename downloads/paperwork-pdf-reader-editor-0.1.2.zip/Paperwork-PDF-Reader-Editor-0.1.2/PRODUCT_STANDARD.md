# Product standard

An application is not considered complete because its interface demonstrates a workflow. It must be useful with the owner's real data.

## Required for every product

1. Accept real files, records, devices, or public/API data appropriate to the product.
2. Persist primary data on disk in an inspectable database or standard file format.
3. Provide backup and restore before accumulating irreplaceable data.
4. Preserve source material and make destructive edits explicit.
5. Export a standard format that can leave the suite.
6. Record provenance for imported and derived information.
7. Search the user's real data.
8. Remember useful preferences such as recent work, preferred views, repeated actions, and defaults.
9. Explain adaptation and allow the user to reset it.
10. Include automated checks for risky logic and file transformations.
11. Work without a network when the underlying task does not require one.
12. State external data, licensing, privacy, and regulatory dependencies inside the product.

## Shared personal behavior

Products may share documents, contacts, organizations, tasks, tags, and activity history. They do not silently copy data. A product links to a shared record or creates an explicit export/import event.

Adaptation uses local event counts and saved preferences first. Statistical or language-model assistance must remain optional, show its source material, and never overwrite primary data without confirmation.
