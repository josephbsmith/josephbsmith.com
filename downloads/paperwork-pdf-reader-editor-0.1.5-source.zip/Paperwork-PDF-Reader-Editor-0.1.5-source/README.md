# Paperwork PDF Reader & Editor

Paperwork is a free, local-first PDF reader and editor. It works on real PDF files, stores its library on your computer, and never uploads documents to a cloud service.

It is the first working application, `[001]`, in the Personal Applications roadmap. Paperwork is still in reliability development; it is useful today, but it is not yet an Acrobat-class everyday editor.

## Install Paperwork 0.1.5

Paperwork is distributed as a real desktop application. The macOS download is a universal DMG containing `Paperwork.app`; the Windows download is a 64-bit installer that creates Start menu and desktop shortcuts. Neither desktop build requires Node.js.

The current builds are not notarized or commercially code-signed. On macOS, open the app once with **Control-click → Open**. On Windows, Microsoft Defender SmartScreen may require **More info → Run anyway**. The source is public and the release checksums are published with each download.

Desktop libraries are stored in the operating system's normal application-data directory:

- macOS: `~/Library/Application Support/Paperwork/library/`
- Windows: `%APPDATA%\Paperwork\library\`

## Run from source

The command launchers remain available for source and portable use. Node.js 22.13 or newer is required for this route.

```sh
npm ci --omit=dev
npm start
```

Open `http://127.0.0.1:4310`.

Documents and application state are stored under `data/001-pdf-workstation/` when running from source. Set `PERSONAL_APPS_DATA_DIR` to put them elsewhere. To run the desktop shell in development, install all dependencies with `npm ci` and run `npm run desktop`.

Reading, selectable text, interactive links, document and library search, highlights, Unicode text overlays, signatures, page editing, and export require no external PDF utilities. Page operations preserve Paperwork annotations, registered AcroForm fields, and valid internal page links while avoiding orphaned page objects. Exported and imported PDF sticky notes remain visible, readable, and searchable in Paperwork. A text overlay is visual editing, not secure redaction: underlying content may remain extractable. Optional scanned-document OCR uses Poppler, Tesseract, and qpdf when those tools are installed.

Paperwork accepts PDFs up to 200 MB and 5,000 pages. Expensive document operations run one at a time to keep memory use predictable. The local API uses a per-launch browser session and rejects non-local hosts, foreign origins, and unexpected request content types.

Removed documents can be restored or permanently deleted from **Recently removed**. The same screen can create, restore, and delete complete local backups of PDFs, annotations, and reading state. A backup restore adds missing records without resurrecting documents removed after the snapshot. Copy a backup folder to another drive if it must survive a disk failure.

## Product rules

- Real inputs, not sample-only workflows.
- Durable storage on disk, not browser-only state.
- Non-destructive editing by default.
- Standard import and export formats.
- Local processing whenever the machine can do the work.
- Adaptation that is visible, reversible, and based on observed preferences.
- Automated checks for calculations, parsers, security, and file operations.

See [PRODUCT_STANDARD.md](PRODUCT_STANDARD.md) and [ROADMAP.md](ROADMAP.md). The roadmap treats Paperwork as a full PDF workstation in its own right, with Acrobat-class document workflows built in focused releases rather than as a thin shared shell.
