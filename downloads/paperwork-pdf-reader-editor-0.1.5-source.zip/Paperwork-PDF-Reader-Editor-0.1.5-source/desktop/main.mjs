import path from "node:path";
import { app, BrowserWindow, dialog, session, shell } from "electron";
import { createApplication } from "../apps/001-pdf-workstation/server.mjs";
import { externalHttpUrl } from "./url.mjs";

app.setName("Paperwork");

let paperwork;
let mainWindow;
let origin;
let closing = false;

function createWindow() {
  mainWindow = new BrowserWindow({
    title: "Paperwork",
    width: 1440,
    height: 940,
    minWidth: 900,
    minHeight: 640,
    backgroundColor: "#f4f0e7",
    autoHideMenuBar: true,
    icon: path.join(import.meta.dirname, "build", "icon.png"),
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    const external = externalHttpUrl(url);
    if (external) void shell.openExternal(external);
    return { action: "deny" };
  });
  mainWindow.webContents.on("will-navigate", (event, url) => {
    if (url === origin || url.startsWith(`${origin}/`)) return;
    event.preventDefault();
    const external = externalHttpUrl(url);
    if (external) void shell.openExternal(external);
  });
  mainWindow.on("closed", () => { mainWindow = null; });
  void mainWindow.loadURL(origin);
}

async function start() {
  session.defaultSession.setPermissionRequestHandler((_webContents, _permission, callback) => callback(false));
  paperwork = createApplication({ dataDir: path.join(app.getPath("userData"), "library") });
  await new Promise((resolve, reject) => {
    paperwork.server.once("error", reject);
    paperwork.server.listen(0, "127.0.0.1", resolve);
  });
  origin = `http://127.0.0.1:${paperwork.server.address().port}`;
  createWindow();
}

async function shutdown() {
  if (closing) return;
  closing = true;
  const instance = paperwork;
  paperwork = null;
  if (instance) await instance.close();
  app.quit();
}

const singleInstance = app.requestSingleInstanceLock();
if (!singleInstance) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (!mainWindow) createWindow();
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.show();
    mainWindow.focus();
  });
  app.on("activate", () => {
    if (!mainWindow && origin) createWindow();
  });
  app.on("window-all-closed", () => {
    if (process.platform !== "darwin") void shutdown();
  });
  app.on("before-quit", (event) => {
    if (paperwork && !closing) {
      event.preventDefault();
      void shutdown();
    }
  });
  app.whenReady().then(start).catch((error) => {
    dialog.showErrorBox("Paperwork could not start", error.message);
    app.quit();
  });
}
