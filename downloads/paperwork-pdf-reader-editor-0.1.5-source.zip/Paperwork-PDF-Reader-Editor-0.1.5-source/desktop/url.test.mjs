import test from "node:test";
import assert from "node:assert/strict";
import { externalHttpUrl } from "./url.mjs";

test("desktop shell only opens ordinary web links externally", () => {
  assert.equal(externalHttpUrl("https://example.com/help"), "https://example.com/help");
  assert.equal(externalHttpUrl("http://example.com/"), "http://example.com/");
  assert.equal(externalHttpUrl("file:///etc/passwd"), null);
  assert.equal(externalHttpUrl("javascript:alert(1)"), null);
  assert.equal(externalHttpUrl("not a URL"), null);
});
