#!/bin/sh
set -eu

cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "Paperwork requires Node.js 22.5 or newer. Download it from https://nodejs.org/"
  read -r _
  exit 1
fi

if [ ! -d node_modules ]; then
  echo "Installing Paperwork's open-source components…"
  npm ci --omit=dev
fi

npm start &
paperwork_pid=$!
trap 'kill "$paperwork_pid" 2>/dev/null || true' INT TERM EXIT

attempt=0
while [ "$attempt" -lt 40 ]; do
  if curl -fsS http://127.0.0.1:4310/api/status >/dev/null 2>&1; then
    open http://127.0.0.1:4310/
    wait "$paperwork_pid"
    exit $?
  fi
  attempt=$((attempt + 1))
  sleep 0.25
done

echo "Paperwork did not start. Review the messages above."
wait "$paperwork_pid"
