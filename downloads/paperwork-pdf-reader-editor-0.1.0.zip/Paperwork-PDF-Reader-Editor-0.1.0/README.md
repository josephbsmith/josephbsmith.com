# Paperwork PDF Reader & Editor

Paperwork is a free, local-first PDF reader and editor. It works on real PDF files, stores its library on your computer, and never uploads documents to a cloud service.

It is also the first completed application, `[001]`, in the Personal Applications roadmap.

## Run `[001]`

On macOS, double-click `Start Paperwork.command`. On Windows, double-click `Start Paperwork.bat`.

You can also run it from a terminal:

```sh
npm ci --omit=dev
npm start
```

Open `http://127.0.0.1:4310`.

Node.js 22.5 or newer is required. The launchers install the two open-source JavaScript dependencies the first time they run. Documents and application state are stored under `data/001-pdf-workstation/`. Set `PERSONAL_APPS_DATA_DIR` to put them elsewhere.

Reading, text search, highlights, replacement text, signatures, page editing, and export require no external PDF utilities. Optional scanned-document OCR uses Poppler, Tesseract, and qpdf when those tools are installed.

## Product rules

- Real inputs, not sample-only workflows.
- Durable storage on disk, not browser-only state.
- Non-destructive editing by default.
- Standard import and export formats.
- Local processing whenever the machine can do the work.
- Adaptation that is visible, reversible, and based on observed preferences.
- Automated checks for calculations, parsers, security, and file operations.

See [PRODUCT_STANDARD.md](PRODUCT_STANDARD.md) and [ROADMAP.md](ROADMAP.md).
