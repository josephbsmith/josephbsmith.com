@echo off
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Paperwork requires Node.js 22.5 or newer.
  echo Download it from https://nodejs.org/
  pause
  exit /b 1
)

if not exist node_modules (
  echo Installing Paperwork's open-source components...
  call npm ci --omit=dev
  if errorlevel 1 pause & exit /b 1
)

start "Paperwork server" cmd /c "npm start"
timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:4310/
