# Third-party notices

Paperwork installs these open-source packages through npm:

- `pdf-lib` — MIT License
- `pdfjs-dist` (Mozilla PDF.js) — Apache License 2.0

Their exact versions and transitive packages are recorded in `package-lock.json`. Optional OCR uses separately installed Poppler, Tesseract OCR, and qpdf under their respective licenses.
