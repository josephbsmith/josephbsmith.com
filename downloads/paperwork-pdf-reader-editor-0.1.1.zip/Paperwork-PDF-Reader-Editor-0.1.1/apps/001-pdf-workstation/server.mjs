import http from "node:http";
import { createReadStream, createWriteStream, existsSync, mkdirSync, renameSync, statSync, unlinkSync } from "node:fs";
import { mkdtemp, readFile, readdir, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createHash, randomBytes, randomUUID, timingSafeEqual } from "node:crypto";
import { execFile as execFileCallback } from "node:child_process";
import { promisify } from "node:util";
import { DatabaseSync } from "node:sqlite";
import fontkit from "@pdf-lib/fontkit";
import { PDFDocument, degrees, rgb } from "pdf-lib";
import { getDocument as getPdfDocument } from "pdfjs-dist/legacy/build/pdf.mjs";

const execFile = promisify(execFileCallback);
const HERE = path.dirname(fileURLToPath(import.meta.url));
const REPO = path.resolve(HERE, "../..");
const PUBLIC = path.join(HERE, "public");
const MAX_UPLOAD = 200 * 1024 * 1024;
const MAX_PAGES = 5_000;
const UNICODE_FONT = path.join(HERE, "assets", "NotoSansCJKsc-Regular.otf");
const PDFJS_STANDARD_FONTS = `${path.join(REPO, "node_modules", "pdfjs-dist", "standard_fonts")}${path.sep}`;

function commandAvailable(name) {
  const suffixes = process.platform === "win32" ? [".exe", ".cmd", ".bat", ""] : [""];
  return String(process.env.PATH || "").split(path.delimiter).some((directory) =>
    suffixes.some((suffix) => existsSync(path.join(directory, `${name}${suffix}`)))
  );
}

function fail(status, message) {
  const error = new Error(message);
  error.status = status;
  return error;
}

export function safeName(value, fallback = "document.pdf") {
  let name = String(value || fallback).normalize("NFKC").replace(/[\x00-\x1f<>:"/\\|?*]+/g, " ").replace(/\s+/g, " ").trim();
  if (!name) name = fallback;
  if (!name.toLowerCase().endsWith(".pdf")) name += ".pdf";
  return name.slice(0, 180);
}

export function validatePages(pages, count, { allowEmpty = false, permutation = false } = {}) {
  if (!Array.isArray(pages)) throw fail(400, "Pages must be an array.");
  const normalized = pages.map(Number);
  if ((!allowEmpty && !normalized.length) || normalized.some((page) => !Number.isInteger(page) || page < 1 || page > count)) {
    throw fail(400, `Pages must be whole numbers from 1 through ${count}.`);
  }
  if (new Set(normalized).size !== normalized.length) throw fail(400, "A page may appear only once.");
  if (permutation && normalized.length !== count) throw fail(400, "A reordered document must include every page exactly once.");
  return normalized;
}

function now() {
  return new Date().toISOString();
}

function json(res, status, body) {
  const data = Buffer.from(JSON.stringify(body));
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": data.length,
    "Cache-Control": "no-store"
  });
  res.end(data);
}

function requireContentType(req, expected) {
  const actual = String(req.headers["content-type"] || "").split(";", 1)[0].trim().toLowerCase();
  if (actual !== expected) throw fail(415, `Content-Type must be ${expected}.`);
}

function requestHost(req) {
  const host = String(req.headers.host || "");
  let hostname;
  try {
    hostname = new URL(`http://${host}`).hostname.toLowerCase();
  } catch {
    throw fail(400, "Invalid Host header.");
  }
  if (!["127.0.0.1", "localhost"].includes(hostname)) throw fail(403, "Paperwork only accepts local requests.");
  const origin = req.headers.origin;
  if (origin && origin !== `http://${host}`) throw fail(403, "Request origin is not allowed.");
  return host;
}

function safeEqual(left, right) {
  const a = Buffer.from(String(left));
  const b = Buffer.from(String(right));
  return a.length === b.length && timingSafeEqual(a, b);
}

function pageBox(page) {
  const media = page.getMediaBox();
  const crop = page.getCropBox();
  const x = Math.max(media.x, crop.x);
  const y = Math.max(media.y, crop.y);
  const right = Math.min(media.x + media.width, crop.x + crop.width);
  const top = Math.min(media.y + media.height, crop.y + crop.height);
  return right > x && top > y ? { x, y, width: right - x, height: top - y } : media;
}

export function annotationGeometry(page, annotation) {
  const box = pageBox(page);
  const rotation = ((page.getRotation().angle % 360) + 360) % 360;
  if (![0, 90, 180, 270].includes(rotation)) throw fail(422, "Annotations require page rotation in 90-degree increments.");
  const displayWidth = rotation % 180 ? box.height : box.width;
  const displayHeight = rotation % 180 ? box.width : box.height;
  const width = Math.min(displayWidth, Math.max(Number(annotation.width) * displayWidth, 8));
  const height = Math.min(displayHeight, Math.max(Number(annotation.height) * displayHeight, 8));
  const screenX = Math.min(Number(annotation.x) * displayWidth, displayWidth - width);
  const screenY = Math.min(Number(annotation.y) * displayHeight, displayHeight - height);
  const bottom = screenY + height;
  if (rotation === 90) return { x: box.x + bottom, y: box.y + screenX, width, height, rotation, displayWidth, screenX };
  if (rotation === 180) return { x: box.x + box.width - screenX, y: box.y + bottom, width, height, rotation, displayWidth, screenX };
  if (rotation === 270) return { x: box.x + box.width - bottom, y: box.y + box.height - screenX, width, height, rotation, displayWidth, screenX };
  return { x: box.x + screenX, y: box.y + box.height - bottom, width, height, rotation, displayWidth, screenX };
}

function localPoint(geometry, x, y) {
  if (geometry.rotation === 90) return { x: geometry.x - y, y: geometry.y + x };
  if (geometry.rotation === 180) return { x: geometry.x - x, y: geometry.y - y };
  if (geometry.rotation === 270) return { x: geometry.x + y, y: geometry.y - x };
  return { x: geometry.x + x, y: geometry.y + y };
}

function wrapText(text, font, size, maxWidth) {
  const lines = [];
  let line = "";
  let width = 0;
  for (const character of String(text || "").replace(/\s+/gu, " ").trim()) {
    const characterWidth = font.widthOfTextAtSize(character, size);
    if (line && width + characterWidth > maxWidth) {
      lines.push(line.trimEnd());
      line = character.trimStart();
      width = line ? characterWidth : 0;
    } else {
      line += character;
      width += characterWidth;
    }
  }
  if (line) lines.push(line.trimEnd());
  return lines;
}

async function readJson(req, max = 2 * 1024 * 1024) {
  const chunks = [];
  let length = 0;
  for await (const chunk of req) {
    length += chunk.length;
    if (length > max) throw fail(413, "Request is too large.");
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw fail(400, "Request body must be valid JSON.");
  }
}

async function receivePdf(req, target) {
  return new Promise((resolve, reject) => {
    const output = createWriteStream(target, { flags: "wx" });
    const hash = createHash("sha256");
    let size = 0;
    let prefix = Buffer.alloc(0);
    let settled = false;

    function abort(error) {
      if (settled) return;
      settled = true;
      output.destroy();
      req.destroy();
      try { unlinkSync(target); } catch {}
      reject(error);
    }

    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > MAX_UPLOAD) return abort(fail(413, "PDF exceeds the 200 MB import limit."));
      if (prefix.length < 8) prefix = Buffer.concat([prefix, chunk]).subarray(0, 8);
      hash.update(chunk);
      if (!output.write(chunk)) req.pause();
    });
    output.on("drain", () => req.resume());
    req.on("end", () => output.end());
    req.on("error", abort);
    output.on("error", abort);
    output.on("finish", () => {
      if (settled) return;
      if (!prefix.toString("latin1").startsWith("%PDF-")) {
        settled = true;
        try { unlinkSync(target); } catch {}
        return reject(fail(400, "That file is not a PDF."));
      }
      settled = true;
      resolve({ size, sha256: hash.digest("hex") });
    });
  });
}

function contentType(file) {
  if (file.endsWith(".html")) return "text/html; charset=utf-8";
  if (file.endsWith(".css")) return "text/css; charset=utf-8";
  if (file.endsWith(".js") || file.endsWith(".mjs")) return "text/javascript; charset=utf-8";
  if (file.endsWith(".pdf")) return "application/pdf";
  return "application/octet-stream";
}

function cleanRecord(row) {
  if (!row) return null;
  return {
    ...row,
    source_ids: JSON.parse(row.source_ids || "[]")
  };
}

export function createApplication(options = {}) {
  const dataDir = path.resolve(options.dataDir || process.env.PERSONAL_APPS_DATA_DIR || path.join(REPO, "data", "001-pdf-workstation"));
  const documentsDir = path.join(dataDir, "documents");
  const exportsDir = path.join(dataDir, "exports");
  const tempDir = path.join(dataDir, "tmp");
  [dataDir, documentsDir, exportsDir, tempDir].forEach((dir) => mkdirSync(dir, { recursive: true }));

  const db = new DatabaseSync(path.join(dataDir, "library.sqlite"));
  const sessionToken = randomBytes(32).toString("base64url");
  const sessionCookie = `paperwork_session=${sessionToken}; HttpOnly; SameSite=Strict; Path=/`;
  let heavyJobs = Promise.resolve();

  function hasSession(req) {
    const token = String(req.headers.cookie || "").split(/;\s*/).find((cookie) => cookie.startsWith("paperwork_session="))?.slice(18);
    return token ? safeEqual(token, sessionToken) : false;
  }

  function runHeavy(task) {
    const job = heavyJobs.then(task, task);
    heavyJobs = job.catch(() => {});
    return job;
  }

  db.exec("PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;");
  db.exec(`
    CREATE TABLE IF NOT EXISTS documents (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      file_name TEXT NOT NULL,
      imported_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      last_opened_at TEXT,
      page_count INTEGER NOT NULL,
      size INTEGER NOT NULL,
      sha256 TEXT NOT NULL,
      source_type TEXT NOT NULL DEFAULT 'import',
      source_ids TEXT NOT NULL DEFAULT '[]',
      archived INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS reading_state (
      document_id TEXT PRIMARY KEY REFERENCES documents(id) ON DELETE CASCADE,
      page INTEGER NOT NULL DEFAULT 1,
      zoom REAL NOT NULL DEFAULT 1.15,
      fit TEXT NOT NULL DEFAULT 'width',
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS annotations (
      id TEXT PRIMARY KEY,
      document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
      page INTEGER NOT NULL,
      type TEXT NOT NULL,
      x REAL NOT NULL,
      y REAL NOT NULL,
      width REAL NOT NULL,
      height REAL NOT NULL,
      color TEXT NOT NULL,
      text TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS text_cache (
      document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
      page INTEGER NOT NULL,
      text TEXT NOT NULL,
      PRIMARY KEY (document_id, page)
    );
    CREATE TABLE IF NOT EXISTS activity (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      action TEXT NOT NULL,
      document_id TEXT,
      created_at TEXT NOT NULL
    );
  `);

  const selectDocument = db.prepare("SELECT * FROM documents WHERE id = ? AND archived = 0");
  const insertDocument = db.prepare(`
    INSERT INTO documents (id, name, file_name, imported_at, updated_at, page_count, size, sha256, source_type, source_ids)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const recordActivity = db.prepare("INSERT INTO activity (action, document_id, created_at) VALUES (?, ?, ?)");

  function documentById(id) {
    const row = selectDocument.get(id);
    if (!row) throw fail(404, "Document not found.");
    return cleanRecord(row);
  }

  function documentPath(document) {
    return path.join(documentsDir, document.file_name);
  }

  async function inspectPdf(file) {
    try {
      const pdf = await PDFDocument.load(await readFile(file), { updateMetadata: false });
      const pageCount = pdf.getPageCount();
      if (!Number.isInteger(pageCount) || pageCount < 1) throw new Error("missing page count");
      if (pageCount > MAX_PAGES) throw fail(413, `PDF exceeds the ${MAX_PAGES.toLocaleString("en-US")}-page limit.`);
      return { pageCount };
    } catch (error) {
      if (error.status) throw error;
      if (/encrypt|password/i.test(String(error?.message || error))) {
        throw fail(400, "Password-protected PDFs must be unlocked before import.");
      }
      throw fail(400, "The PDF is damaged or unsupported.");
    }
  }

  async function registerPdf(file, name, sourceType = "generated", sourceIds = []) {
    const { pageCount } = await inspectPdf(file);
    const bytes = await readFile(file);
    const id = randomUUID();
    const fileName = `${id}.pdf`;
    const finalPath = path.join(documentsDir, fileName);
    renameSync(file, finalPath);
    const stamp = now();
    insertDocument.run(
      id,
      safeName(name),
      fileName,
      stamp,
      stamp,
      pageCount,
      bytes.length,
      createHash("sha256").update(bytes).digest("hex"),
      sourceType,
      JSON.stringify(sourceIds)
    );
    recordActivity.run(sourceType, id, stamp);
    return documentById(id);
  }

  function listDocuments() {
    return db.prepare(`
      SELECT d.*,
        COALESCE(s.page, 1) AS current_page,
        COALESCE(s.zoom, 1.15) AS zoom,
        COALESCE(s.fit, 'width') AS fit,
        (SELECT COUNT(*) FROM annotations a WHERE a.document_id = d.id) AS annotation_count
      FROM documents d
      LEFT JOIN reading_state s ON s.document_id = d.id
      WHERE d.archived = 0
      ORDER BY COALESCE(d.last_opened_at, d.imported_at) DESC
    `).all().map(cleanRecord);
  }

  async function extractText(document) {
    const cached = db.prepare("SELECT page, text FROM text_cache WHERE document_id = ? ORDER BY page").all(document.id);
    if (cached.length === document.page_count) return cached;
    let loadingTask;
    const pages = [];
    try {
      loadingTask = getPdfDocument({
        data: Uint8Array.from(await readFile(documentPath(document))),
        disableWorker: true,
        standardFontDataUrl: PDFJS_STANDARD_FONTS
      });
      const pdf = await loadingTask.promise;
      for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber++) {
        const page = await pdf.getPage(pageNumber);
        const content = await page.getTextContent();
        pages.push(content.items.map((item) => `${item.str || ""}${item.hasEOL ? "\n" : " "}`).join("").trim());
        page.cleanup();
      }
    } catch {
      throw fail(422, "Text extraction failed. Run OCR for a scanned document.");
    } finally {
      await loadingTask?.destroy().catch(() => {});
    }
    const insert = db.prepare("INSERT OR REPLACE INTO text_cache (document_id, page, text) VALUES (?, ?, ?)");
    db.exec("BEGIN");
    try {
      db.prepare("DELETE FROM text_cache WHERE document_id = ?").run(document.id);
      for (let page = 1; page <= document.page_count; page++) insert.run(document.id, page, pages[page - 1] || "");
      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
    return db.prepare("SELECT page, text FROM text_cache WHERE document_id = ? ORDER BY page").all(document.id);
  }

  function snippet(text, query) {
    const normalized = text.replace(/\s+/g, " ").trim();
    const index = normalized.toLowerCase().indexOf(query.toLowerCase());
    if (index < 0) return normalized.slice(0, 220);
    const start = Math.max(0, index - 80);
    const end = Math.min(normalized.length, index + query.length + 140);
    return `${start ? "…" : ""}${normalized.slice(start, end)}${end < normalized.length ? "…" : ""}`;
  }

  async function writeOperation(body) {
    const operation = String(body.operation || "");
    if (operation === "merge") {
      if (!Array.isArray(body.documentIds) || body.documentIds.length < 2) throw fail(400, "Select at least two PDFs to merge.");
      const output = await PDFDocument.create();
      for (const id of body.documentIds) {
        const document = documentById(id);
        const source = await PDFDocument.load(await readFile(documentPath(document)));
        const copied = await output.copyPages(source, source.getPageIndices());
        copied.forEach((page) => output.addPage(page));
      }
      return saveGenerated(output, body.name || "Merged.pdf", "merge", body.documentIds);
    }

    const document = documentById(body.documentId);
    const source = await PDFDocument.load(await readFile(documentPath(document)));
    const count = source.getPageCount();
    let output;

    if (operation === "rotate") {
      const pages = validatePages(body.pages, count);
      const delta = Number(body.degrees);
      if (![90, 180, 270, -90].includes(delta)) throw fail(400, "Rotation must be 90, 180, or 270 degrees.");
      for (const pageNumber of pages) {
        const page = source.getPage(pageNumber - 1);
        page.setRotation(degrees((page.getRotation().angle + delta + 360) % 360));
      }
      output = source;
    } else if (operation === "delete") {
      const removed = new Set(validatePages(body.pages, count));
      if (removed.size === count) throw fail(400, "A PDF must keep at least one page.");
      output = await PDFDocument.create();
      const kept = Array.from({ length: count }, (_, index) => index).filter((index) => !removed.has(index + 1));
      (await output.copyPages(source, kept)).forEach((page) => output.addPage(page));
    } else if (operation === "extract") {
      const pages = validatePages(body.pages, count);
      output = await PDFDocument.create();
      (await output.copyPages(source, pages.map((page) => page - 1))).forEach((page) => output.addPage(page));
    } else if (operation === "reorder") {
      const order = validatePages(body.pages, count, { permutation: true });
      output = await PDFDocument.create();
      (await output.copyPages(source, order.map((page) => page - 1))).forEach((page) => output.addPage(page));
    } else if (operation === "export-annotations") {
      await flattenAnnotations(source, document.id);
      output = source;
    } else {
      throw fail(400, "Unknown PDF operation.");
    }

    const suffix = {
      rotate: "rotated",
      delete: "pages-removed",
      extract: "extract",
      reorder: "reordered",
      "export-annotations": "annotated"
    }[operation];
    const base = document.name.replace(/\.pdf$/i, "");
    return saveGenerated(output, body.name || `${base}-${suffix}.pdf`, operation, [document.id]);
  }

  async function flattenAnnotations(pdf, documentId) {
    const annotations = db.prepare("SELECT * FROM annotations WHERE document_id = ? ORDER BY created_at").all(documentId);
    let font;
    if (annotations.some((annotation) => ["note", "text"].includes(annotation.type))) {
      pdf.registerFontkit(fontkit);
      font = await pdf.embedFont(await readFile(UNICODE_FONT), { subset: true });
      const supported = new Set(font.getCharacterSet());
      const unsupported = [...new Set(annotations
        .filter((annotation) => ["note", "text"].includes(annotation.type))
        .flatMap((annotation) => [...annotation.text].filter((character) => !supported.has(character.codePointAt(0)))))]
        .slice(0, 8);
      if (unsupported.length) throw fail(400, `Overlay text contains unsupported characters: ${unsupported.join(" ")}`);
    }
    for (const annotation of annotations) {
      const page = pdf.getPage(annotation.page - 1);
      if (!page) continue;
      const geometry = annotationGeometry(page, annotation);
      const rotation = degrees(geometry.rotation);
      if (annotation.type === "signature" && annotation.text.startsWith("data:image/png;base64,")) {
        const png = await pdf.embedPng(Buffer.from(annotation.text.split(",")[1], "base64"));
        page.drawImage(png, { x: geometry.x, y: geometry.y, width: geometry.width, height: geometry.height, rotate: rotation });
      } else if (annotation.type === "text") {
        const size = Math.min(18, Math.max(7, geometry.height * 0.42));
        const lines = wrapText(annotation.text || "Text", font, size, geometry.width - 6);
        page.drawRectangle({ x: geometry.x, y: geometry.y, width: geometry.width, height: geometry.height, rotate: rotation, color: rgb(1, 1, 1), opacity: 1 });
        lines.slice(0, Math.max(1, Math.floor(geometry.height / (size * 1.2)))).forEach((line, index) => {
          const point = localPoint(geometry, 3, geometry.height - size * (index + 1));
          page.drawText(line, { ...point, size, font, rotate: rotation, color: rgb(0.08, 0.1, 0.09) });
        });
      } else if (annotation.type === "note") {
        page.drawRectangle({ x: geometry.x, y: geometry.y, width: geometry.width, height: geometry.height, rotate: rotation, color: rgb(0.98, 0.78, 0.18), opacity: 0.95 });
        const point = localPoint(geometry, 3, geometry.height + 3);
        page.drawText(String(annotation.text || "Note").slice(0, 220), {
          ...point,
          size: 8,
          font,
          rotate: rotation,
          color: rgb(0.18, 0.15, 0.08),
          maxWidth: Math.min(geometry.displayWidth - geometry.screenX - 6, 250)
        });
      } else {
        page.drawRectangle({ x: geometry.x, y: geometry.y, width: geometry.width, height: geometry.height, rotate: rotation, color: rgb(1, 0.84, 0.18), opacity: 0.32 });
      }
    }
  }

  async function saveGenerated(pdf, name, sourceType, sourceIds) {
    const bytes = await pdf.save({ useObjectStreams: true });
    const temp = path.join(tempDir, `${randomUUID()}.pdf`);
    await writeFile(temp, bytes);
    return registerPdf(temp, name, sourceType, sourceIds);
  }

  async function ocrDocument(document, language = "eng") {
    if (!["pdftoppm", "tesseract", "qpdf"].every(commandAvailable)) {
      throw fail(501, "OCR requires Poppler, Tesseract, and qpdf. Reading and editing work without them.");
    }
    if (!/^[A-Za-z0-9_+.-]+$/.test(language)) throw fail(400, "OCR language contains unsupported characters.");
    const work = await mkdtemp(path.join(tempDir, "ocr-"));
    try {
      const prefix = path.join(work, "page");
      await execFile("pdftoppm", ["-png", "-r", "200", documentPath(document), prefix], { maxBuffer: 32 * 1024 * 1024 });
      const images = (await readdir(work)).filter((name) => /^page-\d+\.png$/.test(name)).sort((a, b) => Number(a.match(/\d+/)[0]) - Number(b.match(/\d+/)[0]));
      if (!images.length) throw fail(422, "No pages were rendered for OCR.");
      const pagePdfs = [];
      for (let index = 0; index < images.length; index++) {
        const base = path.join(work, `ocr-${String(index + 1).padStart(4, "0")}`);
        await execFile("tesseract", [path.join(work, images[index]), base, "-l", language, "pdf", "txt"], { maxBuffer: 32 * 1024 * 1024 });
        pagePdfs.push(`${base}.pdf`);
      }
      const output = path.join(tempDir, `${randomUUID()}.pdf`);
      await execFile("qpdf", ["--empty", "--pages", ...pagePdfs, "--", output], { maxBuffer: 32 * 1024 * 1024 });
      const baseName = document.name.replace(/\.pdf$/i, "");
      return registerPdf(output, `${baseName}-ocr.pdf`, "ocr", [document.id]);
    } finally {
      await rm(work, { recursive: true, force: true });
    }
  }

  function serveFile(req, res, file, extraHeaders = {}) {
    if (!existsSync(file)) throw fail(404, "File not found.");
    const size = statSync(file).size;
    const range = req.headers.range;
    const common = {
      "Content-Type": contentType(file),
      "Accept-Ranges": "bytes",
      "X-Content-Type-Options": "nosniff",
      ...extraHeaders
    };
    if (range) {
      const match = range.match(/^bytes=(\d*)-(\d*)$/);
      if (!match) throw fail(416, "Invalid byte range.");
      const start = match[1] ? Number(match[1]) : 0;
      const end = match[2] ? Math.min(Number(match[2]), size - 1) : size - 1;
      if (start > end || start >= size) throw fail(416, "Byte range is outside the file.");
      res.writeHead(206, { ...common, "Content-Range": `bytes ${start}-${end}/${size}`, "Content-Length": end - start + 1 });
      createReadStream(file, { start, end }).pipe(res);
      return;
    }
    res.writeHead(200, { ...common, "Content-Length": size });
    createReadStream(file).pipe(res);
  }

  async function handler(req, res) {
    const host = requestHost(req);
    const url = new URL(req.url, "http://127.0.0.1");
    const method = req.method || "GET";
    res.setHeader("Content-Security-Policy", "default-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'; object-src 'none'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; worker-src 'self' blob:; connect-src 'self'");
    res.setHeader("Referrer-Policy", "no-referrer");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("Cross-Origin-Resource-Policy", "same-origin");

    if (method === "GET" && url.pathname === "/api/status") {
      return json(res, 200, { product: "001", dataDir, tools: {
        pdftoppm: commandAvailable("pdftoppm"),
        tesseract: commandAvailable("tesseract"),
        qpdf: commandAvailable("qpdf")
      }, limits: { uploadBytes: MAX_UPLOAD, pages: MAX_PAGES } });
    }
    if (url.pathname.startsWith("/api/") && !hasSession(req)) throw fail(401, "Open Paperwork in its browser window to start an authorized session.");
    if (method === "GET" && url.pathname === "/api/documents") return json(res, 200, { documents: listDocuments() });

    if (method === "POST" && url.pathname === "/api/documents") {
      requireContentType(req, "application/pdf");
      const id = randomUUID();
      const temp = path.join(tempDir, `${id}.upload`);
      try {
        const received = await receivePdf(req, temp);
        const { pageCount } = await runHeavy(() => inspectPdf(temp));
        const fileName = `${id}.pdf`;
        renameSync(temp, path.join(documentsDir, fileName));
        const stamp = now();
        const name = safeName(url.searchParams.get("name") || req.headers["x-file-name"] || "document.pdf");
        insertDocument.run(id, name, fileName, stamp, stamp, pageCount, received.size, received.sha256, "import", "[]");
        recordActivity.run("import", id, stamp);
        return json(res, 201, { document: documentById(id) });
      } catch (error) {
        try { unlinkSync(temp); } catch {}
        throw error;
      }
    }

    const fileMatch = url.pathname.match(/^\/api\/documents\/([0-9a-f-]+)\/file$/i);
    if (method === "GET" && fileMatch) {
      const document = documentById(fileMatch[1]);
      return serveFile(req, res, documentPath(document), { "Content-Disposition": `inline; filename*=UTF-8''${encodeURIComponent(document.name)}` });
    }

    const openMatch = url.pathname.match(/^\/api\/documents\/([0-9a-f-]+)\/open$/i);
    if (method === "POST" && openMatch) {
      const document = documentById(openMatch[1]);
      const stamp = now();
      db.prepare("UPDATE documents SET last_opened_at = ? WHERE id = ?").run(stamp, document.id);
      recordActivity.run("open", document.id, stamp);
      return json(res, 200, { ok: true });
    }

    const stateMatch = url.pathname.match(/^\/api\/documents\/([0-9a-f-]+)\/state$/i);
    if (method === "PUT" && stateMatch) {
      requireContentType(req, "application/json");
      const document = documentById(stateMatch[1]);
      const body = await readJson(req);
      const page = Math.min(document.page_count, Math.max(1, Number(body.page) || 1));
      const zoom = Math.min(5, Math.max(0.25, Number(body.zoom) || 1.15));
      const fit = body.fit === "page" ? "page" : body.fit === "custom" ? "custom" : "width";
      db.prepare(`
        INSERT INTO reading_state (document_id, page, zoom, fit, updated_at) VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(document_id) DO UPDATE SET page=excluded.page, zoom=excluded.zoom, fit=excluded.fit, updated_at=excluded.updated_at
      `).run(document.id, page, zoom, fit, now());
      return json(res, 200, { page, zoom, fit });
    }

    const searchMatch = url.pathname.match(/^\/api\/documents\/([0-9a-f-]+)\/search$/i);
    if (method === "GET" && searchMatch) {
      const document = documentById(searchMatch[1]);
      const query = String(url.searchParams.get("q") || "").trim();
      if (!query) return json(res, 200, { results: [] });
      const pages = await runHeavy(() => extractText(document));
      const lowered = query.toLowerCase();
      const results = pages.filter((page) => page.text.toLowerCase().includes(lowered)).slice(0, 100).map((page) => ({ page: page.page, snippet: snippet(page.text, query) }));
      recordActivity.run("search", document.id, now());
      return json(res, 200, { results });
    }

    const annotationsMatch = url.pathname.match(/^\/api\/documents\/([0-9a-f-]+)\/annotations$/i);
    if (annotationsMatch && method === "GET") {
      const document = documentById(annotationsMatch[1]);
      const annotations = db.prepare("SELECT * FROM annotations WHERE document_id = ? ORDER BY created_at").all(document.id);
      return json(res, 200, { annotations });
    }
    if (annotationsMatch && method === "POST") {
      requireContentType(req, "application/json");
      const document = documentById(annotationsMatch[1]);
      const body = await readJson(req, 4 * 1024 * 1024);
      const type = ["highlight", "note", "text", "signature"].includes(body.type) ? body.type : null;
      const page = Number(body.page);
      if (!type || !Number.isInteger(page) || page < 1 || page > document.page_count) throw fail(400, "Annotation type or page is invalid.");
      const values = [body.x, body.y, body.width, body.height].map(Number);
      if (values.some((value) => !Number.isFinite(value) || value < 0 || value > 1) || values[0] + values[2] > 1 || values[1] + values[3] > 1) {
        throw fail(400, "Annotation coordinates must fit within the page.");
      }
      const annotation = {
        id: randomUUID(), document_id: document.id, page, type,
        x: values[0], y: values[1], width: values[2], height: values[3],
        color: String(body.color || "#f6c945").slice(0, 20),
        text: String(body.text || "").slice(0, type === "signature" ? 2_000_000 : 10_000),
        created_at: now()
      };
      db.prepare(`INSERT INTO annotations (id, document_id, page, type, x, y, width, height, color, text, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(annotation.id, annotation.document_id, annotation.page, annotation.type, annotation.x, annotation.y, annotation.width, annotation.height, annotation.color, annotation.text, annotation.created_at);
      recordActivity.run(type, document.id, annotation.created_at);
      return json(res, 201, { annotation });
    }

    const annotationDelete = url.pathname.match(/^\/api\/annotations\/([0-9a-f-]+)$/i);
    if (method === "DELETE" && annotationDelete) {
      const result = db.prepare("DELETE FROM annotations WHERE id = ?").run(annotationDelete[1]);
      if (!result.changes) throw fail(404, "Annotation not found.");
      return json(res, 200, { ok: true });
    }

    if (method === "POST" && url.pathname === "/api/operations") {
      requireContentType(req, "application/json");
      const body = await readJson(req, 4 * 1024 * 1024);
      const result = await runHeavy(() => body.operation === "ocr"
        ? ocrDocument(documentById(body.documentId), String(body.language || "eng"))
        : writeOperation(body));
      return json(res, 201, { document: result });
    }

    if (method === "GET" && url.pathname === "/api/adaptive") {
      const recent = listDocuments().slice(0, 5);
      const actions = db.prepare(`SELECT action, COUNT(*) AS count FROM activity WHERE created_at >= strftime('%Y-%m-%dT%H:%M:%fZ', 'now', '-90 days') GROUP BY action ORDER BY count DESC, action LIMIT 8`).all();
      return json(res, 200, { recent, actions });
    }

    const archiveMatch = url.pathname.match(/^\/api\/documents\/([0-9a-f-]+)$/i);
    if (method === "DELETE" && archiveMatch) {
      const document = documentById(archiveMatch[1]);
      db.prepare("UPDATE documents SET archived = 1, updated_at = ? WHERE id = ?").run(now(), document.id);
      recordActivity.run("archive", document.id, now());
      return json(res, 200, { ok: true, recoverable: true });
    }

    const staticFiles = {
      "/": path.join(PUBLIC, "index.html"),
      "/index.html": path.join(PUBLIC, "index.html"),
      "/app.js": path.join(PUBLIC, "app.js"),
      "/style.css": path.join(PUBLIC, "style.css"),
      "/vendor/pdf.mjs": path.join(REPO, "node_modules", "pdfjs-dist", "build", "pdf.mjs"),
      "/vendor/pdf.worker.mjs": path.join(REPO, "node_modules", "pdfjs-dist", "build", "pdf.worker.mjs")
    };
    if (method === "GET" && staticFiles[url.pathname]) {
      const headers = { "Cache-Control": url.pathname.startsWith("/vendor/") ? "public, max-age=31536000, immutable" : "no-cache" };
      if (["/", "/index.html"].includes(url.pathname)) headers["Set-Cookie"] = sessionCookie;
      return serveFile(req, res, staticFiles[url.pathname], headers);
    }
    throw fail(404, "Not found.");
  }

  const server = http.createServer((req, res) => {
    handler(req, res).catch((error) => {
      if (res.headersSent) return res.destroy();
      json(res, error.status || 500, { error: error.status ? error.message : "Unexpected server error." });
      if (!error.status) console.error(error);
    });
  });

  return {
    server,
    db,
    dataDir,
    close() {
      return new Promise((resolve) => server.close(() => { db.close(); resolve(); }));
    }
  };
}

if (path.resolve(process.argv[1] || "") === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 4310);
  const app = createApplication();
  app.server.listen(port, "127.0.0.1", () => {
    console.log(`PDF Workstation is running at http://127.0.0.1:${port}`);
    console.log(`Data directory: ${app.dataDir}`);
  });
}
