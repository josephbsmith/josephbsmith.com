import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { request as httpRequest } from "node:http";
import os from "node:os";
import path from "node:path";
import { PDFDocument, StandardFonts, degrees, rgb } from "pdf-lib";
import { annotationGeometry, createApplication, safeName, validatePages } from "../server.mjs";

async function makePdf(pageTexts) {
  const pdf = await PDFDocument.create();
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  for (const text of pageTexts) {
    const page = pdf.addPage([612, 792]);
    page.drawText(text, { x: 72, y: 650, size: 30, font, color: rgb(0.08, 0.16, 0.12) });
  }
  return Buffer.from(await pdf.save());
}

async function sessionClient(origin) {
  const home = await fetch(`${origin}/`);
  const setCookie = home.headers.get("set-cookie") || "";
  assert.match(setCookie, /^paperwork_session=[A-Za-z0-9_-]+;/);
  assert.match(setCookie, /HttpOnly/i);
  assert.match(setCookie, /SameSite=Strict/i);
  const cookie = setCookie.split(";", 1)[0];
  const request = async (route, options = {}) => {
    const headers = new Headers(options.headers);
    headers.set("Cookie", cookie);
    const response = await fetch(`${origin}${route}`, { ...options, headers });
    const body = await response.json();
    return { response, body };
  };
  request.raw = (route, options = {}) => {
    const headers = new Headers(options.headers);
    headers.set("Cookie", cookie);
    return fetch(`${origin}${route}`, { ...options, headers });
  };
  return request;
}

function statusWithHost(origin, host) {
  const url = new URL(origin);
  return new Promise((resolve, reject) => {
    const request = httpRequest({ hostname: url.hostname, port: url.port, path: "/api/status", headers: { Host: host } }, (response) => {
      response.resume();
      response.on("end", () => resolve(response.statusCode));
    });
    request.on("error", reject);
    request.end();
  });
}

test("filename and page validation reject unsafe input", () => {
  assert.equal(safeName('../A:<bad>  name'), ".. A bad name.pdf");
  assert.deepEqual(validatePages([3, 1], 3), [3, 1]);
  assert.throws(() => validatePages([1, 1], 3), /only once/);
  assert.throws(() => validatePages([1, 4], 3), /1 through 3/);
  assert.throws(() => validatePages([1, 2], 3, { permutation: true }), /every page/);
});

test("annotation geometry follows crop boxes and page rotation", async () => {
  const pdf = await PDFDocument.create();
  const page = pdf.addPage([600, 800]);
  page.setCropBox(50, 100, 400, 600);
  const annotation = { x: 0.1, y: 0.2, width: 0.3, height: 0.1 };
  const expected = {
    0: { x: 90, y: 520, width: 120, height: 60 },
    90: { x: 170, y: 160, width: 180, height: 40 },
    180: { x: 410, y: 280, width: 120, height: 60 },
    270: { x: 330, y: 640, width: 180, height: 40 }
  };
  for (const rotation of [0, 90, 180, 270]) {
    page.setRotation(degrees(rotation));
    const geometry = annotationGeometry(page, annotation);
    assert.deepEqual(
      { x: geometry.x, y: geometry.y, width: geometry.width, height: geometry.height },
      expected[rotation]
    );
  }
});

test("PDF workstation persists and transforms real PDFs", async (context) => {
  const dataDir = await mkdtemp(path.join(os.tmpdir(), "paperwork-test-"));
  const app = createApplication({ dataDir });
  await new Promise((resolve) => app.server.listen(0, "127.0.0.1", resolve));
  const address = app.server.address();
  const origin = `http://127.0.0.1:${address.port}`;

  context.after(async () => {
    await app.close();
    await rm(dataDir, { recursive: true, force: true });
  });

  const statusResponse = await fetch(`${origin}/api/status`);
  const status = await statusResponse.json();
  assert.equal(statusResponse.status, 200);
  assert.equal(status.product, "001");
  assert.deepEqual(status.limits, { uploadBytes: 200 * 1024 * 1024, pages: 5_000 });

  const unauthorized = await fetch(`${origin}/api/documents`);
  assert.equal(unauthorized.status, 401);

  const request = await sessionClient(origin);
  const foreignOrigin = await request("/api/documents", { headers: { Origin: "https://attacker.example" } });
  assert.equal(foreignOrigin.response.status, 403);

  assert.equal(await statusWithHost(origin, "attacker.example"), 403);

  const wrongJsonType = await request("/api/operations", {
    method: "POST",
    headers: { "Content-Type": "text/plain" },
    body: JSON.stringify({ operation: "merge", documentIds: [] })
  });
  assert.equal(wrongJsonType.response.status, 415);

  const invalid = await request("/api/documents?name=fake.pdf", {
    method: "POST",
    headers: { "Content-Type": "application/pdf" },
    body: Buffer.from("not a pdf")
  });
  assert.equal(invalid.response.status, 400);

  const sourceBytes = await makePdf(["ALPHA REPORT", "BETA FINDING", "GAMMA APPENDIX"]);
  const imported = await request("/api/documents?name=Research.pdf", {
    method: "POST",
    headers: { "Content-Type": "application/pdf" },
    body: sourceBytes
  });
  assert.equal(imported.response.status, 201);
  assert.equal(imported.body.document.name, "Research.pdf");
  assert.equal(imported.body.document.page_count, 3);
  const id = imported.body.document.id;

  const range = await request.raw(`/api/documents/${id}/file`, { headers: { Range: "bytes=0-4" } });
  assert.equal(range.status, 206);
  assert.equal(await range.text(), "%PDF-");

  const savedState = await request(`/api/documents/${id}/state`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ page: 2, zoom: 1.4, fit: "custom" })
  });
  assert.deepEqual(savedState.body, { page: 2, zoom: 1.4, fit: "custom" });

  const search = await request(`/api/documents/${id}/search?q=BETA`);
  assert.equal(search.response.status, 200);
  assert.equal(search.body.results[0].page, 2);

  const annotation = await request(`/api/documents/${id}/annotations`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ page: 2, type: "note", x: 0.2, y: 0.2, width: 0.04, height: 0.04, color: "#f6c945", text: "Check this result" })
  });
  assert.equal(annotation.response.status, 201);

  const textEdit = await request(`/api/documents/${id}/annotations`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ page: 1, type: "text", x: 0.2, y: 0.3, width: 0.35, height: 0.08, color: "#1b211d", text: "修订报告 · REVISED REPORT" })
  });
  assert.equal(textEdit.response.status, 201);

  const outsidePage = await request(`/api/documents/${id}/annotations`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ page: 1, type: "highlight", x: 0.9, y: 0.9, width: 0.2, height: 0.2 })
  });
  assert.equal(outsidePage.response.status, 400);

  const annotations = await request(`/api/documents/${id}/annotations`);
  assert.equal(annotations.body.annotations.length, 2);

  const exported = await request("/api/operations", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ operation: "export-annotations", documentId: id })
  });
  assert.equal(exported.response.status, 201);
  assert.equal(exported.body.document.page_count, 3);
  assert.equal(exported.body.document.source_type, "export-annotations");

  for (const operation of [
    { operation: "rotate", documentId: id, pages: [1], degrees: 90, name: "Rotated.pdf", expected: 3 },
    { operation: "extract", documentId: id, pages: [2, 3], name: "Extract.pdf", expected: 2 },
    { operation: "delete", documentId: id, pages: [2], name: "Removed.pdf", expected: 2 },
    { operation: "reorder", documentId: id, pages: [3, 1, 2], name: "Reordered.pdf", expected: 3 }
  ]) {
    const result = await request("/api/operations", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(operation)
    });
    assert.equal(result.response.status, 201, `${operation.operation} failed: ${JSON.stringify(result.body)}`);
    assert.equal(result.body.document.page_count, operation.expected);
    assert.equal(result.body.document.source_type, operation.operation);
  }

  const second = await request("/api/documents?name=Second.pdf", {
    method: "POST",
    headers: { "Content-Type": "application/pdf" },
    body: await makePdf(["SECOND DOCUMENT"])
  });
  const merged = await request("/api/operations", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ operation: "merge", documentIds: [id, second.body.document.id], name: "Combined.pdf" })
  });
  assert.equal(merged.response.status, 201);
  assert.equal(merged.body.document.page_count, 4);

  const removed = await request(`/api/documents/${id}`, { method: "DELETE" });
  assert.equal(removed.body.recoverable, true);
  const library = await request("/api/documents");
  assert.equal(library.body.documents.some((document) => document.id === id), false);
});

test("local OCR creates a searchable PDF", { timeout: 120_000 }, async (context) => {
  const dataDir = await mkdtemp(path.join(os.tmpdir(), "paperwork-ocr-test-"));
  const app = createApplication({ dataDir });
  await new Promise((resolve) => app.server.listen(0, "127.0.0.1", resolve));
  const origin = `http://127.0.0.1:${app.server.address().port}`;
  const request = await sessionClient(origin);

  context.after(async () => {
    await app.close();
    await rm(dataDir, { recursive: true, force: true });
  });

  const imported = await request("/api/documents?name=Scan.pdf", {
    method: "POST",
    headers: { "Content-Type": "application/pdf" },
    body: await makePdf(["OCEAN FORTY TWO"])
  });
  const result = await request("/api/operations", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ operation: "ocr", documentId: imported.body.document.id, language: "eng" })
  });
  assert.equal(result.response.status, 201, JSON.stringify(result.body));
  assert.equal(result.body.document.source_type, "ocr");
  assert.equal(result.body.document.page_count, 1);

  const search = await request(`/api/documents/${result.body.document.id}/search?q=OCEAN`);
  assert.equal(search.body.results[0].page, 1);
});
