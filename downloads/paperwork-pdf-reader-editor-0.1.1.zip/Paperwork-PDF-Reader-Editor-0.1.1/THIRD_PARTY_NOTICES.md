# Third-party notices

Paperwork installs these open-source packages through npm:

- `pdf-lib` — MIT License
- `@pdf-lib/fontkit` — MIT License
- `pdfjs-dist` (Mozilla PDF.js) — Apache License 2.0
- Noto Sans CJK SC — SIL Open Font License 1.1; the full font license is included at `apps/001-pdf-workstation/assets/Noto-OFL.txt`.

Their exact versions and transitive packages are recorded in `package-lock.json`. Optional OCR uses separately installed Poppler, Tesseract OCR, and qpdf under their respective licenses.
