# Product roadmap

`[001]` is first because documents become inputs to many later products. The order below builds complete products while reusing proven capabilities.

## `[001]` Paperwork path to an Acrobat-class workstation

Paperwork remains a standalone product, not a generic application kernel. Each release should deepen the actual PDF workflow while keeping local processing, original interfaces, and non-destructive source handling.

- `0.1.x` foundation and hardening: reading and text selection, document and library search, editable annotations, Unicode overlays, signatures, OCR, annotation-, form-, and link-safe page organization, recovery, backup/restore and deletion, secure local sessions, resource limits, and verified packaging.
- `0.2.x` document editing: genuine redaction with sanitization checks, form filling and form creation, bookmarks, links, headers and footers, watermarks, page labels, metadata, attachments, and comparison.
- `0.3.x` production workflows: certificate-backed digital signatures, encryption and permissions, accessibility inspection, preflight, PDF/A conversion, batch actions, watched folders, and recovery.
- `1.0` personal professional workstation: the mature workflows above with dependable cross-platform installers, broad PDF compatibility, performance testing, and migration-safe storage.

Features that claim security properties—especially redaction, signatures, encryption, and archival compliance—do not ship until automated verification proves the exported file has those properties.

## Wave 1 - personal document desk

- `[001]` PDF workstation: library, reading, search, annotations, signing, OCR, page operations, export.
- `[040]` personal knowledge search: index the authorized local library with citations back to source files.
- `[030]` agreements and `[031]` signatures: document review, versions, approvals, signatures, and audit history.
- `[089]` writing review and `[090]` book writing: real document/manuscript projects with export.
- `[048]` literature discovery, `[046]` legal research, and `[047]` patent research: public-source retrieval plus the personal document library.

## Wave 2 - personal money and operations

- `[021] [032] [033] [034] [035] [036] [037] [038] [095]`
- Shared accounts, transactions, vendors, documents, imports, reconciliation, and auditable calculations.

## Wave 3 - projects, data, and decisions

- `[015] [016] [023] [026] [027] [028] [029] [042] [044] [051] [052] [053] [054] [055] [065] [070] [078]`
- Shared tables, pipelines, entities, tasks, schedules, scenarios, and reproducible analyses.

## Wave 4 - design and technical work

- `[002] [005] [006] [009] [010] [018] [019] [020] [063] [086] [096]`
- Real image, vector, IFC/GIS/EDA/drawing, publishing, and web formats backed by mature engines.

## Wave 5 - home and personal life

- `[062] [064] [071] [072] [073] [074] [075] [076] [077] [087] [088] [091] [092] [093] [094] [097] [098] [099] [100]`
- Real files, devices, calendars, photos, lessons, plans, speech models, and interoperable personal records.

## Wave 6 - regulated and organizational systems

- `[022] [024] [025] [039] [041] [043] [045] [057] [058] [061]`
- Built only with explicit jurisdiction, data-source, privacy, and validation boundaries. `[057]` and `[058]` remain billing/administration tools and never become clinical-record systems.
